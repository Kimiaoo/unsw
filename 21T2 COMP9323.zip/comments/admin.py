from django.contrib import admin

from .models import Comment

# registering the app_name to the admin site helps
# to manage the project through django admin tool
admin.site.register(Comment)
