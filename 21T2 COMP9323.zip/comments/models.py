from django.db import models
from django.utils import timezone
from posts.models import Posts
from user_center.models import User


class Comment(models.Model):
    # The model of comments

    # author_id, foreignkey related to table user_info
    author = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='comments'
    )

    # post_id, foreignkey related to table posts
    post = models.ForeignKey(
        Posts,
        on_delete=models.CASCADE,
        related_name='comments'
    )

    # content of the comment
    content = models.TextField()

    # created time of the comment, automatically generated
    create_time = models.DateTimeField(default=timezone.now)
