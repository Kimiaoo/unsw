from rest_framework import serializers
from comments.models import Comment

"""
For the detailed explanations of serializers, please refer to Django
Restful Framework official documentation.
"""


class CommentSerializer(serializers.ModelSerializer):
    """
    In the model of comments, we only store id of the author.
    But to help front-end to display other information such as
    username and avatar, we need to implement new methods.

    Note that following three functions are modified from
    similar functions in Posts app and we did not change their names.

    SerializerMethodField()  means that we want to add additional attribute
    through defining respective method.
    """

    post_username = serializers.SerializerMethodField()
    post_checked = serializers.SerializerMethodField()
    post_user_avatar = serializers.SerializerMethodField()

    def get_post_username(self, obj):
        # get the username of comment's author
        if obj.author.username:
            return obj.author.username
        else:
            return None

    def get_post_checked(self, obj):
        # get the checked of comment's author
        # checked is True when the author is expert/organization
        # otherwise False

        if obj.author.checked:
            return True
        else:
            return False

    def get_post_user_avatar(self, obj):
        # get the avatar of comments' author
        if obj.author.avatar:
            return str(obj.author.avatar)
        else:
            return None

    class Meta:
        # return all attribute in the Comment model
        model = Comment
        fields = '__all__'

