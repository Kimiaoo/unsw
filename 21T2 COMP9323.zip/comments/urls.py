from django.urls import path
from .views import CommentDetail, PublishComment

# registering the app_name helps to manage the project
app_name = 'comments'

urlpatterns = [
    # get access to particular comment through pk (primary key)
    # using CommentDetail in the view.py
    path('<int:pk>/', CommentDetail.as_view(), name='comment'),
    # publish a new comment using PublishComment in the view.py
    path('publish/', PublishComment.as_view(), name='publish'),
]
