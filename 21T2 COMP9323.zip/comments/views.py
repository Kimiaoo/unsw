from comments.models import Comment
from comments.serializers import CommentSerializer
from rest_framework.generics import RetrieveUpdateDestroyAPIView
from rest_framework.response import Response
from rest_framework.generics import CreateAPIView


class CommentDetail(RetrieveUpdateDestroyAPIView):
    """
    Show the information of a particular comment
    Since we get access to this class through /comments/<int:pk>,
    django can directly return record with that pk in the database
    and we do not need to filter.

    With Django Restful Framework, we can easily return JSON data through
    two simple lines.

    First one does the query and second one transforms query result
    into JSON.
    """

    queryset = Comment.objects.all()
    serializer_class = CommentSerializer


class PublishComment(CreateAPIView):
    """
    Publish a new comment
    """
    permission_classes = []
    authentication_classes = []
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer

    def create(self, request, *args, **kwargs):
        # Rewriting the method from CreateAPIView

        # get data from request
        serializer = self.get_serializer(data=request.data)
        # raise an exception if not valid data received
        serializer.is_valid(raise_exception=True)
        # write data to the database
        self.perform_create(serializer)

        # return success message back to front-end
        headers = self.get_success_headers(serializer.data)
        return Response({
            "code": 201,
            "message": "published successfully"
        }, headers=headers)
