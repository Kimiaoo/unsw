from django.db import models
from imagekit.models import ProcessedImageField
from pilkit.processors import ResizeToFill


class FilesUpload(models.Model):
    image_file = ProcessedImageField(upload_to='./post_image/', processors=[ResizeToFill(200, 200)], null=True,
                                     options={'quality': 60})

    created_time = models.DateTimeField(verbose_name='create_time', auto_now_add=True, null=True)
    # init user last modify time
    last_mod_time = models.DateTimeField(verbose_name='update_time', auto_now=True, null=True)

    class Meta:
        verbose_name = 'file management'
        verbose_name_plural = verbose_name
        ordering = ['-id']
        db_table = 'files'

