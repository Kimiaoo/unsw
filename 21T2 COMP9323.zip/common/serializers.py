# coding:utf-8
from rest_framework import serializers

from .models import FilesUpload

"""
For the detailed explanations of serializers, please refer to Django
Restful Framework official documentation.
"""
class ImageUploadSerializer(serializers.ModelSerializer):
    '''
    This serializer is used for upload file, image and save them into the assigned 
    directory, and return the saved path to the front-end.
    '''
    class Meta:
        model = FilesUpload
        fields = '__all__'

    def get_image_file(self, obj):
        if obj.image_file:
            return obj.image_file
        else:
            return None
