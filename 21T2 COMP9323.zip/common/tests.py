from django.test import TestCase

# close csrf
from rest_framework.authentication import SessionAuthentication


class CsrfCloseAuthentication(SessionAuthentication):

    def enforce_csrf(self, request):
        return
