# coding:utf-8
from django.urls import path

from .views import ImageUploadView

app_name = 'common'

urlpatterns = [
    # image upload
    path('image/', ImageUploadView.as_view(), name='comment'),
]
