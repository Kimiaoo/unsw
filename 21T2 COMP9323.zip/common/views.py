
from rest_framework.authentication import BasicAuthentication
from rest_framework.generics import CreateAPIView
from rest_framework.permissions import IsAuthenticated

from .models import FilesUpload
from .serializers import ImageUploadSerializer
from .tests import CsrfCloseAuthentication


class ImageUploadView(CreateAPIView):
    '''
    allow the user who has logged in to upload file, image to the server
    '''
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [CsrfCloseAuthentication, BasicAuthentication]

    serializer_class = ImageUploadSerializer

    queryset = FilesUpload.objects.all()
