<template>
  <div>
    <div>
      <a-layout id="app">
        <a-layout-header class="header" style="background-color:WhiteSmoke;">
          <div class="header-content">
            <a-dropdown v-if="$rootStore.userInf">
              <a-avatar shape="square" :size="48" icon="user" :src="$rootStore.userInf.avatar"/>
              <a-menu slot="overlay" @click="handleMineMenuClick">
                <a-menu-item key="profile" style="font-size:18px;padding:10px 20px">
                  <a-icon style="font-size:40px" type="idcard"/>
                  My profile
                </a-menu-item>
                <a-menu-item key="favourite" style="font-size:18px;padding:10px 20px">
                  <a-icon style="font-size:40px" type="heart"/>
                  Favourite
                </a-menu-item>
                <a-menu-item key="logout" style="font-size:18px;padding:10px 20px">
                  <a-icon style="font-size:40px" type="logout"/>
                  Log out
                </a-menu-item>
              </a-menu>
            </a-dropdown>
            <a-space v-else>
              <router-link :to="{ name: 'login' }">
                <a-button size="large" type="primary">Sign in</a-button>
              </router-link>
              <router-link :to="{ name: 'register' }">
                <a-button size="large" type="primary">Sign up</a-button>
              </router-link>
            </a-space>
            <a-menu :selectedKeys="[$route.name]" mode="horizontal" @click="({ key }) => $router.push({ name: key })"
                    class="header-menu">
              <a-menu-item key="announcement" class="topsize">
                <a-icon style="font-size:60px" type="home"/>
                Home
              </a-menu-item>
              <a-menu-item key="forum" class="topsize">
                <a-icon style="font-size:60px" type="team"/>
                Q&A Forum
              </a-menu-item>
            </a-menu>
            <a-space class="right">
              <!--          <a-input-search placeholder="search" style="width: 200px"/>-->
              <div v-if="$rootStore.userInf">
                <a-button size="large" type="primary" @click="() => $router.push({ name: 'addPost' })">
                  New
                </a-button>
              </div>
            </a-space>
          </div>
        </a-layout-header>
        <a-layout-content class="content">
          <div class="content-block">
            <router-view/>
          </div>
        </a-layout-content>
      </a-layout>
    </div>
  </div>
</template>
<script lang="ts">
import {Component, Vue} from 'vue-property-decorator';
import {CommonApi} from '@/apis/commonApi';

@Component
export default class App extends Vue {
  public created() {
    const {name} = this.$route;
    this.$rootStore.getUserInf()
      .then((res) => {
        if (res && name === 'home') {
          this.$router.push({name: 'announcement'});
        }
        // else if (!res && name !== 'login' && name !== 'register') {
        //   this.$router.push({name: 'login'});
        // }
      });
  }

  public async handleMineMenuClick({key}: { key: string }) {
    if (key === 'logout') {
      await CommonApi.logout();
      this.$rootStore.userInf = null;
      await this.$router.push({name: 'login'});
    } else {
      await this.$router.push({name: key});
    }
  }
}
</script>
<style lang="less" scoped>
#app {
  min-height: 100vh;
  background: white;
}

.header {
  padding: 0 16px;
  height: 48px;
  line-height: 48px;
  background: #fff;
  box-shadow: ~"0 1px 4px 0 rgb(0 21 41 / 12%)";
}

.header-content {
  max-width: 1200px;
  margin: 0 auto;
}

.header-menu {
  display: inline-block;
  margin-left: 24px;
}

.content-block {
  width: 1200px;
  min-height: 100px;
  margin: 16px auto;
  background: #fff;
  border-radius: 2px;
}
</style>
