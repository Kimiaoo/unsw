import {AuthInf, PostInf, ArtiDetailInf, ArtiInf, ShtArtInf} from '@/interfaces';
import moment from 'moment';
import request from '@/utils/request';
import { identity } from 'lodash';
//import {rootStore} from '@/stores/rootStore';

export function transArtiData(data: any): ArtiInf {
    return {
      ...data,
      id: data.id,
      time: moment(data.create_time),
      title: data.title,
      content: data.content,
      pic: data.post_image,
      auth_id: data.author,
      tags: data.first_category,
      userName: data.author_name,
      avatar: data.author_avatar,
      starNum: data.follow_nb,
      starFlag: data.is_like,
    };
}

export function transArtiListData(data: any): ArtiInf {
    return {
      ...data,
      id: data.id,
      title: data.title,
      content: data.content,
      time: moment(data.create_time),
      pic: data.post_image,
      auth_id: data.author,
      tags: data.first_category,
     // userName: data.author_name,
     // avatar: data.author_avatar,
      starNum: data.follow_nb,
    };
}
export function transAnmtData(data: any): ArtiInf {
  return {
    ...data,
    id: data.id,
    time: moment(data.create_time),
    title: data.title,
    content: data.content,
    pic: data.post_image,
    auth_id: data.author,
    tags: data.first_category,
    userName: data.post_username,
    avatar: data.post_username_avatar,
    starNum: data.follow_nb,
    starFlag: data.is_like,
  };
}
export function transSearchRes(data: any): ArtiInf {
  return {
    ...data,
      id: data.id,
      auth_id: data.author,
      userName: data.post_username,
      title: data.title,
      content: data.content,
      time: moment(data.create_time),
      sts: data.sts,
      starNum: data.follow_nb
  };
}
export function transMustSee(data: any): ShtArtInf {
  return {
    ...data,
      id: data.id,
      auth_id: data.author,
      title: data.title,
  };
}

export interface PostListRequest {
    keyWord?: string;
    category?: string;
    tag?: string;
    sort?: 'default' | 'top' | 'top_author';
}
export class AnmtApi {

    public static async getArtTopList(filter: PostListRequest): Promise<Array<ArtiInf>> {
        const res = await request.post('/api/posts/recom/', {post_num: 3});
        if (res.data.code === 200) {
          if (filter.sort === 'top') {
            return res.data.data.posts?.map(transArtiData);
          }
        }
        return [];
    }
    public static async getRecomList(): Promise<Array<ArtiInf>> {
      const res = await request.post('/api/posts/recom/', {post_num: 3});
      if (res.data.code === 200) {
          return res.data.data.posts?.map(transArtiData);
      }
      return [];
  }
    

    public static async getColnList():Promise<Array<ArtiInf>> {
      const res = await request.get('/api/posts/home/announcement/');
      return res.data.map(transAnmtData);
    }

    public static async getAnmtList(): Promise<Array<ArtiInf>> {
      const res = await request.get('/api/posts/home/announcement/');
      return res.data.map(transAnmtData);
    }

    public static async getArtList(): Promise<Array<ArtiInf>> {
      const res = await request.get('/api/posts/home/article/');
      return res.data.map(transAnmtData);
    }
    // use for tag searching 
    public static async getTagRes(keyWord: string): Promise<Array<ArtiInf>> {
      const res = await request.post('/api/posts/search/', {text: keyWord});
      if (res.data.code === 200) {
        return res.data.data.posts.map(transArtiData); 
      }
      return [];
    }

    public static async getTopList(filter: PostListRequest): Promise<Array<PostInf>> {
      const res = await request.post('/api/posts/recom/', {post_num: 3});
      if (res.data.code === 200) {
        if (filter.sort === 'top_author' || filter.sort === 'top' ) {
          return res.data.data.posts?.map(transArtiData);
        }
      }
      return [];
    }
    // use for anmt - mustsee
    public static async getMustsee(): Promise<Array<ShtArtInf>> {
      const res = await request.get('/api/posts/home/must_see/');
        return res.data.map(transMustSee);
    }
    // useful for Author vue
    public static async getAuthInf(user_id:number): Promise<AuthInf | null> {
      const res = await request.put('/api/user_center/search/user_info/', undefined, {params: {user_id}});
      if (res.data.code === 200) {
        const data = res.data.data || {};
        return {
          ...data,
          id: data.user_id,
          avatar: data.avatar,
          userName: data.username,
          email: data.email,
          info: data.personal_info
        };
      }
      if (res.data.code === 400) {
        const data = res.data.data || {};
        return {
          ...data,
          userName: 'User Not Exist',
        };
      }
      return null;
    }
    
    // Userful for author
    public static async getAuthList(author: number): Promise<Array<ArtiInf>> {
      const res = await request.put('/api/posts/author/', {author: author});
      if (res.data.code === 200) {
        return res.data.data.all_post.map(transArtiListData);
      }
      return [];
    }

    
    // get article detail, use for ArticleHome
    public static async getArtiDetail(id: number): Promise<ArtiDetailInf | null> {
      const res = await request.get('/api/posts/' + id + '/');
      const data = res.data;
      return {
        ...data,
        time: moment(data.create_time),
        tags: data.first_category,
        type: data.sts,
        userName: data.post_username,
        avatar: data.post_username_avatar,
        starNum: data.follow_nb,
        starFlag: data.is_like,
        auth_id: data.author,
      };
    }
}