import request from '@/utils/request';
import {getRole, removeRole, setRole} from '@/utils';
import {UserInf} from '@/interfaces';
import moment from 'moment';

export class CommonApi {
  public static async login(email: string, password: string): Promise<number | string> {
    const res = await request.post('/api/user_center/login/', {email, password});
    if (res.data.code === 200) {
      setRole(res.data.data?.status === 0 ? 'user' : 'organization');
      return 1;
    }
    return res.data.message;
  }

  public static async register(formData: Omit<UserInf, 'id'>): Promise<number | string> {
    const res = await request.post('/api/user_center/register/', {
      username: formData.userName,
      email: formData.email,
      password: formData.password,
      retype_new_password: formData.password,
      status: formData.role === 'user' ? 0 : 1,
    });
    setRole(formData.role);
    return res.data.code === 201 ? 1 : (res.data.username?.[0] || res.data.email?.[0]);
  }

  public static async logout(): Promise<number> {
    removeRole();
    await request.post('/api/user_center/logout/');
    return 1;
  }

  public static async getUserInf(): Promise<Omit<UserInf, 'password'> | null> {
    const res = await request.get('/api/user_center/info/');
    if (res.data.code === 200) {
      const data = res.data.data || {};
      return {
        ...data,
        id: data.user_id,
        avatar: data.avatar,
        userName: data.username,
        email: data.email,
        role: data?.status === 0 ? 'user' : 'export/organization',
        gender: data.gender === 0 ? 'unknown' : data.gender === 1 ? 'male' : data.gender === 2 ? 'female' : data.gender === 3 ? 'others' : undefined,
        birthday: data.birthday ? moment(data.birthday) : undefined,
        address: data.address,
        hobbies: data.hobby,
      };
    }
    return null;
  }

  public static async upload(pic: any): Promise<any> {
    const formData = new FormData();
    formData.append('image_file', pic);
    const res = await request.post('/api/upload/image/', formData);
    return res.data.image_file
  }
}
