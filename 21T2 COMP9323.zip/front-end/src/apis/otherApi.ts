import {TagInf} from '@/interfaces';
import request from "@/utils/request";

export class OtherApi {
  public static async getAllTag(): Promise<Array<TagInf>> {
    const res = await request.get('/api/posts/category/');
    if (res.data.code === 200) {
      return res.data.data.category.map((i: any) => ({ name: i, id: i}))
    }
    return [];
  }
}
