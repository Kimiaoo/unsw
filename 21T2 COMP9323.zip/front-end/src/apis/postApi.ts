import {PostDetailInf, PostInf} from '@/interfaces';
import moment from 'moment';
import request from '@/utils/request';
import {rootStore} from '@/stores/rootStore';

export function transPostData(data: any): PostDetailInf {
  return {
    ...data,
    time: moment(data.create_time),
    tags: data.first_category,
    type: data.sts,
    userName: data.author_name,
    avatar: data.author_avatar,
    starNum: data.follow_nb,
    starFlag: 0,
  };
}

export function transTopPostData(data: any): PostDetailInf {
  return {
    ...data,
    time: moment(data.create_time),
    tags: data.first_category,
    userName: data.author_name,
    avatar: data.author_avatar,
    starNum: data.follow_nb,
    starFlag: 0,
  };
}

export interface PostListRequest {
  keyWord?: string;
  category?: string;
  tag?: string;
  sort?: 'default' | 'top';
  sts?: "2";
}

export class PostApi {
  public static async addPost(data: Pick<PostInf, 'title' | 'type' | 'tags' | 'content' | 'pic'>): Promise<number> {
    const formData = new FormData();
    formData.append('title', data.title);
    formData.append('first_category', data.tags + '');
    formData.append('content', data.content);
    formData.append('sts', (data.type === 'announcement' ? 0 : data.type === 'article' ? 1 : 2) + "");
    formData.append('author', rootStore.userInf?.id + '');
    formData.append('post_image', data.pic + '');


    const res = await request.post('/api/posts/publish/', formData);

    //   const res = await request.post('/api/posts/publish/', {
    //   title: data.title,
    //   first_category: data.tags,
    //   sts: data.type,
    //   content: data.content,
    //   author: rootStore.userInf?.id,
    // });
    return res.data.code === 201 ? 1 : 0;
  }

  public static async getPostList(filter: PostListRequest): Promise<Array<PostInf>> {
    const res = await request.post('/api/posts/search/', {
      sts: filter.sts,
      first_category: filter.category,
      text: filter.keyWord
    })
    if (res.data.code === 200) {
      if (res.data.data.posts) {
        return res.data.data.posts?.map(transPostData);
      }
    }
    return [];
  }

  public static async getTopList(filter: PostListRequest): Promise<Array<PostInf>> {
    const res = await request.post('/api/posts/recom/', {post_num: 6});
    if (res.data.code === 200) {
      if (filter.sort === 'top') {
        return res.data.data.posts?.map(transTopPostData);
      }
    }
    return [];
  }

  public static async getPostDetail(id: number): Promise<PostDetailInf | null> {
    const res = await request.get('/api/posts/' + id + '/');
    const data = res.data;
    return {
      ...data,
      time: moment(data.create_time),
      tags: data.first_category,
      type: data.sts === 0 ? 'announcement' : data.sts === 1 ? 'article' : data.sts === 2 ? 'question' : null,
      userName: data.post_username,
      avatar: data.post_username_avatar,
      starNum: data.follow_nb,
      starFlag: data.is_like,
      comments: data.comments?.map((i: any) => {
        return {
          ...i,
          avatar: i.post_user_avatar,
          userName: i.post_username,
          time: moment(i.create_time),
          checked: i.post_checked,
        }
      })
    };
  }

  public static async replyPost(id: number, content: string): Promise<number> {
    const res = await request.post('/api/comments/publish/', {
      post: id,
      content,
      author: rootStore.userInf?.id,
    });
    return res.data.code === 201 ? 1 : 0;
  }
}
