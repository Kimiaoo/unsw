import {PostDetailInf, PostInf, UserInf} from '@/interfaces';
import moment from 'moment';
import request from '@/utils/request';
import {transPostData} from '@/apis/postApi';

export class UserApi {
  public static async modifyUserInf(data: Omit<UserInf, 'password'> | any): Promise<number> {
    console.log(data);
    const res = await request.put('/api/user_center/info/', {
      username: data.userName,
      gender: data.gender === 'unknown' ? 0 : data.gender === 'male' ? 1 : data.gender === 'female' ? 2 : data.gender === 'other' ? 3 : undefined,
      birthday: data.birthday?.format("YYYY-MM-DD"),
      address: data.address,
      hobby: data.hobbies,
      avatar: data.avatar
    });

    return res.data.code === 200 ? 1 : 0;
  }

  public static async modifyPassword(oldPassword: string, newPassword: string): Promise<number> {
    const res = await request.put('/api/user_center/change/', {
      old_password: oldPassword,
      new_password: newPassword,
      retype_new_password: newPassword
    });
    return res.data.code === 200 ? 1 : 0;
  }

  public static async getFavouritePostList(): Promise<Array<PostInf>> {
    const res = await request.get('/api/posts/favor/');
    if (res.data.code === 200) {
      return res.data.data?.posts_all?.map(transPostData);
    }
    return [];
  }

  public static async markPost(id: number, flag: boolean): Promise<number> {
    const res = await request.put('/api/posts/favor/', undefined, {params: {id}});
    if (res.data.code === 200) {
      return 1;
    }
    return 0;
  }
}
