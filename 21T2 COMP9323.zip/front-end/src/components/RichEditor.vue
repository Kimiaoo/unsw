<template>
  <quill-editor :options="editorOption" @change="(v) => $emit('change', v.html)"/>
</template>
<script lang="ts">
import { Component, Model, Vue as VueComponent } from 'vue-property-decorator';
import Vue from 'vue';
// @ts-ignore
import VueQuillEditor from 'vue-quill-editor';
// @ts-ignore
import { quillEditor } from 'vue-quill-editor';
import 'quill/dist/quill.core.css';
import 'quill/dist/quill.snow.css';
import 'quill/dist/quill.bubble.css';

Vue.use(VueQuillEditor);

@Component({
  components: {
    quillEditor,
  },
})
export default class RichEditor extends VueComponent {
  @Model('change')
  public value!: string;

  public get editorOption() {
    return {
      modules:{
        toolbar:[
          ['bold', 'italic', 'underline', 'strike'], //加粗，斜体，下划线，删除线
          ['blockquote', 'code-block'],  //引用，代码块
          [{ 'header': 1 }, { 'header': 2 }],  // 标题，键值对的形式；1、2表示字体大小
          [{ 'list': 'ordered'}, { 'list': 'bullet' }],  //列表
          [{ 'direction': 'rtl' }],    // 文本方向
        ]
      },
      theme:'snow',
    };
  }
}
</script>
<style lang="less">
.ql-editor {
  min-height: 300px;
}
</style>
