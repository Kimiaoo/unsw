import { Moment } from 'moment';

export interface UserInf {
  id: number;
  // avatar?: string;
  userName: string;
  email: string;
  password: string;
  role: 'user' | 'export/organization';
  gender?: 'male' | 'female' | 'unknown' | 'others';
  birthday?: Moment;
  address?: string;
  hobbies?: string;
  avatar?: Blob;
}

export interface PostInf {
  id: number;
  title: string
  tags: number;
  type: 'announcement' | 'article' | 'question';
  content: string;
  time: Moment;
  userName: string;
  avatar?: string;
  starNum: number;
  starFlag: boolean;
  pic?: Blob;
}

export interface CommentInf {
  id: number;
  content: string;
  time: Moment;
  userName: string;
  avatar?: string;
}

export interface PostDetailInf extends PostInf {
  comments: Array<CommentInf>;
}

export interface TagInf {
  id: number;
  name: string;
}


export interface AuthInf{
  id: number;
  userName: string;
  avatar?: string;
  email: string;
  info: string;
}

// short article info type
export interface ShtArtInf{
  id: number;
  auth_id: number;
  title: string;
}


export interface ArtiInf extends PostInf{
  auth_id: number,
}

export interface ArtiDetailInf  extends PostDetailInf{
  auth_id: number,
}