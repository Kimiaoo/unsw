import Vue from 'vue';
import App from './App.vue';
import router from './router';
import Antd from 'ant-design-vue';
import { RootStore, rootStore } from '@/stores/rootStore';
import RichEditor from '@/components/RichEditor.vue';
import { BootstrapVue, IconsPlugin } from 'bootstrap-vue'

import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
import 'ant-design-vue/dist/antd.less';
import '@/styles/index.less';



Vue.use(BootstrapVue)
Vue.use(IconsPlugin)

Vue.config.productionTip = false;

Vue.prototype.$rootStore = rootStore;

Vue.use(Antd);
Vue.component('rich-editor', RichEditor);

new Vue({
  router,
  render: h => h(App),
}).$mount('#app');

declare module 'vue/types/vue' {
  interface Vue {
    $rootStore: RootStore;
  }
}

