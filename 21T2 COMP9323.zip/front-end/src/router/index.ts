import Vue from 'vue';
import VueRouter, { RouteConfig } from 'vue-router';
import Login from '@/views/Login.vue';
import Announcement from '@/views/Announcement.vue';
import Register from '@/views/Register.vue';
import Profile from '@/views/Profile.vue';
import Favourite from '@/views/Favourite.vue';
import Forum from '@/views/Forum.vue';
import AddPost from '@/views/AddPost.vue';
import PostDetail from '@/views/PostDetail.vue';
import ArticleHome from '@/views/ArticleHome.vue';
import Author from '@/views/Author.vue';
import AnmtSec from '@/views/AnmtSec.vue';
import ArtiSec from '@/views/ArtiSec.vue';
import ColnSec from '@/views/ColnSec.vue';
import NotFound from '@/views/NotFound.vue';
import SearchTag from '@/views/SearchTag.vue';

Vue.use(VueRouter);

const routes: Array<RouteConfig> = [
  {
    name: 'login',
    path: '/login',
    component: Login,
  },
  {
    name: 'register',
    path: '/register',
    component: Register,
  },
  {
    name: 'profile',
    path: '/profile',
    component: Profile,
  },
  {
    name: 'favourite',
    path: '/favourite',
    component: Favourite,
  },
  {
    name: 'announcement',
    path: '/',
    component: Announcement,
  },
  {
    name: 'anmtsec',
    path: '/anmtsec',
    component: AnmtSec,
  },
  {
    name: 'colnsec',
    path: '/colnsec',
    component: ColnSec,
  },
  {
    name: 'artisec',
    path: '/artisec',
    component: ArtiSec,
    
  },
  {
    name: 'article_detail',
    path: '/article_detail/:id',
    component: ArticleHome,
    props: (route) => ({ id: Number(route.params.id), auth_id: Number(route.params.auth_id) }),
  },
  {
    name: 'author_home',
    path: '/author_home/:auth_id',
    component: Author,
    props: (route) => ({ auth_id: Number(route.params.auth_id) }),
  },
  {
    name: 'tag_res',
    path: '/tag_res/:kw',
    component: SearchTag,
    props: (route) => ({ kw: Number(route.params.kw) }),
  },
  {
    name: 'forum',
    path: '/forum',
    component: Forum,
  },
  {
    name: 'postDetail',
    path: '/forum/:id',
    component: PostDetail,
    props: (route) => ({ id: Number(route.params.id) }),
  },
  {
    name: 'addPost',
    path: '/addPost',
    component: AddPost,
  },
  // add Page Not Found, catch all 404
  {
    name: 'NotFound',
    path: '/:catchAll(.*)',
    component: NotFound,
  },
];

const router = new VueRouter({
  mode: 'hash',
  base: process.env.BASE_URL,
  routes,
  scrollBehavior (to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition
    } else {
      return { x: 0, y: 0 }
    }
  }
});


export default router;
