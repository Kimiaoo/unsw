import { UserInf } from '@/interfaces';
import { CommonApi } from '@/apis/commonApi';
import Vue from 'vue';

export class RootStore {
  public userInf: Omit<UserInf, 'password'> | null = null;

  public getUserInf() {
    return CommonApi.getUserInf()
      .then((res) => {
        if (res) {
          // console.log(res)
          this.userInf = res;
        }
        return res;
      });
  }
}

export const rootStore = Vue.observable(new RootStore());
