import { UserInf } from '@/interfaces';

const dataBaseName = '9323';
const dataBaseVersion = 1;
let db: IDBDatabase | undefined;
let dbRequest: IDBOpenDBRequest | undefined;

function createTables(dataBase: IDBDatabase) {
  // userInf table
  if (!dataBase.objectStoreNames.contains('userInf')) {
    const userInfStore = dataBase.createObjectStore('userInf', { keyPath: 'id', autoIncrement: true });
    userInfStore.createIndex('email', 'email', { unique: true });
  }
}
function getDataBase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!dbRequest) {
      dbRequest = indexedDB.open(dataBaseName, dataBaseVersion);
      dbRequest.onupgradeneeded = (event) => {
        db = dbRequest?.result;
        createTables(db!);
      }
    }
    if (dbRequest.readyState === 'done') {
      if (db) {
        resolve(db);
      } else {
        reject();
      }
    } else {
      dbRequest.onsuccess = () => {
        db = dbRequest?.result;
        resolve(db!);
      }
      dbRequest.onerror = () => {
        reject();
      }
    }
  });
}

function addUser(user: Omit<UserInf, 'id'>) {
  return new Promise( resolve => {
    getDataBase().then(database => {
      const result = database
        .transaction('userInf', 'readwrite')
        .objectStore('userInf')
        .add(user);
      result.onsuccess = () => {
        resolve(undefined);
      }
    });
  });
}

function getUserByEmail(email: string) {

}

getDataBase();
addUser({ userName: '33', email: 'ss', role: 'user', password: '233' })
