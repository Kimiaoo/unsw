export function setRole(role: string) {
  localStorage.setItem('role', role);
}

export function getRole(): string | null {
  return localStorage.getItem('role');
}

export function removeRole() {
  localStorage.removeItem('role');
}
