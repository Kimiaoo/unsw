import axios from 'axios';
import qs from 'qs';
import router from '@/router';
import { message } from 'ant-design-vue';

const instance = axios.create({
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json;charset=utf-8',
  },
});

instance.interceptors.request.use(config => {
  if (config.method === 'GET') {
    config.params = {
      ...config.params,
      t: new Date().valueOf(),
    }
  }

  config.paramsSerializer = params => {
    return qs.stringify(params, { arrayFormat: 'repeat', allowDots: true });
  };

  return config;
});

instance.interceptors.response.use(response => {
  return response;
}, error => {
  if (error.response.status === 401) {
    router.push({ name: 'login' });
  }
  if (error.response.status === 500) {
    message.error(error.response);
  }
  return Promise.reject(error).catch((e) => {});
});

export default instance;
