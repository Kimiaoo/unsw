<template>
  <div class="page-content" style="width: 1100px; margin: 0 auto; padding: 48px 0;">
    <a-form-model
      :model="form"
      :label-col="{ span: 2 }"
      :wrapper-col="{ span: 22 }"
      @submit="handleSubmit"
      @submit.native.prevent
      ref="form"
    >
      <a-form-model-item label="Title" prop="title" required>
        <a-input v-model="form.title"/>
      </a-form-model-item>
      <a-form-model-item label="Category" prop="tags" required>
        <a-select v-model="form.tags" style="width: 20%;">
          <a-select-option v-for="tag in tags" :key="tag.id">{{ tag.name }}</a-select-option>
        </a-select>
      </a-form-model-item>
      <a-form-model-item label="Type" prop="type" required>
        <a-radio-group v-model="form.type">
          <a-radio v-if="$rootStore.userInf.role === 'export/organization'" value="article">Article</a-radio>
          <a-radio v-if="$rootStore.userInf.role === 'export/organization'" value="announcement">Announcement</a-radio>
          <a-radio v-if="$rootStore.userInf.role === 'user'" value="question">Question</a-radio>
        </a-radio-group>
      </a-form-model-item>

      <a-form-model-item label="Cover" prop="pic">
        <a-upload name="avatar" :fileList="fileList" :customRequest="customRequest"
                  :remove="(f) => fileList.splice(fileList.indexOf(f), 1)" :show-upload-list="false">
          <a-avatar shape="square" :size="128" icon="user" :src="form.pic"/>
        </a-upload>
      </a-form-model-item>
      <a-form-model-item label="Body" prop="content" required>
        <rich-editor v-model="form.content"/>
      </a-form-model-item>
      <a-button type="primary" html-type="submit" class="right">Release</a-button>
    </a-form-model>
  </div>
</template>
<script lang="ts">
import {Component, Vue} from 'vue-property-decorator';
import {PostInf, TagInf} from '@/interfaces';
import {OtherApi} from '@/apis/otherApi';
import {FormModel} from 'ant-design-vue';
import {PostApi} from '@/apis/postApi';
import {CommonApi} from "@/apis/commonApi";

@Component
export default class AddPost extends Vue {
  public fileList: any[] = [];
  public form: Pick<PostInf, 'title' | 'type' | 'content' | 'pic'> & { tags: null | number } = {
    title: '',
    tags: null,
    type: 'announcement',
    content: '',
    pic: undefined,
  };
  public tags: Array<TagInf> = [];

  public created() {
    OtherApi.getAllTag()
      .then((res) => {
        this.tags = res;
      });

    if (this.$rootStore.userInf?.role === 'export/organization') {
      this.form.type = "article"
    } else {
      this.form.type = "question"
    }

  }

  public async customRequest(file: any) {
    console.log(file);
    this.fileList.push({
      uid: Math.random() + '',
      status: 'done',
      name: file.file.name,
      url: file.file,
    });
    this.form.pic = await CommonApi.upload(file.file);
  }

  public handleSubmit() {
    const {form} = this;
    (this.$refs.form as FormModel)?.validate(valid => {
      if (!valid) {
        return;
      }

      PostApi.addPost(form as Pick<PostInf, 'title' | 'type' | 'tags' | 'content'>)
        .then((res) => {
          if (res) {
            this.$message.success('release successful');
            this.$router.push({name: 'forum'})
          }
        });
    });
  }
}
</script>
<style lang="less" scoped>
</style>
