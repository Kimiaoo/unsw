<template>
  <div>
    <span><img src="../assets/wellbeing_3.png" alt="banner Img" class = "banner"></span>
    
    <div id="row">
      <h1 class="big_title"> <b-icon icon ='award' ></b-icon> MUST SEE</h1>
      <div v-for="mustsee in mustsees" :key ="mustsee.id" style="margin-top:20px" >
        <router-link :to =" { name:'article_detail', params: { id: mustsee.id, auth_id:mustsee.auth_id}}">
          <h3 class = "mustsee"> {{ mustsee.title }} </h3>
        </router-link>
      </div>
    </div>

    <div id="most_read">
        <h1 class="big_title"><b-icon icon='lightning'></b-icon> TRENDING TODAY</h1>
        <b-row style="padding:5px">
          <b-col sm="4" id="card" v-for="mostread in mostreads"  :key="mostread.id">
          <b-card  img-top>
          <router-link :to="{ name:'article_detail', params: { id: mostread.id, auth_id:mostread.id }}"> 
            <img :src="mostread.pic" alt="Image" id="img" style="height:200px; width:340px;">
            <div class = "anmt-content">
              <b-card-title id="title"> <b>
                 {{ mostread.title }} </b>
              </b-card-title>
              <b-card-subtitle v-html="mostread.content"  class ="overflow"></b-card-subtitle>
            </div>
            </router-link>
            
           <router-link :to="{ name:'author_home', params: { auth_id: mostread.auth_id }}">
            <div class="author_item">
              <b-avatar button :src="mostread.avatar"></b-avatar> 
                {{ mostread.userName }}<br>
            </div>
            </router-link>
          </b-card>  
          </b-col>
        </b-row>      
    </div>
  
    
  </div>
</template>

<script lang="ts">
//import {MostRead} from "@/views/Anmt/MostRead.vue";
import {Component, Vue} from 'vue-property-decorator';
import {TagInf, ArtiInf, ShtArtInf} from '@/interfaces';
import {AnmtApi} from '@/apis/anmtApi';
//import {PostApi} from '@/apis/postApi';
import {OtherApi} from '@/apis/otherApi';

@Component
export default class AnmtSec extends Vue {
  public mustsees: Array<ShtArtInf> = [];
  
  public tags: Array<TagInf> = [];
  public mostreads: Array<ArtiInf> = [];

  created(){
    OtherApi.getAllTag()
      .then((res) => {
        this.tags = res;
      });
  
    AnmtApi. getAnmtList()
      .then((res) => this.mostreads = res);
    AnmtApi.getMustsee()
      .then((res) => {
        this.mustsees = res;
      });
  }
}

</script>

<style scoped>
.banner{
    width: 1200px;
}
.big_title{
    margin: 10px 0 10px 0;
    background: lightgreen;
    border-bottom: 1px solid lightslategray;
}
h1:hover{
    background: mediumpurple;
}

#row{
    width:1200px;
    height:200px;
    margin-top:20px;
    margin-left:0;
    border: 2px solid green;
    border-radius: 3px;
    padding: 10px;
}

#most_read{
    margin-top: 20px;
    height: 520px;
    border: 2px solid green;
    border-radius: 3px;
    padding: 10px;
}
#card{
  height: 440px;
}
.anmt-content{
  margin-top: 10px;
  width: 350px;
  height: 140px;
}
.author_item{
  margin-top: 10px;
  height: 50px;
}

.overflow{ 
  width:350px;

  color: grey;

  overflow: hidden;

  text-overflow: ellipsis;

  display: -webkit-box;

  -webkit-line-clamp: 3;

  -webkit-box-orient: vertical;
}
</style>