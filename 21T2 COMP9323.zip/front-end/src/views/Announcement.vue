<template>
<div>
  <div id = "top">
    <h2 style="margin-top:50px">
      <span class="head_navi" @click="goAnmtSec"> ANNOUNCEMENT </span>
      <span class="head_navi" @click="goArtiSec"> ARTICLE & COLUMN </span>
      <span class="head_navi" @click="goColnSec"> RECOMMENDATION </span>
    </h2>
  </div>
  <div>
    <component v-bind:is="dynamicComponent"></component>
  </div>
</div>
</template>

<script>



import ArtiSec from "@/views/ArtiSec.vue";
import ColnSec from "@/views/ColnSec.vue";
import AnmtSec from "@/views/AnmtSec.vue";

export default {
  name: "Announcement.vue",
  components:{
    "anmtsec":AnmtSec,
    "colnsec":ColnSec,
    "artisec":ArtiSec,
  },
  
  data(){
    return {
      dynamicComponent: "anmtsec",
    }
  },
  
  methods:{
    goAnmtSec:function(){
      this.dynamicComponent = "anmtsec";
    },
    goArtiSec:function(){
      this.dynamicComponent = "artisec";
    },
    goColnSec: function(){
      this.dynamicComponent = "colnsec";
    },
  }
  
  
}

</script>

<style lang="less" scoped>
#top{
  font-family: Arial, Helvetica, sans-serif;
 
  height: 70px;
  text-align: center;
}

.head_navi{
  margin: 0 40px 30px 40px;
  border-radius: 3px;
  padding: 15px 20px 15px 20px;
  border: 2px solid green;
}

span:hover{
  background: mediumseagreen;
  color: white;
}
</style>