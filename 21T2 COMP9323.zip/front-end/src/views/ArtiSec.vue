<template>
  <div>
    <div class="sec top">
      <h1 class="big_title"> <b-icon icon ='pen' ></b-icon> HOT ARTICLES</h1>
      <b-row style="padding:5px">
        <b-col sm="4" id="card" v-for="hot in hots"  :key="hot.id">
        <b-card  img-top>
        <router-link :to="{ name:'article_detail', params: { id: hot.id, auth_id: hot.auth_id }}"> 
          <img :src="hot.pic" alt="Image" id="img" style="height:200px; width:350px;">
          <div class = "anmt-content">
            <b-card-title id="title">
              <b> {{ hot.title }} </b>
            </b-card-title>
            <b-card-subtitle v-html="hot.content" class="overflow"></b-card-subtitle>
          </div>
          </router-link>
          
          <router-link :to="{ name:'author_home', params: { auth_id: hot.auth_id }}">
          <div class="author_item" style="margin-top:10px">
            <b-avatar button :src="hot.avatar"></b-avatar> 
              {{ hot.userName }}<br>
          </div>
          </router-link>
        </b-card>  
        </b-col>
      </b-row>      
    </div>

    <div class="sec bottom"> 
      <h1 class="big_title"> <b-icon icon ='patch-check' ></b-icon> HOT AUTHOR</h1>
      <b-row  style="padding:5px;margin-top:20px">
      <b-col sm="4" id="card" v-for="coln in colns" :key="coln.id">
        <router-link :to="{name:'author_home', params: { auth_id: coln.author}}">
          <b-card class = "text-center">
           <b-img center thumbnail :src="coln.avatar" rounded="circle" style="max-height:200px; max-width:200px"></b-img>
            
            <div id="info_box">
              <h5>{{ coln.userName }} </h5>
              <h5 style="margin:5px 0 5px 0"><b-button size='sm' variant="outline-primary"> ENTER COLUMN </b-button></h5>
              <b-button variant="light" class="tag">{{ coln.tags }}</b-button>
            </div>
          </b-card>
        </router-link>
      </b-col>  
    </b-row>
    </div>

    
   
  </div>
</template>

<script lang="ts">
import {Component, Vue} from 'vue-property-decorator';
import {PostInf, ArtiInf} from '@/interfaces';
import {AnmtApi} from '@/apis/anmtApi';

@Component
export default class ArtiSec extends Vue {
  public hots: Array<ArtiInf> = [];

  public colns: Array<ArtiInf> = [];
    

  created(){
    //AnmtApi.getArtTopList({sort: 'top'})
    //  .then((res) => this.artis = res);

    AnmtApi.getArtList()
      .then((res) => this.hots = res);

    AnmtApi.getColnList()
      .then((res) => this.colns = res);
  }
}
</script>

<style scoped>
.big_title{
    margin: 10px 0 10px 0;
    background: lightgreen;
    border-bottom: 1px solid lightslategray;
}
h1:hover{
    background: lawngreen;
}

.sec{
    margin-top: 20px;
    
    border: 2px solid green;
    border-radius: 3px;
    padding: 10px;
}

.top{
  height: 530px;
}

.bottom{
  height: 450px;
}
#card{
  height: 440px;
}
.anmt-content{
  margin-top: 10px;
  height: 140px;
}
.author_item{
  height: 60px;
}

.overflow{ 

  width:350px;

  color: grey;
  
  overflow: hidden;

  text-overflow: ellipsis;

  display: -webkit-box;

  -webkit-line-clamp: 3;

  -webkit-box-orient: vertical;
}
</style>