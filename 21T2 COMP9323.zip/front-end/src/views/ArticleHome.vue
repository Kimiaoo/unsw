<template>
  <div id ="article">
    <b-container class="content_box" v-if="artiData.author">
      <router-link :to="{name:'author_home', params: { auth_id: artiData.author }}">
        <b-card img-left bg-variant="Default" text-variant="black">
          <b-row no-gutters>
            <b-col sm="1">
              <b-img :src="artiData.avatar" id="author_img" rounded="circle"></b-img>
            </b-col>
            <b-col sm="9">
              <b-card-body>
                
                <b-card-title> {{ artiData.userName }}</b-card-title>
                <small> 
                  <b-button pill size="sm" variant="success">Published at</b-button>
                  {{ artiData.time.format('LL') }} 
                </small>
                <!--<b-card-subtitle> {{ authData.info }}</b-card-subtitle !-->
              </b-card-body>
            </b-col>
          </b-row>
        </b-card>
      </router-link>
    </b-container>

    <b-container class="content_box">
      <b-card>
        <br>
        <b-card-title className="text-center"> 
          <b-button variant="outline-primary"  @click="markItem">
            <b-icon :icon="artiData.starFlag ? 'star-fill' : 'star'"></b-icon>  {{ artiData.starNum }}
          </b-button>
          {{artiData.title }}
        </b-card-title>
        
        <b-card-text v-html="artiData.content">
        </b-card-text>
        <br>
        <div style="margin-bottom:10px" >
          <b-button squared variant="outline-secondary" size="sm" class = "tag">{{ artiData.tags }}</b-button>
        </div>

        <br>
        <comment/>
      </b-card>

    </b-container>

  </div>
</template>

<script lang="ts">
import {Component, Prop, Vue, Watch} from 'vue-property-decorator';
import {ArtiDetailInf, AuthInf} from '@/interfaces';
import {AnmtApi} from '@/apis/anmtApi';
import {UserApi} from '@/apis/userApi';
//import {PostApi} from '@/apis/postApi';

@Component
export default class ArticleHome extends Vue {
  @Prop()
  public id!: number;

  public artiData:ArtiDetailInf | null = null;

  public _created() {
    this.getData();
  }

  @Watch('id', { immediate: true })
  public ic() {
    this._created();
  }

  public getData(){
    AnmtApi.getArtiDetail(this.id)
      .then((res) => {
        this.artiData = res;
    });
  }
  public async markItem() {
    if (this.artiData) {
      this.artiData.starFlag = !this.artiData.starFlag;
      await UserApi.markPost(this.id, this.artiData.starFlag);
      this.getData();
    }
  }

}
</script>

<style scoped>

#article{
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;

  color: #2c3e50;
}
.content_box {
  margin-bottom: 20px;
}

#author_img {
  width: 100px;
  height: 100px;
}

#content {
  text-align: justify;
  font-size: larger;
}

.tag{
  margin-right: 5px;
}

.user_name{
  font-weight: bold;
  font-size: large;
  text-align: left;
}
.single_comment{
  text-align: justify;
  margin-top: 5px;
}
</style>