<template>
  <div id ="author">
    <b-container class="p-4" >
      <b-card class = "text-center" id = "author_card">
        <b-img center thumbnail :src="authData.avatar" rounded="circle"></b-img>

        <div id="info_box">
          <h3>{{ authData.userName }} </h3>
          <h4>{{ authData.email }}</h4>
          <b-card-text id="desc"><br>{{ authData.info }} </b-card-text>
        </div>
      </b-card>
    </b-container>

    <b-container  class="p-4" id="left">
    
      <b-row>
      <b-card no-body class="overflow-hidden" style=" height: 200px" v-for="arti in artis" :key="arti.id">
        <router-link :to="{ name:'article_detail', params: { id: arti.id, auth_id:arti.auth_id }}">
        <b-card-title class="title">{{ arti.title }}</b-card-title>
        <b-card-subtitle class ="time"> Published at {{ arti.time.format('LL') }}, Starred {{ arti.starNum}} times</b-card-subtitle>
        <div class ="content" v-html="arti.content"></div>
        </router-link>
      </b-card>
  
      </b-row>

    </b-container>

  </div>

</template>

<script  lang="ts">
import {Component, Prop, Vue, Watch} from 'vue-property-decorator';
import {ArtiInf, AuthInf, ShtArtInf} from '@/interfaces';
import {AnmtApi} from '@/apis/anmtApi';

@Component
export default class Author extends Vue {
  @Prop()
  public auth_id!: number;

  public artis: Array<ArtiInf> = [];
 
  public authData: AuthInf | null = null;


  public _created() {
    this.getData();

    AnmtApi.getAuthList(this.auth_id)
      .then((res) => this.artis = res);
  }

  @Watch('auth_id', { immediate: true })
  public ic() {
    this._created();
  }
  
  public getData() {
    AnmtApi.getAuthInf(this.auth_id)
      .then((res) => {
        this.authData = res;
      });
  }
}


</script>

<style scoped>
#author{
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;

  color: #2c3e50;
  margin-top: 60px;
}
#left{
  width:98%;
}
#top5{
  padding-top: 20px;
  right:20px;
}
.overflow-hidden{
  margin-bottom: 10px;
}
.read-item{
  margin-top: 20px;
  margin-bottom: 20px;
  border-bottom: 1px dashed lightgrey;
}
.title{
  margin:10px 0 0 10px;
}
.time{
  color: grey;
  font-size: small;
  font-style: italic;
  margin: 5px 0 0 10px;
}
.content{
  text-align: justify;
  margin:5px 10px 0 10px;
}

#author_card{
  padding: 20px;
  border: 2px solid goldenrod;
}
#info_box{
  margin:20px;
  padding-top: 10px;
  color:black;
}
.tag{
  margin: 8px;
}
#desc{
  margin-top: 20px;
  font-family: Papyrus;
  font-style: italic;
  border-top: 1px solid darkgrey;
}
</style>