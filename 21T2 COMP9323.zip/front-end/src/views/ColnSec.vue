<template>
  <div>
    <div class = "whole">
      <img src="../assets/wellbeing_1.png" alt ="img" style="max-height:300px; margin-bottom:20px;">
      <br>
      <div class="sec">
      <b-row>
        <b-col sm="4" id="card" v-for="arti in artis" :key="arti.id">
          <b-card  img-top>
            <img :src="arti.pic" alt="Image" style="height:200px; width:340px;" >
            <div class = "anmt-content">
            <router-link :to="{ name:'article_detail', params: { id: arti.id, auth_id: arti.auth_id}}">
              <b-card-title id="title">
                 <b> {{ arti.title }} </b>
              </b-card-title>

              <div v-html="arti.content" class="overflow">
                {{ arti.tags }}
              </div>
            </router-link>
            </div>

            <div class="tag_item">

              <b-button variant="light" style="margin-top:10px">{{ arti.tags }}</b-button>
            </div>
            <template #footer>
              <small class="text-muted">Starred {{ arti.starNum }} times</small>
            </template>
          </b-card>
        </b-col>
      </b-row>
      </div>
      <br>

      <div class="sec">
      <b-row >
      <b-col sm="4" id="card" v-for="recom in recomList" :key="recom.id">
        <router-link :to="{name:'author_home', params: {auth_id: recom.author}}">
          <b-card class = "text-center">
            <img :src="recom.avatar" style="max-height:200px; max-width:200px">

            <div id="info_box">
              <h5>{{ recom.userName }}</h5>
              <!--p style="color: grey">{{ recom.articles }} Articles , {{ recom.followers }} Followers  <!-->
              <h5 style="margin:5px 0 5px 0"><b-button size='sm' variant="outline-primary"> ENTER COLUMN </b-button></h5>
              <b-button variant="light" class="tag">{{ recom.tags }}</b-button>
              <br>
            </div>
          </b-card>
        </router-link>
      </b-col>
    </b-row>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import {Component, Vue} from 'vue-property-decorator';
import {PostInf, ArtiInf} from '@/interfaces';
import {AnmtApi} from '@/apis/anmtApi';

@Component
export default class ColnSec extends Vue {
  public artis: Array<ArtiInf> = [];
  public recomList: Array<ArtiInf> = [];

  created(){
    //AnmtApi.getArtTopList({sort: 'top'})
    //  .then((res) => this.artis = res);
    AnmtApi.getRecomList()
      .then((res) => this.artis = res);

    AnmtApi.getRecomList()
      .then((res) => this.recomList = res);
  }
}
</script>

<style>
.whole{
    margin-top: 20px;
    height: 1300px;
    border: 2px solid green;
    border-radius: 3px;
    padding: 10px;
}

.sec{
  height: 490px;
}
#card{
  height: 440px;
}
.anmt-content{
  margin-top: 10px;
  height: 140px;
}
.author_item{
  height: 50px;
}
.line{
  margin-top: 20px;
}

.overflow{
  width:350px;

  color: grey;

  overflow: hidden;

  text-overflow: ellipsis;

  display: -webkit-box;

  -webkit-line-clamp: 3;

  -webkit-box-orient: vertical;
}
</style>
