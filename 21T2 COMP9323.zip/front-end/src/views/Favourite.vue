<template>
  <div class="page-content" style="width: 800px; margin: 0 auto; padding: 48px 0;">
    <h1>My favourite</h1>
    <a-list item-layout="horizontal" :data-source="list" row-key="id">
      <a-list-item slot="renderItem" slot-scope="item">
        <a-icon type="delete" slot="actions" @click="() => deleteItem(item.id)"/>
        <a-list-item-meta>
          <router-link slot="title" :to="{ name: 'postDetail', params: { id: item.id } }">{{ item.title }}</router-link>
        </a-list-item-meta>
      </a-list-item>
    </a-list>
  </div>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { PostInf } from '@/interfaces';
import { UserApi } from '@/apis/userApi';

@Component
export default class Favourite extends Vue {
  public list: Array<PostInf> = [];

  public created() {
    this.getList();
  }

  public getList() {
    UserApi.getFavouritePostList().then(res => this.list = res);
  }

  public deleteItem(id: number) {
    this.$confirm({
      title: 'Are you sure to delete this?',
      onOk: async () => {
        await UserApi.markPost(id, false);
        this.getList();
      },
    });
  }
}
</script>
<style lang="less" scoped>
h1 {
  font-size: 32px;
  font-weight: bold;
  margin-bottom: 16px;
}
</style>
