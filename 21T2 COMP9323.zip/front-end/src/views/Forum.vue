<template>
  <div class="page-content" style=" padding: 24px;">
    <a-carousel :autoplay="true" style="width: 100%; height: 300px;margin-bottom: 25px">
      <div><img src="../assets/forum1.png"/></div>
      <div><img src="../assets/forum2.png"/></div>
      <div><img src="../assets/forum3.png"/></div>
    </a-carousel>
    <div style="display: flex;">
      <div style="flex-grow: 1;">
        <a-row :gutter="48">
          <a-col :span="8">
            <a-select size="large" style="width: 100%;" placeholder="Type" v-model="filter.sts" @change="getList">
              <a-select-option value="0">Announcement</a-select-option>
              <a-select-option value="1">Article</a-select-option>
              <a-select-option value="2">Question</a-select-option>
            </a-select>
          </a-col>
          <a-col :span="8">
            <a-input-search size="large" placeholder="Key words" v-model="filter.keyWord" @search="getList"/>
          </a-col>
          <a-col :span="8">
            <a-select size="large" style="width: 100%;" placeholder="Category" v-model="filter.category"
                      @change="getList" allowClear>
              <a-select-option v-for="tag in tags" :key="tag.id">{{ tag.name }}</a-select-option>
            </a-select>
          </a-col>
        </a-row>
        <a-list item-layout="vertical" :data-source="dataSource" row-key="id">
          <a-list-item slot="renderItem" slot-scope="item">
            <a-list-item-meta>
            <span slot="title">
              <span>{{ item.userName }}</span>
              <span class="right" style="color: rgba(0, 0, 0, .65); font-size: 12px;">{{
                  item.time.format('LL')
                }}</span>
            </span>
              <a-avatar slot="avatar" :src="item.avatar" shape="square" :size="24" icon="user"/>
            </a-list-item-meta>
            <router-link :to="{ name: 'postDetail', params: { id: item.id } }" style="color: rgba(0, 0, 0, .65);">
              {{ item.title }}
            </router-link>
<!--            <div v-if="$rootStore.userInf">-->
<!--              <span slot="actions">-->
<!--                <a-icon type="heart" style="color: red;" :theme="item.starFlag ? 'filled' : undefined"/>-->
<!--                <span style="margin-left: 6px;">{{ item.starNum }}</span>-->
<!--              </span>-->
<!--            </div>-->
          </a-list-item>
        </a-list>
      </div>
      <div style="flex-basis: 300px; margin-left: 24px; border-left: 1px solid #e8e8e8; padding-left: 24px;">
        <h2>Recommend</h2>
        <router-link v-for="(item, index) in topList" :key="item.id"
                     :to="{ name: 'postDetail', params: { id: item.id } }" class="topics-item">
          <span style="font-size: 16px; margin-right: 6px; color: rgba(0, 0, 0, .85);">{{ index + 1 }}</span>
          <span style="color: rgba(0, 0, 0, .65);">{{ item.title }}</span>
        </router-link>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
import {Component, Vue} from 'vue-property-decorator';
import {PostInf, TagInf} from '@/interfaces';
import {PostApi, PostListRequest} from '@/apis/postApi';
import {UserApi} from '@/apis/userApi';
import {OtherApi} from '@/apis/otherApi';

@Component
export default class Forum extends Vue {
  public dataSource: Array<PostInf> = [];
  public topList: Array<PostInf> = [];
  public filter: PostListRequest = {};
  public tags: Array<TagInf> = [];

  public created() {
    PostApi.getTopList({sort: 'top'})
      .then((res) => this.topList = res);
    OtherApi.getAllTag()
      .then((res) => {
        this.tags = res;
      });
    this.getList();
  }

  public getList() {
    PostApi.getPostList({...this.filter, sort: 'default'})
      .then((res) => this.dataSource = res);
  }

  public markItem(item: PostInf) {
    item.starFlag = !item.starFlag;
    UserApi.markPost(item.id, item.starFlag);
  }
}
</script>
<style lang="less" scoped>
h2 {
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 12px;
  text-align: center;
  background-color: WhiteSmoke;
  padding: 20px 0px 20px;
}

.topics-item {
  display: block;
  margin-bottom: 12px;
}
</style>

