<template>
  <div id = "header">
    <h1>This is a temporary header on the top.</h1>
  </div>
</template>

<script>
export default {
  name: "Header.vue"
}
</script>

<style scoped>
#header{
  background: aquamarine;
  height: 50px;
}
</style>