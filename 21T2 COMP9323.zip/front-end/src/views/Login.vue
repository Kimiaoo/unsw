<template>
  <div>
    <div class="mid">
      <div class="page-content login-card">
        <h1>Login</h1>
        <a-form-model
          :model="form"
          :label-col="{ span: 4 }"
          :wrapper-col="{ span: 20 }"
          @submit="handleSubmit"
          @submit.native.prevent
          ref="form"
        >
          <a-form-model-item label="Email" prop="email" :rules="[{ type: 'email' }]">
            <a-input size="large" v-model="form.email"/>
          </a-form-model-item>
          <a-form-model-item label="Password" prop="password" :rules="[{ min: 8 }]">
            <a-input size="large" v-model="form.password" type="password"/>
          </a-form-model-item>

          <a-space size="large" style="margin-top: 10px">
            <!--            <a>Forgot password?</a>-->
            <router-link :to="{ name: 'register' }">Don't have an account?</router-link>
          </a-space>
          <a-button size="large" type="primary" html-type="submit" class="right"
                    :disabled="!form.email || !form.password">
            Login
          </a-button>

        </a-form-model>
      </div>
    </div>

    <div class="p">
      <img src="../assets/forum1.png" style="margin: 0 auto;">
    </div>
    <footer class="footer">
      <div class="container">
        <div class="copyright">
          &copy; Copyright <strong><span>Group21</span></strong>. All Rights Reserved
        </div>
      </div>
    </footer>

  </div>
</template>
<script lang="ts">
import {Component, Vue} from 'vue-property-decorator';
import {CommonApi} from '@/apis/commonApi';
import {FormModel} from 'ant-design-vue';

@Component
export default class Login extends Vue {
  public form = {email: '', password: ''};

  public handleSubmit() {
    const {email, password} = this.form;
    (this.$refs.form as FormModel)?.validate(valid => {
      if (!valid) {
        return;
      }

      CommonApi.login(email, password)
        .then(async (res) => {
          if (res === 1) {
            await this.$rootStore.getUserInf();
            this.$router.push({name: 'announcement'});
          } else {
            this.$message.error('Email or password error!');
          }
        });
    });

  }
}
</script>
<style lang="less" scoped>
.login-card {
  margin: 0 auto;
  padding: 48px 0 80px;
  width: 500px;
}

h1 {
  text-align: center;
  font-size: 38px;
  font-weight: bold;
  margin-bottom: 48px;
}

.p {
  margin-top: 50px;
}

.footer {
  padding: 20px 0 20px;
  margin-top: 20px;
  background-color: WhiteSmoke;
  width: 1152px;
}

.copyright {
  text-align: center;
}

.form {
  font-size: 60px;
}

.mid {
  width: 1152px;
  background-color: WhiteSmoke;
}
</style>
