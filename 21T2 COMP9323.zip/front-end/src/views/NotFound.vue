<template>
    <div>
        <h2>404</h2>
        <h5>Page Not Found</h5>
    </div>
  
</template>

<script>
export default {

}
</script>

<style>

</style>