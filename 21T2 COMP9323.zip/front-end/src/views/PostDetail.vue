<template>
  <div class="page-content" style="display: flex; padding: 24px;">
    <div v-if="detailData" style=" flex-grow: 1;">
      <div style="display: flex;">
        <div style="text-align: center; flex-basis: 100px;">
          <a-avatar slot="avatar" :src="detailData.avatar" shape="square" :size="90" style="margin-right: 40px"
                    icon="user"/>
          <div style="margin-top: 8px;margin-right: 40px">{{ detailData.userName }}</div>
        </div>
        <div style="flex-grow: 1;">
          <h3 style="display: inline-block; font-weight: 600;font-size: xxx-large;margin-bottom: 20px">
            {{ detailData.title }}</h3>
          <div v-if="$rootStore.userInf">
            <span class="right" @click="markItem">
              <a-icon type="heart" style="color: red;margin-left: 5px"
                      :theme="detailData.starFlag ? 'filled' : undefined"/>
              <span style="margin-left: 6px; vertical-align: -.2em;">{{ detailData.starNum }}</span>
            </span>
          </div>
          <div v-html="detailData.content"></div>
        </div>
      </div>
      <div v-if="detailData.type === 'question'">
        <a-list :header="`${detailData.comments.length} comments`" item-layout="horizontal"
                :data-source="detailData.comments">
          <a-list-item slot="renderItem" slot-scope="item">
            <a-comment style="width: 100%;">
              <span slot="author">{{ item.userName }}<a-tag v-if="item.checked"
                                                            style="margin-left: 6px;">Authenticated</a-tag></span>
              <a-avatar slot="avatar" :src="item.avatar" shape="square" :size="40" icon="user"/>
              <p slot="content" v-html="item.content"></p>
              <a-tooltip slot="datetime" :title="item.time.format('YYYY-MM-DD HH:mm:ss')">
                <span class="right">{{ item.time.fromNow() }}</span>
              </a-tooltip>
            </a-comment>
          </a-list-item>
        </a-list>
        <a-divider/>
        <div v-if="$rootStore.userInf && $rootStore.userInf.role === 'export/organization'">
          <rich-editor v-model="replyContent"/>
          <a-button type="primary" @click="replyPost" style="margin-top: 8px;">Submit
          </a-button>
        </div>
      </div>
    </div>
    <div
      style="flex-basis: 300px; margin-top: 142px; margin-left: 24px; border-left: 1px solid #e8e8e8; padding-left: 24px;">
      <h2>Recommend</h2>
      <router-link v-for="(item, index) in topList" :key="item.id"
                   :to="{ name: 'postDetail', params: { id: item.id } }" class="topics-item">
        <span style="font-size: 16px; margin-right: 6px; color: rgba(0, 0, 0, .85);">{{ index + 1 }}</span>
        <span style="color: rgba(0, 0, 0, .65);">{{ item.title }}</span>
      </router-link>
    </div>
  </div>
</template>
<script lang="ts">
import {Component, Prop, Vue, Watch} from 'vue-property-decorator';
import {PostDetailInf, PostInf} from '@/interfaces';
import {PostApi} from '@/apis/postApi';
import {UserApi} from '@/apis/userApi';

@Component
export default class PostDetail extends Vue {
  @Prop()
  public id!: number;

  public detailData: PostDetailInf | null = null;
  public topList: Array<PostInf> = [];
  public replyContent = '';

  public _created() {
    this.getData();
    PostApi.getTopList({sort: 'top'})
      .then((res) => this.topList = res);
  }


  @Watch('id', {immediate: true})
  public ic() {
    this._created();
  }

  public getData() {
    PostApi.getPostDetail(this.id)
      .then((res) => {
        this.detailData = res;
      });
  }

  public async markItem() {
    if (this.detailData) {
      this.detailData.starFlag = !this.detailData.starFlag;
      await UserApi.markPost(this.id, this.detailData.starFlag);
      this.getData();
    }
  }

  public async replyPost() {
    await PostApi.replyPost(this.id, this.replyContent);
    this.$message.success('comment successful');
    location.reload()
    // this.getData();
  }

}
</script>
<style lang="less" scoped>
h2 {
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 12px;
}

.topics-item {
  display: block;
  margin-bottom: 12px;
}
</style>
