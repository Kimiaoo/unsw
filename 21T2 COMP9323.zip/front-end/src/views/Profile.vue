<template>
  <div class="page-content" style="width: 800px; margin: 0 auto; padding: 48px 0;">
    <a-form-model
        v-if="form"
        :model="form"
        :label-col="{ span: 3 }"
        :wrapper-col="{ span: 21 }"
        @submit="handleSubmit"
        @submit.native.prevent
        ref="form"
    >
      <div v-if="$rootStore.userInf" style="display: flex;">
        <div style="text-align: center; flex-basis: 200px; margin-right: 16px; padding: 32px 0;">
          <a-upload name="avatar" :customRequest="customRequest" :show-upload-list="false">
            <!--            <a-avatar shape="square" :size="128" icon="user" :src="$rootStore.userInf.avatar"/>-->
            <a-avatar shape="square" :size="128" icon="user" :src="form.avatar"/>
          </a-upload>
        </div>
        <div style="flex-grow: 1;">
          <a-form-model-item label="User id">
            <a-input size="large" v-model="form.id" disabled/>
          </a-form-model-item>
          <a-form-model-item label="User Name" prop="userName">
            <a-input size="large" v-model="form.userName"/>
          </a-form-model-item>
          <a-form-model-item label="E-mail" prop="email">
            <a-input size="large" v-model="form.email" disabled/>
          </a-form-model-item>
          <a-form-model-item label="You are now logged in as" prop="role" :label-col="{ span: 7 }"
                             :wrapper-col="{ span: 17 }">
            <a-input size="large" v-model="form.role" disabled/>
          </a-form-model-item>
          <a-button class="right" @click="() => visible = true">change password</a-button>
        </div>
      </div>
      <a-form-model-item label="Gender" prop="gender">
        <a-radio-group v-model="form.gender">
          <a-radio value="unknown">unknown</a-radio>
          <a-radio value="male">Male</a-radio>
          <a-radio value="female">Female</a-radio>
          <a-radio value="others">others</a-radio>
        </a-radio-group>
      </a-form-model-item>
      <a-form-model-item label="Birthday" prop="birthday">
        <a-date-picker size="large" v-model="form.birthday"/>
      </a-form-model-item>
      <a-form-model-item label="Address" prop="address">
        <a-input size="large" v-model="form.address"/>
      </a-form-model-item>
      <a-form-model-item label="Hobbies" prop="hobbies">
        <a-textarea size="large" v-model="form.hobbies"/>
      </a-form-model-item>
      <a-button size="large" type="primary" html-type="submit" class="right">Confirm</a-button>
    </a-form-model>
    <a-modal v-model="visible" title="Change password" @ok="handleModifyPassword">
      <a-form-model
          :model="passwordForm"
          :label-col="{ span: 8 }"
          :wrapper-col="{ span: 16 }"
          @submit.native.prevent
          ref="passwordForm"
      >
        <a-form-model-item label="Old password" prop="oldPassword" :rules="passwordRule" required>
          <a-input v-model="passwordForm.oldPassword" type="password"/>
        </a-form-model-item>
        <a-form-model-item label="New password" prop="password" :rules="passwordRule" required>
          <a-input v-model="passwordForm.password" type="password">
            <a-tooltip slot="suffix">
              <a-icon type="question-circle" style="color: rgba(0,0,0,.45); cursor: pointer;"/>
              <div slot="title">
                <div>Your password must be at least 8 characters long and only contain characters from the following
                  categories.
                </div>
                <div>· Uppercase letters e.g. A B C ...</div>
                <div>· Lowercase letters e.g. a b c ...</div>
                <div>· Numbers e.g. 0 1 2 3 4 5 6 7 8 9</div>
              </div>
            </a-tooltip>
          </a-input>
        </a-form-model-item>
        <a-form-model-item label="Re-type password" prop="confirmPassword" :rules="passwordRule" required>
          <a-input v-model="passwordForm.confirmPassword" type="password"/>
        </a-form-model-item>
      </a-form-model>
    </a-modal>

    <div style="margin-top: 150px">
      <video width="500" height="300" style="float: left" controls>
        <source src="movie.ogg" type="video/ogg"/>
        <source src="../assets/thanks.mp4" type="video/mp4"/>
        Your browser does not support the video tag.
      </video>
      <img width="290" height="330" style="float: right" src="../assets/QR-code.png"/>
    </div>
  </div>
</template>
<script lang="ts">
import {Component, Vue} from 'vue-property-decorator';
import {PostInf, UserInf} from '@/interfaces';
import {CommonApi} from '@/apis/commonApi';
import {FormModel} from 'ant-design-vue';
import {UserApi} from '@/apis/userApi';

@Component
export default class Profile extends Vue {
  public fileList: any[] = [];
  public visible = false;
  public form: Omit<UserInf, 'password'> | null = null;
  public passwordForm = {oldPassword: '', password: '', confirmPassword: ''};
  public passwordRule = [
    {pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/, message: 'Incorrect password format'},
  ]

  public created() {
    CommonApi.getUserInf()
        .then((res) => {
          this.form = res;
        });
  }

  private async customRequest(file: any) {
    this.fileList.push({
      uid: Math.random() + '',
      status: 'done',
      name: file.file.name,
      url: file.file,
    });
    (this.form as any).avatar = await CommonApi.upload(file.file);
  }

  public handleSubmit() {
    const {form} = this;
    (this.$refs.form as FormModel)?.validate(valid => {
      if (!valid) {
        return;
      }

      UserApi.modifyUserInf(form as Omit<UserInf, 'password'>)
          .then((res) => {
            if (res) {
              this.$message.success('Modify successful');
              location.reload();
            }
          });
    });
  }

  public handleModifyPassword() {
    const {oldPassword, password, confirmPassword} = this.passwordForm;
    (this.$refs.passwordForm as FormModel)?.validate(valid => {
      if (!valid) {
        return;
      }

      if (password !== confirmPassword) {
        this.$message.error('Two passwords are inconsistent');
        return;
      }

      UserApi.modifyPassword(oldPassword, password)
          .then((res) => {
            if (res) {
              this.$message.success('Modify successful');
              this.visible = false;
              this.$router.push({ name: 'announcement' });
              location.reload();
            } else {
              this.$message.error('Modify failed');
            }
          });
    });
  }
}
</script>
<style lang="less" scoped>
</style>
