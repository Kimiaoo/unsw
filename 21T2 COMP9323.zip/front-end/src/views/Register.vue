<template>
  <div>
    <div class="mid">
      <div class="page-content register-box">
        <h1>Register</h1>
        <a-form-model
          :model="form"
          :label-col="{ span: 6 }"
          :wrapper-col="{ span: 18 }"
          @submit="handleSubmit"
          @submit.native.prevent
          ref="form"
        >
          <a-form-model-item label="User Name" prop="userName" required>
            <a-input size="large" v-model="form.userName"/>
          </a-form-model-item>
          <a-form-model-item label="Email" prop="email" :rules="[{ type: 'email' }]" required>
            <a-input size="large" v-model="form.email"/>
          </a-form-model-item>
          <a-form-model-item label="Password" prop="password" :rules=passwordRule required>
            <a-input size="large" v-model="form.password" type="password">
              <a-tooltip slot="suffix">
                <a-icon type="question-circle" style="color: rgba(0,0,0,.45); cursor: pointer;"/>
                <div slot="title">
                  <div>Your password must be at least 8 characters long and only contain characters from the following
                    categories.
                  </div>
                  <div>· Uppercase letters e.g. A B C ...</div>
                  <div>· Lowercase letters e.g. a b c ...</div>
                  <div>· Numbers e.g. 0 1 2 3 4 5 6 7 8 9</div>
                </div>
              </a-tooltip>
            </a-input>
          </a-form-model-item>
          <a-form-model-item label="Re-type Password" prop="confirmPassword" required>
            <a-input size="large" v-model="form.confirmPassword" type="password"/>
          </a-form-model-item>
          <a-form-model-item label="Who you are" prop="role" required>
            <a-radio-group v-model="form.role">
              <a-radio value="user">User</a-radio>
              <a-radio value="organization">Export/Organization</a-radio>
            </a-radio-group>
            <a-tooltip>
              <a-icon type="question-circle" style="color: rgba(0,0,0,.45); cursor: pointer;"/>
              <div slot="title">
                <div>If you want register as export or organization, please select “export/organization” and then use
                  your register email to send an email with identification materials to 203760028@qq.com.
                </div>
              </div>
            </a-tooltip>
          </a-form-model-item>
          <a-form-model-item :wrapperCol="{ offset: 6 }">
            <a-button size="large" type="primary" html-type="submit" class="sign">Sign up</a-button>
          </a-form-model-item>
        </a-form-model>
      </div>
    </div>

    <div class="p">
      <img src="../assets/forum1.png"/>
    </div>
    <footer class="footer">
      <div class="container">
        <div class="copyright">
          &copy; Copyright <strong><span>Group21</span></strong>. All Rights Reserved
        </div>
      </div>
    </footer>

  </div>
</template>
<script lang="ts">
import {Component, Vue} from 'vue-property-decorator';
import {FormModel} from 'ant-design-vue';
import {CommonApi} from '@/apis/commonApi';
import {UserInf} from '@/interfaces';

@Component
export default class Register extends Vue {
  public form: Omit<UserInf, 'id'> & { confirmPassword: string, agree: boolean } = {
    userName: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'user',
    agree: false,
  };
  public passwordRule = [
    {pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{6,}$/, message: 'Incorrect password format'},
  ]

  public handleSubmit() {
    const {form} = this;
    (this.$refs.form as FormModel)?.validate(valid => {
      if (!valid) {
        return;
      }

      if (form.password !== form.confirmPassword) {
        this.$message.error('Two passwords are inconsistent');
        return;
      }

      CommonApi.register(form)
        .then(async (res) => {
          if (res === 1) {
            await this.$rootStore.getUserInf();
            this.$router.push({name: 'announcement'});
          } else {
            this.$message.error(res + '');
          }
        });
    });
  }
}
</script>
<style lang="less" scoped>
.register-box {
  margin: 0 auto;
  padding: 48px 0 40px;
  width: 600px;
}

h1 {
  text-align:center;
  font-size: 38px;
  font-weight: bold;
  margin-bottom: 48px;
  margin-left: 100px;
}
.p{
  margin-top: 5px;
}
.footer{
  padding: 20px 0 20px;
  margin-top: 20px;
  background-color:WhiteSmoke;
  width: 1152px;
}
.copyright{
  text-align:center;
}
.sign{
  margin-left: 360px;
}
.mid{
  width: 1152px;
  background-color:WhiteSmoke;
}
</style>
