<template>
  <div>
      
      <b-container class="p-4">
            <b-row>
              <b-col sm="3">
                  <b-card class="cards">
                      <h1 style="text-align: right"><b>TAG <i> #  {{ this.$route.params.kw }}  #</i></b> </h1>
                  </b-card>
              </b-col>
              <b-col sm="9">
                <b-card class="cards">
                    <div v-for="art in artis" :key="art.id" style="heigh: 300px; border-bottom:1px solid gray"> 
                        <!-- <b-card-title> <b-badge :variant="badge_color">{{ category }}</b-badge></b-card-title> !-->
                        <b-card-title>{{ arti.title }}</b-card-title>
                        <b-card-subtitle> By {{ arti.userName}}, Published at {{ arti.time.format('LL') }} </b-card-subtitle>
                        <p :v-html="art.content"> </p>
                    </div>
                     
                </b-card>

                  
                  
              </b-col>
            </b-row>
      </b-container>
  </div>
</template>

<script lang="ts">
import {Component, Prop, Vue, Watch} from 'vue-property-decorator';
import {ArtiInf} from '@/interfaces';
import {AnmtApi} from '@/apis/anmtApi';

@Component
export default class SearchTag extends Vue {
  @Prop()
  public kw!: string;
   public artis: Array<ArtiInf> = [];

  public _created() {
    this.getData();
  }
  @Watch('kw', { immediate: true })
  public ic() {
    this._created();
  }

  public getData(){
    AnmtApi.getTagRes(this.kw)
      .then((res) => {
        this.artis = res;
    });
  }
}
</script>

<style>
.cards{
    border: 2px solid orange;
    height: 500px;
}
</style>