-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: django_vue_db
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

DROP Database IF EXISTS `django_vue_db`;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`django_vue_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `django_vue_db`;

/*Table structure for table `auth_group` */

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add content type',4,'add_contenttype'),(14,'Can change content type',4,'change_contenttype'),(15,'Can delete content type',4,'delete_contenttype'),(16,'Can view content type',4,'view_contenttype'),(17,'Can add session',5,'add_session'),(18,'Can change session',5,'change_session'),(19,'Can delete session',5,'delete_session'),(20,'Can view session',5,'view_session'),(21,'Can add User management',6,'add_user'),(22,'Can change User management',6,'change_user'),(23,'Can delete User management',6,'delete_user'),(24,'Can view User management',6,'view_user'),(25,'Can add Post management',7,'add_posts'),(26,'Can change Post management',7,'change_posts'),(27,'Can delete Post management',7,'delete_posts'),(28,'Can view Post management',7,'view_posts'),(29,'Can add User Blog Collections',8,'add_userblogcollections'),(30,'Can change User Blog Collections',8,'change_userblogcollections'),(31,'Can delete User Blog Collections',8,'delete_userblogcollections'),(32,'Can view User Blog Collections',8,'view_userblogcollections'),(33,'Can add comment',9,'add_comment'),(34,'Can change comment',9,'change_comment'),(35,'Can delete comment',9,'delete_comment'),(36,'Can view comment',9,'view_comment'),(37,'Can add file management',10,'add_filesupload'),(38,'Can change file management',10,'change_filesupload'),(39,'Can delete file management',10,'delete_filesupload'),(40,'Can view file management',10,'view_filesupload');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments_comment`
--

DROP TABLE IF EXISTS `comments_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments_comment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` longtext NOT NULL,
  `create_time` datetime(6) NOT NULL,
  `author_id` int NOT NULL,
  `post_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_comment_author_id_334ce9e2_fk_users_user_id` (`author_id`),
  KEY `comments_comment_post_id_96a9ac05_fk_posts_id` (`post_id`),
  CONSTRAINT `comments_comment_author_id_334ce9e2_fk_users_user_id` FOREIGN KEY (`author_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `comments_comment_post_id_96a9ac05_fk_posts_id` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments_comment`
--

LOCK TABLES `comments_comment` WRITE;
/*!40000 ALTER TABLE `comments_comment` DISABLE KEYS */;
INSERT INTO `comments_comment` VALUES (1,'<p>get a private script from your GP, Gardasil 9, $180 per dose, x2</p><p>&nbsp;</p><p>the age matters, have a chat with the doctor if &gt;27 years old already</p><p>https://immunisationhandbook.health.gov.au/vaccines/gardasil-9</p><p>&nbsp;</p><p>There is another brand, cervarix for female up to 46 years old ($140 each) forgot if 2 or 3 doses</p><p>&nbsp;</p><p>https://immunisationhandbook.health.gov.au/vaccines/cervarix</p>','2021-08-09 07:58:46.096732',3,20),(2,'<p>all up to options .. Medicare (goverment) pays x amount .. any costs above are out of pocket if you have insurance the out of pocket can be $0 or $$$ depending on doctor .. ie Medibank can give you a list of there doctors / surgeons / etc so your not paying extra</p><p>&nbsp;</p>','2021-08-09 07:59:43.685775',3,19),(3,'<p>Extras only = no rebate</p><p>&nbsp;</p><p>Private hospital cover = rebate</p><p>It’s a section on your tax return, you’ll see it when you do the return. Many insurers provide the ATO with the data and it preloads.</p>','2021-08-09 08:00:26.203435',3,18),(4,'<p>I tried to read your link and search other websites. I was on a NSW govt site and clicked on a bit and it talked about Victorian compensation.</p><p>I think the compensation is still to be worked out, it sounds like the federal government compensation package they gave to Victoria will be given to NSW? Any one who has lost their job due to the lockdown will get $500 per week provided they don\'t have over 10k in liquid assets etc. Basically for casual staff????????</p><p>$500 does not seem enough expecially if you earn over $500.</p><p>&nbsp;</p><p>But I would say we have to listen for announcements. After all NSW was only locked down a day or two ago. Let\'s hope NSW compensation is better than Victorians.</p>','2021-08-09 08:00:45.914666',3,17),(5,'<p>No worries, happy to help.</p><p>It makes sense you are bored- and it does take a while to adjust. It\'s unfortunate you\'re not getting work yet, but have a think in your last job if a person came on for 6 months. I\'m not sure you\'d be giving them planning facilitation or large budgets to manage and so forth. But you are right – some managers just aren\'t great at delegating and adapting to the skill level of their employees. I\'ve only had one or two good managers (possibly 3) who could probably understand tasks and delegations, skills, and motivational conversations. I\'m starting to learn those skills myself.</p>','2021-08-09 08:01:12.356421',3,16),(6,'<p>Yes leave now if you can for the private sector. Otherwise you\'ll get more and more bored and then get more and more stuck forever in government.</p><p>&nbsp;</p><p>You\'ll make more money in private too and do proper stuff.</p><p>&nbsp;</p><p>Join the easy government life when you\'re in your 40s / 50s and want to take it easy.</p>','2021-08-09 08:02:46.157662',4,20),(7,'<p>It\'s insurance, it wouldn\'t be profitable if everyone didn\'t pay for more than what they need.</p><p>&nbsp;</p><p>Really the main thing that they cover is the hospital stay.</p>','2021-08-09 08:04:14.615917',5,19);
/*!40000 ALTER TABLE `comments_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_users_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(9,'comments','comment'),(10,'common','filesupload'),(4,'contenttypes','contenttype'),(7,'posts','posts'),(8,'posts','userblogcollections'),(5,'sessions','session'),(6,'user_center','user');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2021-08-09 04:41:01.536010'),(2,'contenttypes','0002_remove_content_type_name','2021-08-09 04:41:01.582197'),(3,'auth','0001_initial','2021-08-09 04:41:01.715768'),(4,'auth','0002_alter_permission_name_max_length','2021-08-09 04:41:01.746140'),(5,'auth','0003_alter_user_email_max_length','2021-08-09 04:41:01.754792'),(6,'auth','0004_alter_user_username_opts','2021-08-09 04:41:01.762707'),(7,'auth','0005_alter_user_last_login_null','2021-08-09 04:41:01.776093'),(8,'auth','0006_require_contenttypes_0002','2021-08-09 04:41:01.780816'),(9,'auth','0007_alter_validators_add_error_messages','2021-08-09 04:41:01.790308'),(10,'auth','0008_alter_user_username_max_length','2021-08-09 04:41:01.798599'),(11,'auth','0009_alter_user_last_name_max_length','2021-08-09 04:41:01.810098'),(12,'auth','0010_alter_group_name_max_length','2021-08-09 04:41:01.828898'),(13,'auth','0011_update_proxy_permissions','2021-08-09 04:41:01.837855'),(14,'auth','0012_alter_user_first_name_max_length','2021-08-09 04:41:01.854270'),(15,'user_center','0001_initial','2021-08-09 04:41:02.026608'),(16,'admin','0001_initial','2021-08-09 04:41:02.088747'),(17,'admin','0002_logentry_remove_auto_add','2021-08-09 04:41:02.099202'),(18,'admin','0003_logentry_add_action_flag_choices','2021-08-09 04:41:02.110691'),(19,'posts','0001_initial','2021-08-09 04:41:02.175143'),(20,'comments','0001_initial','2021-08-09 04:41:02.193783'),(21,'comments','0002_initial','2021-08-09 04:41:02.272203'),(22,'common','0001_initial','2021-08-09 04:41:02.287849'),(23,'posts','0002_initial','2021-08-09 04:41:02.388542'),(24,'sessions','0001_initial','2021-08-09 04:41:02.415080');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('87mhjralo6mmilyq2xoxeilur11lkfa3','.eJxVjDsOwyAQRO9CHSGwgYWU6X0GtHw2OIlAMnYV5e6xJRdJN5r3Zt7M47YWv_W8-DmxK5OCXX7LgPGZ60HSA-u98djqusyBHwo_aedTS_l1O92_g4K97GubHEikQSsNeyQYY4ZskbJTRlGUZLW00ToxahW0SwOYYJwlQQ4BRvb5AgI7N7Q:1mD2Tx:Mqr3DyLcLZYLpBjC0HEiJoJjGhTQ3ujJBDgHExWn5T4','2021-08-23 10:26:09.493386'),('t3obqc63362xkus0ixpd0mag6ewml8sl','.eJxVjEEOwiAQRe_C2pCBlg66dO8ZCAMzUjU0Ke3KeHfbpAvdvvf-f6sQ16WEtfEcxqwuyqjTL6OYnlx3kR-x3iedprrMI-k90Ydt-jZlfl2P9u-gxFa2NZjzYDti6xL1YMmRzz0hmmTFeGCMGxaE5BBEUkeRAVm8o8EJOK8-X9ndN_E:1mCxjI:nOT0h9OHKIiiA_WmH5JsUwpPZXqpJH1NrjbokEy5lyQ','2021-08-23 05:21:40.538788');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `files` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `image_file` varchar(100) DEFAULT NULL,
  `created_time` datetime(6) DEFAULT NULL,
  `last_mod_time` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
INSERT INTO `files` VALUES (1,'post_image/1.jpg','2021-08-09 05:52:03.384431','2021-08-09 05:52:03.384431'),(2,'post_image/1_LDvvv6w.jpg','2021-08-09 05:52:37.809324','2021-08-09 05:52:37.809324'),(3,'post_image/2.jpg','2021-08-09 06:52:58.059346','2021-08-09 06:52:58.059346'),(4,'post_image/3.jpg','2021-08-09 06:55:31.237924','2021-08-09 06:55:31.237924'),(5,'post_image/4.jpg','2021-08-09 06:58:52.809740','2021-08-09 06:58:52.809740'),(6,'post_image/5.jpg','2021-08-09 06:59:48.371402','2021-08-09 06:59:48.371402'),(7,'post_image/6.jpg','2021-08-09 07:00:06.248587','2021-08-09 07:00:06.248587'),(8,'post_image/7.jpg','2021-08-09 07:01:33.622202','2021-08-09 07:01:33.622202'),(9,'post_image/8.jpg','2021-08-09 07:02:23.725979','2021-08-09 07:02:23.725979'),(10,'post_image/9.jpg','2021-08-09 07:02:45.630081','2021-08-09 07:02:45.630081'),(11,'post_image/10.jpg','2021-08-09 07:03:24.080704','2021-08-09 07:03:24.080704'),(12,'post_image/图片_1.png','2021-08-09 07:11:20.828683','2021-08-09 07:11:20.828683'),(13,'post_image/2.png','2021-08-09 07:12:08.101969','2021-08-09 07:12:08.102936'),(14,'post_image/3.png','2021-08-09 07:13:08.493908','2021-08-09 07:13:08.493908'),(15,'post_image/4.png','2021-08-09 07:14:36.117590','2021-08-09 07:14:36.117590'),(16,'post_image/4_UT4TOeA.png','2021-08-09 07:15:18.183349','2021-08-09 07:15:18.183349'),(17,'post_image/5.png','2021-08-09 07:15:53.650707','2021-08-09 07:15:53.650707'),(18,'post_image/5_yxET1LY.png','2021-08-09 07:15:56.569077','2021-08-09 07:15:56.569077'),(19,'post_image/2a3bcd9d-6c3d-481c-9e18-7007d6394dc3.png','2021-08-09 07:17:01.534818','2021-08-09 07:17:01.534818'),(20,'post_image/788bdf3e-2b79-4c02-8b60-e7e4a0f97d7f.png','2021-08-09 07:17:25.093285','2021-08-09 07:17:25.093285'),(21,'post_image/f61996d3-1712-418c-a705-0028cec8b16c.png','2021-08-09 07:18:39.014648','2021-08-09 07:18:39.014648'),(22,'post_image/头像_3.png','2021-08-09 07:19:40.434816','2021-08-09 07:19:40.434816'),(23,'post_image/1.jpeg','2021-08-09 07:52:55.785982','2021-08-09 07:52:55.785982'),(24,'post_image/2_zxKx8Ym.png','2021-08-09 07:53:44.406019','2021-08-09 07:53:44.406019'),(25,'post_image/3.jpeg','2021-08-09 07:54:45.386264','2021-08-09 07:54:45.386264'),(26,'post_image/头像.png','2021-08-09 07:54:57.655038','2021-08-09 07:54:57.655038'),(27,'post_image/99292a3a-857a-4dc6-b4e4-38935a6ea640.png','2021-08-09 07:55:02.152275','2021-08-09 07:55:02.152275'),(28,'post_image/4.jpeg','2021-08-09 07:55:24.505385','2021-08-09 07:55:24.505385'),(29,'post_image/df7e6190-89a6-4bbc-b113-5df4d96984cf.png','2021-08-09 07:57:02.749363','2021-08-09 07:57:02.749363'),(30,'post_image/5.jpeg','2021-08-09 07:57:36.385947','2021-08-09 07:57:36.385947'),(31,'post_image/download.jpeg','2021-08-09 09:51:45.153271','2021-08-09 09:51:45.153307'),(32,'post_image/download_mRMnmIy.jpeg','2021-08-09 10:05:59.672731','2021-08-09 10:05:59.672788'),(33,'post_image/food_health.jpeg','2021-08-09 10:06:45.397853','2021-08-09 10:06:45.397884'),(34,'post_image/food_health_8mEzm3b.jpeg','2021-08-09 10:13:40.312951','2021-08-09 10:13:40.312995'),(35,'post_image/WechatIMG194.jpg','2021-08-09 10:15:04.887556','2021-08-09 10:15:04.887596'),(36,'post_image/image.jpeg','2021-08-09 10:20:16.813978','2021-08-09 10:20:16.814015'),(37,'post_image/1_5ei2Do4.jpeg','2021-08-09 10:21:31.513289','2021-08-09 10:21:31.513322'),(38,'post_image/5_yWKC3Vy.jpeg','2021-08-09 10:27:36.834496','2021-08-09 10:27:36.834529'),(39,'post_image/123.jpg','2021-08-09 10:29:35.277119','2021-08-09 10:29:35.277154'),(40,'post_image/_119840257_bbcsport_gb_medal_standings_tokyo_2020.jpeg','2021-08-09 10:38:24.097011','2021-08-09 10:38:24.097050');
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(20) NOT NULL,
  `content` longtext,
  `create_time` datetime(6) DEFAULT NULL,
  `sts` int NOT NULL,
  `first_category` varchar(20) DEFAULT NULL,
  `follow_nb` int NOT NULL,
  `post_image` varchar(200) DEFAULT NULL,
  `must_see` tinyint(1) NOT NULL,
  `author_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `posts_author_id_099b8aca_fk_users_user_id` (`author_id`),
  CONSTRAINT `posts_author_id_099b8aca_fk_users_user_id` FOREIGN KEY (`author_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (1,'Australian stress','<p>Stress among consumers has risen across every Australian state and territory, new data suggests, with big purchasing expectations for the next 12 months trimmed as the gap between low and high incomes widens.</p><p>&nbsp;</p><p>The “stress index” in a National Australia Bank consumer sentiment survey released on Thursday registered 57.8 points in the June quarter, up from 56.6 in the March quarter, driven by growing concern over government policy, ability to fund retirement and cost of living.</p><p>&nbsp;</p><p>The gap between lower and higher income groups widened, with consumers earning less than $35,000 per annum rising 2.4 points to 63.1, but falling for those pocketing above $100,000 per annum, down 0.9 points to 53.6.</p><p>&nbsp;</p><p>“Stress among consumers on lower income remains noticeably higher across all measures, particularly cost of living,” NAB found.</p><p>&nbsp;</p><p>Consumer perceptions of living costs remains highest for groceries, while utilities rose sharply.</p><p>&nbsp;</p><p>Respondents particularly noted price rises for rent, transport, travel and holidays, home improvements, medical expenses and eating out.</p><p>&nbsp;</p><p>“Rent has no doubt been a contributing factor with on balance more WA consumers noting rent price increases than in any other state, except SA,” a spokesman said.</p><p>&nbsp;</p><p>West Australians were also increasingly anxious overall, with the state’s stress index rating lifting 2.7 points to 55.6.</p><p>&nbsp;</p><p>Despite the Australian economy being in a much better position than expected six months ago, only West Australians reported heightened concerns about the economy.</p><p>&nbsp;</p><p>Unsurprisingly, concern about the economy was highest in Victoria at 63.3 points, where the economic recovery has been relatively slower due to multiple Covid-19 lockdowns.</p><p>&nbsp;</p><p>The state ranked second for overall stress, up 0.1 points to 58, behind NSW/ACT, up 0.9 to 59.3.</p><p>&nbsp;</p><p>NAB also found expectations for major purchases were a little more conservative, although home renovations were a surprising exception given product and tradesperson supply shortages, partly due to the success of the federal government’s HomeBuilder stimulus scheme.</p><p>&nbsp;</p><p>The good news was stress over job security eased further to sit at its lowest level since the third quarter of 2019.</p>','2021-08-09 05:57:35.170140',1,'Finance',0,'http://127.0.0.1:8000/media/post_image/1_LDvvv6w.jpg',0,3),(2,'How to help staff','<p>As the weeks stretch into months for Sydneysiders stuck in lockdown, bosses are spending more money than ever to keep their workers motivated.</p><p>&nbsp;</p><p>A number of employees have received a surprise parcel in the mail in an attempt by their bosses to cheer them up as they work from home.</p><p>&nbsp;</p><p>Corporate leaders are forking out cash for ‘Covid-19 care packages’ which includes items like chocolate, flowers and even jigsaw puzzles, to be delivered to the doorsteps of their workers.</p><p>&nbsp;</p><p>The Covid hamper industry is one that didn’t exist two years ago but has now become crucial to getting through lockdown, and is perhaps one of the only industries booming during the current health crisis.</p><p>&nbsp;</p><p>There’s been such demand for the hand-delivered parcels that Leyla Roberts, 49, quit her day job to work full-time organising the hampers.</p><p>&nbsp;</p><p>“As soon as lockdown started, I started getting lots of orders and inquiries, not just about lockdown, but also close contacts, hotel quarantine, self-isolation,” Ms Roberts told news.com.au.</p><p>&nbsp;</p><p>Ms Roberts is from one of Sydney’s Covid-affected local government areas, in the Georges River region.</p><p>&nbsp;</p><p>She’s been supporting herself and her three-year-old for a year on the money she gets from creating and delivering Covid hampers.</p><p>&nbsp;</p><p>Most of her materials are sourced online, as she herself is currently in lockdown as well.</p><p>&nbsp;</p><p>“The income is quite high,” she said, citing a comfortable five figure income.</p><p>&nbsp;</p><p>“I’m making more now than I made with my job beforehand.</p><p>&nbsp;</p><p>She’s sold 127 packages in the last month. Since</p><p>&nbsp;</p><p>Quarantine Careofficially launched in September last year, she’s sold 177 packages – so more than half her orders have come through in the last month.</p><p>&nbsp;</p><p>officially launched in September last year, she’s sold 177 packages – so more than half her orders have come through in the last month.</p><p>&nbsp;</p><p>Ms Roberts first came up with the idea after she started to receive queries for her other business.</p><p>&nbsp;</p><p>She used to run a concierge service, taking deliveries – predominantly groceries – to clients who usually couldn’t find the time to buy their own groceries because of work commitments.</p><p>&nbsp;</p><p>Despite ending that line of work after the birth of her child, she started to receive emails last year, as people looked for delivery services.</p><p>&nbsp;</p><p>“It took me a while to realise wait a minute, this is an untapped market.”</p><p>&nbsp;</p><p>She now offers a number of packages including a gym pack, an espresso martini kit, and a kids activity pack, with her most popular being the “Aussie faves” hamper.</p><p>&nbsp;</p><p>It includes a pack of TimTams and a 12-pack of Caramel Koalas for Aussies returning home and stuck in hotel quarantine.</p><p>&nbsp;</p><p>She also has a cleaning pack as a lot of quarantining travellers often want to clean their own hotel room after staying there for two weeks, but don’t usually bring the right equipment.</p><p>&nbsp;</p><p>Ms Roberts has also just struck a deal with Optus to supply SIM cards to people who have just arrived in Australia.</p><p>&nbsp;</p><p>Three people now work under her to cope with the order load.</p><p>&nbsp;</p><p>She said most of her clientele are friends, family or corporate bosses.</p><p>&nbsp;</p><p>Companies have been thinking of conventional and creative ways to bring cheer to staff members.</p><p>&nbsp;</p><p>Sydney-based Fifth Dimension Consulting sent out flowers to all their locked-down employees.</p><p>&nbsp;</p><p>Meanwhile, Aussie cryptocurrency start-up Ebonex, which launched a month before lockdown, sent out relax and indulge hampers to their workers from the Hamper Emporium.</p><p>&nbsp;</p><p>Johnny Phan recalled getting a parcel delivered to his door and thinking it was his wife’s online shopping delivery.</p><p>&nbsp;</p><p>“Once that delivery was there, I was a bit shocked. My wife said she hadn’t purchased anything,” he said.</p><p>&nbsp;</p><p>Opening up the delivery, he found the Covid care package.</p><p>&nbsp;</p><p>The leadership team at science and tech compnay Merck ANZ recently sent out self-care hampers to their employees.</p><p>&nbsp;</p><p>Other workers have received margarita mixes, 1kg cookies and scented candles.</p><p>&nbsp;</p><p>Some of Australia’s big banks are doing their own version of a Covid care package.</p><p>&nbsp;</p><p>NAB and the Commonwealth Bank have given their workers an additional 10 days of paid “pandemic leave” for Covid-related needs like isolating, getting tested or vaccinated, or home schooling needs.</p><p>&nbsp;</p><p>Likewise, Westpac has given workers affected by lockdown the opportunity to spend $100 on items or gift vouchers.</p><p>&nbsp;</p><p>Westpac said people who need to supervise their children and can’t work from home are able to take personal/carer‘s leave.</p><p>&nbsp;</p><p>If they have no personal/carer’s leave left, Westpac provides an additional two weeks of special paid leave.</p>','2021-08-09 06:54:42.305643',1,'Work',0,'http://127.0.0.1:8000/media/post_image/2.jpg',0,3),(3,'Disaster fee','<p>Apprentices younger than 17 are falling through the cracks when it comes to coronavirus disaster payments, a union has said.</p><p>&nbsp;</p><p>The Electrical Trades Union has called for the federal government to change the rules for Covid-19 payments so that workers under 17 would be eligible.</p><p>&nbsp;</p><p>The federal disaster payment scheme has a lower age limit set at 17.</p><p>&nbsp;</p><p>ETU Assistant National Secretary Michael Wright argued that because many trainees and apprentices have the “typical cost of living expenses of being in the workforce”, it doesn\'t make sense to exclude them from the payments solely on account of their age.</p><p>&nbsp;</p><p>“In the absence of Jobkeeper, the Covid-19 disaster payment is designed to help those who are unable to work as a result of government mandated restrictions on business, yet the current eligibility rules arbitrarily exclude apprentices under the age of 17” Mr Wright said.</p><p>&nbsp;</p><p>“The carving out of apprentices and trainees under 17, many of whom will have the typical cost of living expenses of being in the workforce is grossly unfair and must be fixed urgently.”</p><p>&nbsp;</p><p>There are other payments that are available to apprentices aged under 17, including youth allowance.</p><p>&nbsp;</p><p>A spokeswoman for the federal government’s National Recovery and Resilience Agency pointed to that opportunity when asked to comment.</p><p>&nbsp;</p><p>“The Covid-19 disaster payment is only available to people aged 17 years and above,” the spokeswoman said.</p><p>&nbsp;</p><p>“Workers under 17 years of age who require assistance are encouraged to contact Services Australia to test their eligibility for a range of other payments including youth allowance, which is the working age payment for job seekers and apprentices aged 16-24.”</p><p>&nbsp;</p><p>But the union argued those weren’t enough and pointed to limitations including waiting period and asset tests.</p><p>&nbsp;</p><p>Mr Wright said he had written to the Prime Minister and the Treasurer to ask that they put the issue on the agenda for Friday’s national cabinet meeting.</p><p>&nbsp;</p><p>But a statement issued by the national cabinet after the summit did not indicate it had been brought up.</p><p>&nbsp;</p><p>The only mention of the disaster payments was the following line: “National cabinet noted the support package agreed between the Commonwealth and the Victorian government to progress Covid-19 disaster payments and business payments during the current outbreak.”</p><p>&nbsp;</p><p>Sydney’s construction sector was almost completely shut down for a two-week period during the current lockdown.</p><p>&nbsp;</p><p>Even after the ban was lifted, many tradespeople have been unable to work because they live in a hotspot, given they cannot leave their local government area.</p><p>&nbsp;</p><p>With Australia’s three largest cities in lockdown, more than half of the country’s population is currently under stay-at-home orders.</p>','2021-08-09 06:57:59.023412',1,'Work',0,'http://127.0.0.1:8000/media/post_image/3.jpg',1,3),(4,'Financial incentives','<p>Victorians who need to isolate during the state’s latest Covid-19 outbreak could snap up cash cheques worth $1500.</p><p>&nbsp;</p><p>Gyms, cafes and other small businesses owners have also been offered financial support.</p><p>&nbsp;</p><p>Victoria has been plunged into another snap seven-day lockdown, with four new locally acquired cases confirmed on Friday.</p><p>&nbsp;</p><p>Authorities say they are “sick of the lockdowns” but realise the impact they are having on people’s finances, so will be upping incentives.</p><p>&nbsp;</p><p>Trade Minister Martin Pakula said he was “as sick of lockdown as everybody else” but needed people to do the right thing.</p><p>&nbsp;</p><p>“I’m also as convinced as Jeroen and Minister Foley that this is the only and best option we have available to us in an environment where are vaccination numbers are (so low),” he said.</p><p>&nbsp;</p><p>“These lockdowns are very hard, I don’t just mean from a business viability point of view. They are difficult for people to cope with.</p><p>&nbsp;</p><p>“The alternative right now seems to be that you lock down, get on top of it, or you let it run. I know what I’d rather.”</p><p>&nbsp;</p><p>Covid-19 commander Jeroen Weimar said it was “much more important” people did the right thing.</p><p>&nbsp;</p><p>“Anyone who needs to isolate as a positive case is eligible for a $1500 payment if there’s no alternative source of income to you to support people isolating safely,” he told reporters in Melbourne on Friday.</p><p>&nbsp;</p><p>“We have 10,000 people already isolating as primary close and secondary contacts. If anyone on the list needs support, please get in touch with us.”</p><p>&nbsp;</p><p>It’s one of a number of new financial measures introduced this week, including a $450 payment for anyone who needs to isolate while awaiting a Covid-19 test result.</p><p>&nbsp;</p><p>“I know so many people are doing jobs whereby they don’t get sick pay,” Mr Weimar said.</p><p>&nbsp;</p><p>If that applies to you, if you need to take a day off to go and get tested and you won’t be paid for it, there’s a $450 isolation payment available.”</p><p>&nbsp;</p><p>Mr Pakula said his department had put together a $400m package to support more than 100,000 businesses.</p><p>&nbsp;</p><p>He said the Treasurer had spoken to Josh Frydenberg to secure a 50-50 split with the commonwealth.</p><p>&nbsp;</p><p>“It means this package can be in the vicinity of $400m for a seven-day lockdown, which is above and beyond what we’ve been able to do in the past,” Mr Pakula said.</p><p>&nbsp;</p><p>“Round three of the business cost assistance program will provide grants of $2800 to around 95,000 businesses including gyms, cafes, restaurants, caterers, hairdressers, event businesses, tourism basements.”</p><p>&nbsp;</p><p>Mr Pakula said the payments would be made automatically and there would be an opportunity for those who didn’t previously apply to register.</p><p>&nbsp;</p><p>The state is awaiting a hotspot declaration from the commonwealth to assist those workers who have lost hours.</p>','2021-08-09 06:59:06.896685',1,'Finance',0,'http://127.0.0.1:8000/media/post_image/4.jpg',0,4),(5,'Jobs down','<p>Australian jobs dropped by 176,000 in July as all five mainland states experienced lockdowns, new data reveals.</p><p>&nbsp;</p><p>A total of 13.2 millions Aussies were employed last month, down 176,000 on June, according to the latest Roy Morgan employment series data.</p><p>&nbsp;</p><p>There were 8.7 million workers employed full-time, a drop of 61,000 from June. There was also a fall in part-time employment, down by 115,000 to 4.4 million.</p><p>&nbsp;</p><p>Unemployment also rose 0.3 percentage points to 9.7 per cent in July as more people looked for full time work.</p><p>&nbsp;</p><p>The underemployment rate — in which people are working part time but looking for more work — was also higher, up 0.6 percentage points, to 9.1 per cent.</p><p>&nbsp;</p><p>Roy Morgan CEO Michele Levine said the July estimates meant 2.76 million Aussies — or 18.8 per cent of the workforce — were either unemployed or underemployed in July, the highest monthly figure since February 2021.</p><p>&nbsp;</p><p>“The increases in both unemployment and underemployment in July are not surprising when one considers the number of lockdowns around Australia over the last few months,” she said.</p><p>&nbsp;</p><p>“There have been three lockdowns of Victoria, two lockdowns in Queensland, a lockdown of South Australia, a lockdown of Greater Perth, a lockdown of Darwin and an extended lockdown in Greater Sydney which began in late June and is set to continue until at least the end of August.”</p><p>Ms Levine said the multiple lockdowns were especially detrimental to travel and tourism industries and the retail and hospitality sectors.</p><p>&nbsp;</p><p>“Already Qantas has stood down 2,500 staff as hundreds of flights are cancelled due to the lockdowns and state border closures and the damage to the retail and hospitality sectors continues with trade disrupted and stores forced to close again,” she said.</p><p>&nbsp;</p><p>“The renewed lockdowns in south east Queensland and Victoria, as well as the extended Greater Sydney lockdown, will cause more economic damage and higher unemployment and underemployment in August, with more than half of the population now in lockdown.</p><p>&nbsp;</p><p>“The contagiousness of the Delta variant means these lockdowns could continue throughout August and beyond.”</p><p>&nbsp;</p><p>Ms Levine said increasing government support to business and workers dealing with border closures and lockdowns is having an impact, with the July 2021 jobless estimate of 9.7 per cent well down from July 2020 (12.5 per cent).</p><p>&nbsp;</p><p>However, the next four months were expected to be unpredictable for business while Australia moved towards its target of at least 70 per cent of adults being vaccinated - a milestone not likely until around the end of the year.</p><p>&nbsp;</p><p>“As lockdowns are now the preferred policy response of both the federal and state governments to deal with the highly contagious Delta variant, it is imperative that both levels of government are on the front foot to offer businesses impacted by these lockdowns all the support they require,” she said.</p><p>&nbsp;</p><p>“Australia’s largely successful management of the COVID-19 pandemic has been one of the best in the world over the last 18 months and there is no point letting all the good work we’ve undertaken so far be undone by decisions made in the final months of the vaccination push.”</p><p>&nbsp;</p><p>The Roy Morgan July unemployment figure of 9.7 per cent is higher than the current ABS estimate for June of 4.9 per cent, as the ABS counts an extra 157,000 Australians working zero hours for ‘economic reasons’ as employed.</p>','2021-08-09 06:59:50.467678',1,'Work',0,'http://127.0.0.1:8000/media/post_image/5.jpg',0,4),(6,'Learn new skills','<p>BITE-SIZED training, lasting as little as just 60 seconds, is being embraced by workers looking to continue their climb up the career ladder after a Covid-induced pause.</p><p>&nbsp;</p><p>Experts say full-day workplace training is all but dead following the pandemic, with a move to more efficient professional development sessions that last no more than three hours at a time.</p><p>&nbsp;</p><p>Culture Amp people science director Chloe Hamman says it typically is not a good way to learn anyway.</p><p>&nbsp;</p><p>“To sit in a classroom for the day is one of the least effective ways of doing (workplace training),’’ she says.</p><p>&nbsp;</p><p>“It’s far more effective to spend a couple of hours – maybe an hour, maybe two – where you do some quite intense learning and then you have the opportunity to put that into practise.’’</p><p>&nbsp;</p><p>A Culture Amp survey shows more than two in five workers are thinking of leaving their current job, with lack of development opportunities and career growth most likely to blame.</p><p>&nbsp;</p><p>Hamman says with most workplace training put on hold last year, staff and employers are now keen to make up for lost time.</p><p>&nbsp;</p><p>“Companies were not spending on learning and development because they were just really trying to deal with Covid,” she says.</p><p>&nbsp;</p><p>“It was very much about survival and bunkering down to get through the year.</p><p>&nbsp;</p><p>“So we had a year where we didn’t make as much progress in our (professional) growth and careers as we expected – and now we are really hungry (to rectify) that.’’</p><p>&nbsp;</p><p>Corporate training platform EdApp chief executive Darren Winterford says microlearning is fast becoming the preferred method of workplace training.</p><p>&nbsp;</p><p>He says the training, which relies on short bursts of learning done frequently, overcomes the forgetting curve, a mathematical concept that shows people forget 90 per cent of what they learned within the first month, unless it is reinforced.</p><p>&nbsp;</p><p>“We can set up small, 60-second quizzes that can be sent out in a push notification on your mobile phone,’’ Winterford says.</p><p>&nbsp;</p><p>“So, for a period of eight weeks, you can receive tiny, 60-second trainings that, through repetition, ensures that what you are learning sticks.’’</p><p>&nbsp;</p><p>He says microlearning can be used in all industries, for teaching even complex theories or subject matter.</p><p>&nbsp;</p><p>Merylee Crockett, director of people and culture at IT services company Interactive, is among those to embrace the move to shorter, online learning.</p><p>&nbsp;</p><p>Within her own workplace, Crockett says almost a third of employees have gained certifications in cyber security and cloud computing in the past year, which she credits to the more convenient style of learning.</p><p>&nbsp;</p><p>“Now, we might sit and learn for five minutes, or for 30 minutes, as opposed to a whole day,’’ she says.</p><p>&nbsp;</p><p>“We are able to consume little pieces of learning as and when it’s relevant to what we are doing.</p><p>&nbsp;</p><p>“It’s much more effective and efficient.’’</p>','2021-08-09 07:00:18.385220',1,'Work',0,'http://127.0.0.1:8000/media/post_image/6.jpg',0,4),(7,'New Covid-19 vaccine','<p>Authorities are set to approve Australia’s third Covid-19 vaccine within the next few weeks, significantly boosting efforts to protect the country from infection, serious illness and death.</p><p>&nbsp;</p><p>The vaccination rollout has been plagued by delays due to supply issues and hesitancy, but the arrival of millions of Moderna jabs will help alleviate some of the pressure.</p><p>&nbsp;</p><p>Health Minister Greg Hunt has said the first doses will roll out from mid-September, with the Therapeutic Goods Administration expected to green light the vaccine’s use imminently.</p><p>&nbsp;</p><p>Moderna’s vaccine is pretty similar to the Pfizer jab, in that it’s developed using mRNA technology and requires two doses to be administered.</p><p>&nbsp;</p><p>It has received approval in a number of countries, from the United Kingdom and European Union to the United States and Singapore and is in wide use there.</p><p>&nbsp;</p><p>Vaccinating against Covid-19 is the only way for Australians to get their normal lives back, but as a nation we’re struggling.</p><p>&nbsp;</p><p>News.com.au’s Our Best Shot campaign answers your questions about the Covid-19 vaccine rollout.</p><p>&nbsp;</p><p>It’s fair to say the vaccine rollout has confused Australians. We’ll cut through the spin and give you clear information so you can make an informed decision.</p><p>&nbsp;</p><p>Australia’s deal is for 10 million doses of the existing formula this year, followed by 15 million additional doses of an updated variant-targeting shot to come in 2022.</p><p>&nbsp;</p><p>“The agreement not only ensures current supply, but it is also forward-looking by providing vaccines for the variants that are now appearing, for which existing vaccines don’t work as well,” Professor Bruce Thompson, dean of the School of Health Sciences at Swinburne University, said.</p><p>&nbsp;</p><p>Here’s the lowdown on the jab, from its efficacy to potential side effects.</p><p>&nbsp;</p><p>How effective is it?</p><p>&nbsp;</p><p>Official data shows the Moderna vaccine has an overall efficacy against symptomatic Covid-19 of 94.1 per cent. It’s been shown to be 100 per cent effective against severe illness.</p><p>&nbsp;</p><p>On top of that, a study by Boston Healthcare System also indicated the first Moderna dose can begin reducing general covid infection rates after just eight days.</p><p>&nbsp;</p><p>Researchers made the finding while monitoring the rollout of the jab in frontline healthcare workers, which kicked off just as a winter surge of new cases was ravaging the city.</p><p>&nbsp;</p><p>In addition, they found two doses of the vaccine are 95 per cent effective at preventing illness after two weeks.</p><p>&nbsp;</p><p>The second jab should be administered four weeks after the first.</p><p>&nbsp;</p><p>Are there side effects?</p><p>&nbsp;</p><p>Authorities have noted a few side effects of the Moderna vaccine, including one that’s been colloquially dubbed ‘Covid arm’.</p><p>&nbsp;</p><p>Some recipients experienced a small reaction on their arm where the jab is given, presented as itchy, swollen or sore skin.</p><p>&nbsp;</p><p>It can appear a few days afterwards and last for two to three weeks in some people.</p><p>&nbsp;</p><p>Researchers from Yale University examined people who experienced ‘Covid arm’ and found it isn’t serious and shouldn’t be a reason to avoid receiving the Moderna jab.</p><p>&nbsp;</p><p>“Skin biopsies found these reactions are not serious like immediate reactions experienced by those with severe allergic reactions and should not be a reason to avoid a second dose of Moderna,” they concluded.</p>','2021-08-09 07:01:41.966541',1,'Life',0,'http://127.0.0.1:8000/media/post_image/7.jpg',1,5),(8,'Cairns venues','<p>A Woolworths supermarket, gambling lounge and tavern have been added to the long list of Queensland venues exposed to Covid-19 cases.</p><p>&nbsp;</p><p>It comes after the state recorded nine new locally acquired cases on Sunday, with seven of those linked to the Indooroopilly cluster and one under investigation on the Gold Coast, while a Cairns taxi driver sparked a three-day lockdown in the far north city and Yarrabah local government areas.</p><p>&nbsp;</p><p>The driver had been infectious in the community for 10 days.</p><p>&nbsp;</p><p>The lockdown started at 4pm, just as southeast Queensland emerged from its eight-day lockdown.</p><p>&nbsp;</p><p>Anyone who has been to the following venues is considered a close contact and must quarantine immediately at home for 14 days, gest tested as soon as possible and remain at home for the full fortnight regardless of the result.</p><p>&nbsp;</p><p>Manunda:</p><p>&nbsp;</p><p>* Woolworths, Raintrees Shopping Centre, corner Alfred and Koch Streets, Thursday 29 July, 3.15pm to 4.30pm; Friday 30 July, 1.30pm to 2.30pm; and Wednesday 4 August, 2.30pm to 3.30pm</p><p>&nbsp;</p><p>* Raintrees Tavern, Raintrees Shopping Centre, corner Alfred and Koch Streets, Tuesday 3 August, 1.55pm to 4.30pm and Wednesday 4 August, 3.30pm to 4.30pm</p><p>&nbsp;</p><p>* Brothers Leagues Club gaming lounge, 99-107 Anderson Street, Thursday 5 August, 3pm to 5pm</p><p>&nbsp;</p><p>Parramatta Park:</p><p>* Café China on Mulgrave Road, 79 Mulgrave Road, Thursday 5 August, 11.40am to 12.40pm</p><p>&nbsp;</p><p>Cairns City:</p><p>&nbsp;</p><p>* The Cairns 24 Hour Medical Centre waiting room, 156 Grafton Street, Friday 6 August, 3pm to 4.15pm</p><p>&nbsp;</p><p>* QML Pathology Cairns Day Surgery, corner Florence and Grafton streets, Friday 6 August, 4.15pm to 5.30pm</p><p>&nbsp;</p><p>Additional venues have been added to the list of places where anyone who attended at the specified times is considered a casual contact.</p>','2021-08-09 07:02:26.287426',1,'Health',0,'http://127.0.0.1:8000/media/post_image/8.jpg',0,5),(9,'AstraZeneca vaccine','<p>A 34-year-old woman‘s death has been linked to a rare blood clotting condition associated with the AstraZeneca vaccine.</p><p>&nbsp;</p><p>She died on Wednesday after receiving her first dose and developing thrombosis with thrombocytopenia syndrome (TTS), the Therapeutic Goods Administration said.</p><p>&nbsp;</p><p>Hers is the seventh death linked to the first dose of the AstraZeneca vaccine, of which about 6.8 million shots have now been administered across the country.</p><p>&nbsp;</p><p>Six of those deaths were linked to TTS, while the other was a case of immune thrombocytopenia (ITP), where the body’s immune system mistakenly attacks blood platelets.</p><p>&nbsp;</p><p>Data suggests that TTS occurs in 2 to 3 out of every 100,000 people who receive a first dose of the AstraZeneca vaccine.</p><p>&nbsp;</p><p>Leading Sydney doctors have urged people to get immunised with AstraZeneca, warning that Covid-19 kills about 3 per cent and causes long-term illness in 10 to 30 per cent of those who contract it.</p><p>&nbsp;</p><p>The Australian Technical Advisory Group on Immunisation has recommended that all adults in Greater Sydney get immunised with any available vaccine.</p><p>&nbsp;</p><p>“ATAGI reaffirms our previous advice that in a large outbreak the benefits of the COVID-19 vaccine AstraZeneca are greater than the risk of rare side effects for all age groups,” the expert panel said in a statement.</p><p>&nbsp;</p><p>The Pfizer vaccine, which remains in short supply and high demand, remains the preferred vaccine for people under 60 outside of Sydney.</p><p>&nbsp;</p><p>Sydney on Thursday suffered its worst day of the pandemic, with 262 new cases and five deaths from the virus recorded.</p><p>&nbsp;</p><p>The TGA noted the new AstraZeneca-linked death in its weekly Covid-19 safety report, released on Thursday.</p><p>&nbsp;</p><p>“Sadly, one of the cases, a 34-year-old woman from NSW, died yesterday,” the report said.</p><p>&nbsp;</p><p>“The TGA extends its sincerest condolences to her family and loved ones. We are in close communication with NSW Health who are undertaking further investigation of this case.</p><p>&nbsp;</p><p>“The TGA extends its sincerest condolences to their families and loved ones.”</p><p>&nbsp;</p><p>In the past week, a total of three reports of blood clots and low blood platelets have been assessed as confirmed or probable TTS likely to be linked to the AstraZeneca vaccine.</p>','2021-08-09 07:02:56.395883',1,'Health',0,'http://127.0.0.1:8000/media/post_image/9.jpg',0,5),(10,'Bitcoin price','<p>Bitcoin is attempting to stage its next comeback as it came close to $US50,000 ($A68,000) for the first time since May as the broader cryptocurrency market also looked to claw back massive losses.</p><p>&nbsp;</p><p>The most popular cryptocurrency, bitcoin is trading at $A44,500, and comes after the top ten cryptos, including ethereum and dogecoin, added $US300 billion ($A409 billion) to the market over the past week.</p><p>&nbsp;</p><p>Tony Sycamore, APAC market analyst at City Index, said the bitcoin rally comes after last week’s ethereum upgrade and renewed optimism towards a bitcoin ETF, which would allow investors to buy into the digital coin without going through the complicated process of trading.</p><p>&nbsp;</p><p>“This is overshadowing concerns the US could be about to pass legislation including cryptocurrency as part of tax reporting legislation in the Infrastructure and Jobs Act,” he noted.</p><p>&nbsp;</p><p>“If bitcoin can see a sustained break above the 200 day moving average at $45,000 it would confirm a break out of the top of three month range and allow for further gains towards $52,000.”</p><p>&nbsp;</p><p>Crypto experts and investors are fearful the US regulations could make mining of cryptocurrency impossible and have described is a “backdoor ban”, while Coinbase chief executive Brian Armstrong branded the bill as “disastrous”.</p><p>&nbsp;</p><p>Billionaire Elon Musk has also weighed into the debate arguing there is “no crisis” to warrant “hasty legislation”.</p><p>&nbsp;</p><p>Meanwhile, ethereum experienced a strong rally last week with gains as much as 30 per cent as it underwent a major software upgrade on Thursday.</p><p>&nbsp;</p><p>The digital coin was upgraded to stabilise transaction fees and significantly decrease the number of ether tokens available - which will in turn jack up the price of ethereum as there will be less supply and more demand.</p><p>&nbsp;</p><p>Crypto volatility</p><p>&nbsp;</p><p>Jeremy Ng, Asia-Pacific Managing Director of Gemini, said recent research has shown that some crypto enthusiasts in Australia are looking to use the digital coins like bitcoin to protect themselves against inflation.</p><p>&nbsp;</p><p>He said while some investors do get nervous about the volatility of bitcoin, it is to be expected for a relatively new asset class.</p><p>&nbsp;</p><p>“Bitcoin is still maturing while climbing exponentially. Bitcoin, most notably, has had the highest average return across all asset classes in the last decade,” he said.</p><p>&nbsp;</p><p>“At an average annualised return rate of over 200 per cent, bitcoin’s average return is over 10 times that of Nasdaq-100 index which was the second ranked asset class.”</p><p>&nbsp;</p><p>However, regulators around the world are increasingly eyeing off cryptocurrency and the risks they could pose to people’s finances.</p><p>&nbsp;</p><p>The UK financial regulator has previously warned that people should be prepared to lose all their money if they invest in cryptocurrency and recently banned one of the world’s largest exchanges Binance.</p>','2021-08-09 07:03:31.120039',1,'Finance',0,'http://127.0.0.1:8000/media/post_image/10.jpg',0,5),(11,'Phone Surveys','<p><span style=\"color: black;\">MDH\'s most common phone survey is the Behavioral Risk Factor Surveillance System. MDH works with the survey company Abt SRBI to do the survey. The phone call you receive should be from&nbsp;</span><strong style=\"color: black;\">651-201-4982</strong><span style=\"color: black;\">&nbsp;or&nbsp;</span><strong style=\"color: black;\">877-551-6138</strong><span style=\"color: black;\">. You can also ask for a supervisor who will identify themselves as being from the company Abt SRBI.</span></p><p><span style=\"color: black;\">More information about the BRFSS survey is available online at&nbsp;</span><a href=\"https://www.health.state.mn.us/data/mchs/surveys/brfss/index.html\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"color: rgb(0, 100, 164);\">Behavioral Risk Factor Surveillance System</a><span style=\"color: black;\">.</span></p><p><span style=\"color: black;\">This is a biennial general population telephone survey of Minnesotans focused on health insurance coverage and access, as well as health care access. The University of Minnesota may display on caller ID. MDH works with the survey company SSRS located in Media, PA. The phone number you receive should be from&nbsp;</span><strong style=\"color: black;\">612-626-3261</strong><span style=\"color: black;\">&nbsp;or&nbsp;</span><strong style=\"color: black;\">651-201-3846</strong><span style=\"color: black;\">.</span></p><h3><span style=\"color: black;\">Minnesota Pregnancy Risk Assessment Monitoring System (Minnesota PRAMS)</span></h3><p><a href=\"https://www.health.state.mn.us/people/womeninfants/prams/index.html\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"color: rgb(0, 100, 164);\">PRAMS</a><span style=\"color: black;\">&nbsp;conducts a population-based survey to collect information on maternal behaviors and experiences before, during, and shortly after a woman\'s pregnancy. Each month, approximately 150 PRAMS surveys are mailed to a random sample of women who live in Minnesota and have recently delivered a live-born infant. The survey is administered in English or in Spanish. Multiple mail attempts are made to sampled mothers. However, a phone survey is conducted for mothers who do not respond by mail. MDH works with Kent State University Survey Research Lab to do the phone surveys. The phone number that will appear on cell phone caller IDs is toll free&nbsp;</span><strong style=\"color: black;\">800-723-2712</strong><span style=\"color: black;\">. The results of the survey will provide useful information to identify high-risk groups, select maternal and child health priorities, establish prevention programs, and inform policy changes that can improve the health of mothers and babies in Minnesota.</span></p>','2021-08-09 07:11:32.634587',0,'Health',0,'http://127.0.0.1:8000/media/post_image/%E5%9B%BE%E7%89%87_1.png',0,4),(12,'COVID-19 death','<p><strong style=\"color: black;\">The Minnesota Department of Health issued this statement today upon confirmation of a COVID-19 related death involving a school-aged child.</strong></p><p><span style=\"color: black;\">We are deeply saddened to confirm that a child under age 10 from southwestern Minnesota has died due to complications from COVID-19. While COVID-related deaths in children are rare, they can occur even in otherwise healthy children. Since the start of the pandemic, three Minnesota children under age 18 have died due to COVID-19. Because this is a death in a school-aged student in Minnesota, it will be included in Thursday’s school data update.</span></p><p><span style=\"color: black;\">Since children under 16 are not yet eligible to receive a COVID-19 vaccine, the best approach we all can take to keep children safe is to make sure those around them who can get vaccinated do get vaccinated, and that we continue to follow those measures that prevent transmission of the virus. Those measures include getting vaccinated as soon as you can, wearing masks when in public, socially distancing, getting tested regularly, staying home if you test positive or if you’re sick, washing your hands and covering your coughs.</span></p>','2021-08-09 07:12:32.276664',0,'Health',0,'http://127.0.0.1:8000/media/post_image/2.png',1,4),(13,'CDC panel vote','<p><strong style=\"color: black;\"><em>The Minnesota Department of Health issued this statement today following today’s vote by the Centers for Disease Control and Prevention Advisory Committee on Immunization Practices to lift the temporary pause on use of the Johnson &amp; Johnson COVID-19 vaccine.</em></strong></p><p><span style=\"color: black;\">This announcement is good news for Minnesotans and underscores the importance that is placed on vaccine safety.</span></p><p><span style=\"color: black;\">Americans are fortunate to have three safe and effective vaccines that are helping get us closer to the end of this pandemic. To bring that end even closer, it is very important that all eligible Minnesotans get vaccinated. All three vaccines protect you from COVID-19, but they do much more than that. They also protect your family, your friends and your community. They get us closer to the day when we are able to do all those things we’ve missed over the last year plus.</span></p><p><span style=\"color: black;\">Right before the pause was announced last week, the State of Minnesota had distributed 9,600 doses of Johnson &amp; Johnson vaccine to Minnesota providers. Those doses have been stored by the providers who received them and we expect them to be available in the coming days along with any updated information to provide to those getting the vaccine. While Minnesota is not scheduled to receive any Johnson &amp; Johnson vaccine this coming week, we anticipate the federal supply picking back up in the weeks ahead and we strongly encourage everyone who is eligible to get their vaccine so we can finally end this pandemic and enjoy a summer full of brighter days for all Minnesotans.</span></p>','2021-08-09 07:13:19.315349',0,'Health',0,'http://127.0.0.1:8000/media/post_image/3.png',0,4),(14,'Ministry of Health','<p><span style=\"color: black;\">According to the provision defined in paragraph 1 of Article 7 of the Food Sanitation Law (Law No. 233), certain parts of Specifications and Standards for Foods, Food Additives and Other Related Products (Ministry of Health and Welfare Announcement No.370 - Dec. 1959) are hereby amended as follows, and this amendment is effective on April 1, 2001. Under the amended Specifications and Standards, only two provisions regarding procedure for examination of safety assessment and for confirmation of compliance with the standards for manufacturing process can be applied before April 1, 2001. The former is related to the provision defined in paragraphs 3 and 4 of Part 1, Section A and in Part 2, Section D and the latter is in paragraph 5 of Part 1, Section B and in paragraph 3 of Part 2, Section E of the Specifications and Standards.</span></p>','2021-08-09 07:15:20.394560',1,'Health',0,'http://127.0.0.1:8000/media/post_image/4_UT4TOeA.png',0,5),(15,'Ministry No. 233','<p><span style=\"color: black;\">According to the Specifications and Standards for Foods, Food Additives and Other Related Products (Ministry of Health and Welfare Announcement No.370-December 1954) amended by new Announcement (Announcement No. 232), Procedure of Application for Safety Assessment of Foods and Food Additives Produced by Recombinant DNA Techniques is hereby determined as follows.</span></p><p><span style=\"color: black;\"> Even if application is not made based on the provision defined in paragraph 1 of Article 3 of this Announcement, the Minister can examine safety assessment of such foods and food additives, if the Minister has already possessed necessary documents for the safety assessments in applying this Announcement.</span></p><p><span style=\"color: black;\"> </span></p><p><span style=\"color: black;\"> </span></p>','2021-08-09 07:16:28.750178',0,'Health',1,'http://127.0.0.1:8000/media/post_image/5_yxET1LY.png',0,5),(16,'Leaving a job','<p>Hi all,</p><p>I\'m currently 6 months into a 2 year grad program. I\'m working in the environment team for a govt infrastructure project. I studied enviro and sustainability in uni, am 26 years old (single, no mortgage) and have an interest in infrastructure so applied for the grad job.</p><p>&nbsp;</p><p>I\'m really struggling to stay engaged with the job so am considering looking elsewhere, would love to hear your thoughts. A few notes:</p><p>&nbsp;</p><p>- I feel like I\'m not really learning. I\'m doing pretty basic work which isn\'t too related to what I studied, and the grad development sessions are teaching skills which I\'ve taught other people in previous jobs.</p><p>- My next rotation starts this month. It will be on site instead of in HQ so will be more hands-on, which might give me the opportunity to develop my technical skills.</p><p>- I\'ve had a lot of varied work experience in the past – lots of facilitation and leadership coaching, sales, communications, working for environmental non profits, strategic business operations and management... In comparison, the govt grad job seems really slow and cushy. I feel like I\'m not being challenged.</p><p>- I want to stay in the environment sector for sure.</p><p>- I think the work my project is doing is important, but feel like the work I\'m individually doing isn\'t important. I\'m a person who\'s really connected to purpose.</p><p>- The pay is really good especially for a grad job ($70k), though I\'m fine with taking a pay cut if I feel more engaged and fulfilled at the end of every day.</p><p>&nbsp;</p><p>That\'s just a brief overview, I\'ve started browsing through council and NFP jobs again in the environment sector to get a feel for what\'s available but would love to hear your thoughts. Thanks.</p>','2021-08-09 07:53:05.078298',2,'Work',0,'http://127.0.0.1:8000/media/post_image/1.jpeg',0,2),(17,'Financial support','<p>Hi everyone,</p><p>With the recent lockdown imposed on parts of NSW including Sydney and surrounds, I thought it was important to discuss financial support that may be available for businesses and individuals that are affected by the lockdowns.</p><p>&nbsp;</p><p>NSW has been quite fortunate and hasn’t had to endure as many lockdowns as VIC however in general the impacts are being felt throughout and it is predicted some businesses may not survive this lockdown.</p><p>&nbsp;</p><p>You may find information at this link useful: https://www.nsw.gov.au/covid-19/financial-support</p><p>&nbsp;</p><p>There seems to be discussion in the media of further support but I haven’t seen anything finalised.</p><p>&nbsp;</p><p>If anyone has anything to contribute or wish to discuss that is relevant to NSW financial support, please share.</p><p>&nbsp;</p><p>Stay safe, Thank you</p>','2021-08-09 07:53:47.164309',2,'Life',0,'http://127.0.0.1:8000/media/post_image/2_zxKx8Ym.png',0,2),(18,'Private health','<p>Hi all</p><p>I currently have general private health insurance cover (dentist etc).</p><p>&nbsp;</p><p>Can someone explain how the rebate works and if I can claim it in my tax return?</p><p>&nbsp;</p><p>According to the ATO I can claim the rebate as an offset in my tax return</p><p>https://www.ato.gov.au/Individuals/Medicare-and-private-health-insurance/Private-health-insurance-rebate/</p><p>&nbsp;</p><p>However, this article mentions that you need to be paying for private hospital cover.</p><p>https://www.ato.gov.au/Individuals/Medicare-and-private-health-insurance/Private-health-insurance-rebate/Private-health-insurance-rebate-eligibility/#Complyinghealthinsurancepolicy</p><p>&nbsp;</p><p>Thanks</p>','2021-08-09 07:54:46.734718',2,'Health',0,'http://127.0.0.1:8000/media/post_image/3.jpeg',0,6),(19,'Private health funds','<p>Hello Everyone, this is the first time I am using my private health insurance (medibank) for a hospital stay. I\'ve been with them for ~ 9 years and pay a monthly premium of ~$360.</p><p>I need a surgery for which the surgeon fee is $3800 and the medicare schedule fee is $750. Medicare pays $550 of that and Medibank pays the rest of $200. This is really frustrating since it\'s less the my monthly premium. I understand they also pay some of the hospital stay fees, but for such a high monthly premium I\'d expect they covered more of the specialist fee. Medibank told me they can only pay UP TO the Medicare schedule fee, but this is not true. Info on health.gov says that the private fund must pay AT LEAST up to the Medicare schedule fee, and Medibank chooses to pay the minimum.</p><p>So my question is: do any of the private funds cover more than the Medicare schedule fee? Otherwise it\'s hard to justify paying ~ $30,000 in premiums over 9 years, if they only pay such a small proportion of the specialist fees for hospital stays.</p>','2021-08-09 07:55:32.370303',2,'Health',0,'http://127.0.0.1:8000/media/post_image/4.jpeg',0,6),(20,'Vaccine (HPV)','<p>Has anybody sought to obtain the Gardasil vaccine for themselves as an adult? If so was the process straightforward, how much did it cost?</p><p>&nbsp;</p><p>Background: After getting my second COVID vaccine I looked up my vaccination record. I see that a vaccine for HPV is available as a paid vaccination for people above school-age children.</p><p>&nbsp;</p><p>I’m a adult who is very unlikely to have contracted HPV as I’ve never engaged in sexual activity with another person. I am seeing my GP soon to enquire whether it would be worth getting the three-dose Gardasil shot to prevent contracting and spreading of HPV if I do engage in sexual activities in the future.</p>','2021-08-09 07:57:57.650285',2,'Health',0,'http://127.0.0.1:8000/media/post_image/5.jpeg',0,7),(21,'Dating Strategy','<p>You\'re on a date and the person is clearly smitten. It\'s clear you\'ve been brought together by the universe for a reason, they tell you, and they can see having children with you. And oh, wouldn\'t it be great to hop on a plane and go on that bucket-list trip together soon? Like next week?</p><p>No, you\'re not on an episode of&nbsp;<em>The Bachelor or Bachelorette</em>. It\'s real life. And it\'s your first or second date. Could this person be \"future faking\" you? Here\'s everything you need to know about this manipulative dating strategy, why it\'s a sign you could be seeing a narcissist, and how to avoid becoming a victim.</p><h2><strong>What is future faking?</strong></h2><p>\"Future faking is when someone uses a detailed vision of the future to facilitate the bonding and connection in a romantic relationship,\"&nbsp;<a href=\"https://manhattanpsychologist.com/\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"color: rgba(0, 0, 0, 0.95);\">Greg Kushnick, PsyD,</a>&nbsp;a psychologist based in New York City, tells&nbsp;<em>Health</em>. It\'s generally something that narcissists do, adds Kushnick; it\'s their way of getting attention and admiration from you.</p><p>On the outside, future faking might seem like you\'re experiencing the meet-cute of a romantic comedy. \"It\'s a charming, magnetic, oxygen-fueled experience,\"&nbsp;<a href=\"https://danielsokaltherapy.com/about/\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"color: rgba(0, 0, 0, 0.95);\">Dan Sokal, LCSW,</a>&nbsp;a licensed psychotherapist and trained psychoanalyst in New York City, tells&nbsp;<em>Health</em>.</p><p><strong>RELATED:&nbsp;</strong><a href=\"https://www.health.com/relationships/types-of-narcissism\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"color: rgba(0, 0, 0, 0.95);\"><strong>The 3 Types of Narcissism—And Why You Need to Know the Differences, According to Experts</strong></a></p><p>At its root, future faking is meant to be manipulative. \"In most situations, it\'s not intentional,\" says Kushnick. \"Many narcissists are very impulsive when it comes to having romantic feelings. And in that impulsivity, they promise someone the world.\" (That said, narcissism exists on a spectrum. People who fall into the \"malignant narcissist\" category can have premeditated motives, he explains.)</p><p>So you can\'t assume the other person is acting maliciously and trying to fool you; \"they actually believe what they\'re saying to you to be true during the initial courting period. Until they don\'t,\" Kushnick says.</p><p>If you\'re on the receiving end of future faking, you can really suffer emotionally. Because even if it\'s not intentional, the end result is that the relationship tends to blow up in painful ways.</p><p><br></p>','2021-08-09 10:14:50.884053',1,'Health',1,'http://127.0.0.1:8000/media/post_image/food_health_8mEzm3b.jpeg',0,8),(22,'Australian returning','<p class=\"ql-align-justify\">	Scott Morrison has stared down a group of Australians who are angy and frustrated about a major change to Covid-19 travel rules.</p><p class=\"ql-align-justify\">	The prime minister has changed a border rule that allowed expats living abroad to fly back after visiting Australia.</p><p class=\"ql-align-justify\">	Mr Morrison said he didn’t want people to keep “going out and in, and out and in”.</p><p class=\"ql-align-justify\">	“That has an impact on quarantine spaces and we obviously want to maximise those to have as many as possible who are returning home,” Scott Morrison said.</p><p class=\"ql-align-justify\">	“We want to provide as many of those opportunities as we can, but equally as I’m sure Australians understand, in this phase, we took the decision to half the amount of people coming back into Australia at the moment because of the Delta strain of this virus.”</p><p class=\"ql-align-justify\">	Mr Morrison acknowledged that many were fed up with the Covid-19 situation in the country, which has caused his government to prevent tens of thousands of Australians to return home from overseas.</p><p class=\"ql-align-justify\">	“I know Australians are frustrated,” Mr Morrison said.</p><p class=\"ql-align-justify\">&nbsp;	“I know they’re sick of it. I know they’re angry. I know they want it to stop and for life to get back to where they knew it.</p><p class=\"ql-align-justify\">	“But what we have to do now is recognise the reality of the challenge we have in front of us. None of us likes it. None of us likes to have restrictions. None of us likes to have the situation we’re having now.”</p><p><br></p>','2021-08-09 10:22:32.168687',1,'Work',1,'http://127.0.0.1:8000/media/post_image/1_5ei2Do4.jpeg',0,9),(23,'pregnancy problems','<p>High blood pressure, also called hypertension, occurs when arteries carrying blood from the heart to the body organs are narrowed. This causes pressure to increase in the arteries. In pregnancy, this can make it hard for blood to reach the placenta, which provides nutrients and oxygen to the fetus.<a href=\"https://www.nichd.nih.gov/health/topics/pregnancy/conditioninfo/complications#f1\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"color: rgb(50, 119, 179);\">1</a>&nbsp;Reduced blood flow can slow the growth of the fetus and place the mother at greater risk of preterm labor and preeclampsia.<a href=\"https://www.nichd.nih.gov/health/topics/pregnancy/conditioninfo/complications#f1\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"color: rgb(50, 119, 179);\">1</a>,<a href=\"https://www.nichd.nih.gov/health/topics/pregnancy/conditioninfo/complications#f2\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"color: rgb(50, 119, 179);\">2</a></p><p>Women who have high blood pressure before they get pregnant will continue to have to monitor and control it, with medications if necessary, throughout their pregnancy. High blood pressure that develops in pregnancy is called gestational hypertension. Typically, gestational hypertension occurs during the second half of pregnancy and goes away after delivery.</p><p><a href=\"https://www.nichd.nih.gov/health/topics/diabetes/Pages/default.aspx\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"color: rgb(50, 119, 179);\">Gestational diabetes</a>&nbsp;occurs when a woman who didn\'t have diabetes before pregnancy develops the condition during pregnancy.</p><p>Normally, the body digests parts of your food into a sugar called glucose. Glucose is your body\'s main source of energy. After digestion, the glucose moves into your blood to give your body energy.</p><p>To get the glucose out of your blood and into the cells of your body, your pancreas makes a hormone called insulin. In gestational diabetes, hormonal changes from pregnancy cause the body to either not make enough insulin, or not use it normally. Instead, the glucose builds up in your blood, causing diabetes, otherwise known as high blood sugar.</p><p>Managing gestational diabetes, by following a treatment plan outlined by a health care provider, is the best way to reduce or prevent problems associated with high blood sugar during pregnancy. If not controlled, it can lead to high blood pressure from preeclampsia and having a large infant, which increases the risk for cesarean delivery.</p><p>Infections, including some sexually transmitted infections (STIs), may occur during pregnancy and/or delivery and may lead to complications for the pregnant woman, the pregnancy, and the baby after delivery. Some infections can pass from mother to infant during delivery when the infant passes through the birth canal; other infections can infect a fetus during the pregnancy.1 Many of these infections can be prevented or treated with appropriate pre-pregnancy, prenatal, and postpartum follow-up care.</p>','2021-08-09 10:29:01.641609',1,'Life',1,'http://127.0.0.1:8000/media/post_image/5_yWKC3Vy.jpeg',0,10),(24,'Tokyo Olympics','<p>The United States top the medal table for the sixth time in seven Olympic Games. At all seven, they have won the most medals.</p><p>Japan\'s third place in the medal table - with 58 medals including 27 gold - is the country\'s joint best with Tokyo 1964 when hosting and Mexico 1968.</p><p>Great Britain finished second in Rio 2016 and third in London 2012. However, this is Team GB\'s second best performance at an overseas Olympics, after Rio (67 medals).</p>','2021-08-09 10:38:25.897565',0,'Health',1,'http://127.0.0.1:8000/media/post_image/_119840257_bbcsport_gb_medal_standings_tokyo_2020.jpeg',0,10);
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_blog_collections`
--

DROP TABLE IF EXISTS `user_blog_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_blog_collections` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `is_like` tinyint(1) NOT NULL,
  `post_id` int NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_blog_collections_post_id_23a6f36e_fk_posts_id` (`post_id`),
  KEY `user_blog_collections_user_id_3eaf44ee_fk_users_user_id` (`user_id`),
  CONSTRAINT `user_blog_collections_post_id_23a6f36e_fk_posts_id` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`),
  CONSTRAINT `user_blog_collections_user_id_3eaf44ee_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_blog_collections`
--

LOCK TABLES `user_blog_collections` WRITE;
/*!40000 ALTER TABLE `user_blog_collections` DISABLE KEYS */;
INSERT INTO `user_blog_collections` VALUES (1,1,15,4),(3,1,21,8),(4,1,22,9),(5,1,23,10),(6,1,24,10);
/*!40000 ALTER TABLE `user_blog_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `username` varchar(20) NOT NULL,
  `user_id` int NOT NULL AUTO_INCREMENT,
  `phone_number` varchar(11) DEFAULT NULL,
  `email` varchar(254) NOT NULL,
  `status` smallint NOT NULL,
  `checked` tinyint(1) NOT NULL,
  `gender` smallint NOT NULL,
  `birthday` date DEFAULT NULL,
  `address` longtext,
  `hobby` varchar(50) DEFAULT NULL,
  `personal_info` longtext,
  `avatar` varchar(200) DEFAULT NULL,
  `created_time` datetime(6) DEFAULT NULL,
  `last_mod_time` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('pbkdf2_sha256$260000$Lm3KJGl2QQB85m0CL2OtMj$xtTeEakSEmVnFaQcj4CiEzwC/bYGgwFlITcQAajMYCU=','2021-08-09 05:21:40.536379',1,'','',1,1,'2021-08-09 05:21:24.109705','admin',1,NULL,'admin@gmail.com',0,0,0,NULL,NULL,NULL,NULL,NULL,'2021-08-09 05:21:24.235574','2021-08-09 05:21:24.235587'),('pbkdf2_sha256$260000$C3ppDD5ogvku0ocOZOhw1n$tZPFA1mLdvayTyXBL9ADEyaE1G1JtLRYZ9riCaH5RK8=','2021-08-09 07:51:59.109984',0,'','',0,1,'2021-08-09 05:32:59.853237','Kim',2,NULL,'jin_hx@icloud.com',0,0,0,NULL,NULL,NULL,NULL,'http://127.0.0.1:8000/media/post_image/788bdf3e-2b79-4c02-8b60-e7e4a0f97d7f.png','2021-08-09 05:32:59.853237','2021-08-09 07:17:26.913317'),('pbkdf2_sha256$260000$V79rH17m0ejB2qFNmptCS3$xrTfA1sV+5k1mUNoes92dE6UovOlzZZu3B37/1Pt1ZE=','2021-08-09 07:58:24.132155',0,'','',0,1,'2021-08-09 05:33:34.686960','Rebecca Le May',3,NULL,'jin_hx@163.com',1,1,0,NULL,NULL,NULL,NULL,'http://127.0.0.1:8000/media/post_image/f61996d3-1712-418c-a705-0028cec8b16c.png','2021-08-09 05:33:34.687958','2021-08-09 07:18:40.512172'),('pbkdf2_sha256$260000$X91UJXrkkORSuSxoMpHIuu$H71OfZRlDc4be7Iwfhy3uzxSNQ2PaGU+2AZsdreXe78=','2021-08-09 08:02:37.417152',0,'','',0,1,'2021-08-09 06:58:40.813258','Ellen Ransley',4,NULL,'hongxiao.jinx@gmail.com',1,1,0,NULL,NULL,NULL,NULL,'http://127.0.0.1:8000/media/post_image/%E5%A4%B4%E5%83%8F_3.png','2021-08-09 06:58:40.813258','2021-08-09 07:19:42.160952'),('pbkdf2_sha256$260000$mgHFUPLlYxssWWZslFPUe1$IkLaZLrJ0EkgCrVyIdpOJucZvaKTBA8hP4EiRb+qKvc=','2021-08-09 08:03:57.738600',0,'','',0,1,'2021-08-09 07:01:17.859846','Shannon Molloy',5,NULL,'203760028@qq.com',1,0,0,NULL,NULL,NULL,NULL,'http://127.0.0.1:8000/media/post_image/2a3bcd9d-6c3d-481c-9e18-7007d6394dc3.png','2021-08-09 07:01:17.859846','2021-08-09 07:17:04.330078'),('pbkdf2_sha256$260000$BUorGvNCb3qEZ4fimAfJMo$HM6YLeInHy4iDArXVDZ40AN9i9tUxbEOFyR4KOR9d2s=','2021-08-09 07:54:18.082961',0,'','',0,1,'2021-08-09 07:54:18.079050','kimiii',6,NULL,'jinxawsl@163.com',0,0,0,NULL,NULL,NULL,NULL,'http://127.0.0.1:8000/media/post_image/99292a3a-857a-4dc6-b4e4-38935a6ea640.png','2021-08-09 07:54:18.079050','2021-08-09 07:55:03.728090'),('pbkdf2_sha256$260000$qaxKPtg4Zg73TLWR3UqP9I$lBsQ15VEe3agOSk0qenpZJA0VS1+hnrpif7wM6azIAI=','2021-08-09 07:56:52.954203',0,'','',0,1,'2021-08-09 07:56:52.948362','Charles',7,NULL,'jinhx@163.com',0,0,0,NULL,NULL,NULL,NULL,'http://127.0.0.1:8000/media/post_image/df7e6190-89a6-4bbc-b113-5df4d96984cf.png','2021-08-09 07:56:52.948362','2021-08-09 07:57:03.460447'),('pbkdf2_sha256$260000$LsFWIrgYr8hCfWL3Olo5Fe$DB4628ZpFbDUCWTu+99CtB+2cismpgwpsxiyZDZTisg=','2021-08-09 09:48:11.922879',0,'','',0,1,'2021-08-09 09:48:11.913641','Liangyu Huang',8,'','liangyuhuang@outlook.com',1,0,0,NULL,NULL,'','','http://127.0.0.1:8000/media/post_image/WechatIMG194.jpg','2021-08-09 09:48:11.913995','2021-08-09 10:15:23.717610'),('pbkdf2_sha256$260000$H5CDIIhTtATGxdzlLyYSF4$jz9vDamOjj88HbDLiHI2b3vj774gJlBOlpCxYnDtUTM=','2021-08-09 10:17:52.175678',0,'','',0,1,'2021-08-09 10:17:52.171340','Sandy Smith',9,NULL,'Julian@gmail.com',1,0,0,'2021-05-05',NULL,NULL,NULL,'http://127.0.0.1:8000/media/post_image/image.jpeg','2021-08-09 10:17:52.171757','2021-08-09 10:20:43.420372'),('pbkdf2_sha256$260000$Vbw0cS1NvTxsEfbuLrAGnD$eq0+ltvMrQ38JktXSbuQR+bFedOBkozAQqK5PWHu/Ec=','2021-08-09 10:26:09.491621',0,'','',0,1,'2021-08-09 10:26:09.484858','Zhengyang Chi',10,NULL,'wood@gmail.com',1,0,0,NULL,NULL,NULL,NULL,'http://127.0.0.1:8000/media/post_image/123.jpg','2021-08-09 10:26:09.485219','2021-08-09 10:29:36.617017');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_groups_user_id_group_id_fc7788e8_uniq` (`user_id`,`group_id`),
  KEY `users_groups_group_id_2f3517aa_fk_auth_group_id` (`group_id`),
  CONSTRAINT `users_groups_group_id_2f3517aa_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `users_groups_user_id_f500bee5_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_groups`
--

LOCK TABLES `users_groups` WRITE;
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_user_permissions`
--

DROP TABLE IF EXISTS `users_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_user_permissions_user_id_permission_id_3b86cbdf_uniq` (`user_id`,`permission_id`),
  KEY `users_user_permissio_permission_id_6d08dcd2_fk_auth_perm` (`permission_id`),
  CONSTRAINT `users_user_permissio_permission_id_6d08dcd2_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `users_user_permissions_user_id_92473840_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_user_permissions`
--

LOCK TABLES `users_user_permissions` WRITE;
/*!40000 ALTER TABLE `users_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-09 18:40:02
