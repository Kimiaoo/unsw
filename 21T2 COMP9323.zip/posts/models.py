from django.db import models
from user_center.models import User


class Posts(models.Model):
    # The model of posts

    # post id, primary key
    id = models.AutoField(primary_key=True, unique=True, verbose_name='post_id')
    # author id, foreignkey related to table user_info
    author = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='user', null=True)
    # title of the post
    title = models.CharField(max_length=20, verbose_name='title', default='')
    # content of the post
    content = models.TextField(blank=True, null=True, verbose_name='content')
    # created time of the post, automatically generated
    create_time = models.DateTimeField(verbose_name='create time', auto_now_add=True, null=True)
    # Status of the post
    # 0 means the post is an announcement
    # 1 means the post is an article
    # 2 means the post is a question
    sts_choices = [(0, 'announcement'), (1, 'article'), (2, 'question')]
    sts = models.IntegerField(choices=sts_choices, default=0)

    # the category of the posts
    # our origin design was multiple levels of categories
    # so this attribute is called first category here
    first_category = models.CharField(max_length=20, null=True)

    # number of followers (who like the post)
    follow_nb = models.IntegerField(default=0, verbose_name='follower number')

    # the cover image of the post
    post_image = models.CharField(verbose_name='post image', max_length=200, null=True, blank=True)

    # on our homepage, we have a section called "Must see" at the top
    # posts in this section are chosen by project admin
    # this attribute should be manually set and changed by project admin
    # default value is false
    must_see = models.BooleanField(default=False)

    # following codes helps to manage the project through django admin tool
    class Meta:
        verbose_name = 'Post management'
        verbose_name_plural = verbose_name
        ordering = ['-id']
        db_table = 'posts'


class UserBlogCollections(models.Model):
    # the many-to-many relationship between user and post

    # post_id, foreignkey related to table posts
    post = models.ForeignKey(Posts, on_delete=models.CASCADE, related_name='user_post')
    # user_id, foreignkey related to table user_info
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='users')
    # the boolean attribute to store the relationship
    is_like = models.BooleanField(default=False)

    # following codes helps to manage the project through django admin tool
    class Meta:
        verbose_name = 'User Blog Collections'
        verbose_name_plural = verbose_name
        ordering = ['-id']
        db_table = 'user_blog_collections'
