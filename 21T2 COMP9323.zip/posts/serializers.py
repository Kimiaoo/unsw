from rest_framework.serializers import ModelSerializer
from rest_framework import serializers
from .models import Posts, UserBlogCollections
from comments.serializers import CommentSerializer

"""
For the detailed explanations of serializers, please refer to Django
Restful Framework official documentation.
"""


class PostListSerializer(ModelSerializer):
    # list of posts
    class Meta:
        model = Posts
        fields = "__all__"


class PostInfosSerializer(ModelSerializer):
    """
    This serializer generates the information of a particular
    post (for general use).

    In the model of posts, we only store id of the author.
    But to help front-end to display other information such as
    username and avatar, we need to implement new methods.

    SerializerMethodField()  means that we want to add additional attribute
    through defining respective method.
    """
    post_username = serializers.SerializerMethodField()
    post_username_avatar = serializers.SerializerMethodField()
    is_like = serializers.SerializerMethodField()

    class Meta:
        model = Posts
        fields = "__all__"

    def get_post_username(self, obj):
        # get the username of post's author
        if obj.author.username:
            return obj.author.username
        else:
            return None

    def get_post_username_avatar(self, obj):
        # get the avatar of post's author
        if obj.author.avatar:
            return str(obj.author.avatar)
        else:
            return None

    def get_is_like(self, obj):
        # query whether current user like the post
        try:
            user_id = self.context.get("request").user.user_id
        except AttributeError:
            # if current user has not logged in
            return False

        User_blog = UserBlogCollections.objects.filter(post_id=obj.id, user_id=user_id)
        if not User_blog:
            # if current user has not logged in
            # or do not like the
            return False
        is_like = User_blog.first().is_like

        return is_like


class UserBlogCollectionsSerializer(ModelSerializer):
    """
    This serializer saves the like relationship between user and post.
    It also updates the follow_nb of the post.
    """
    class Meta:
        model = UserBlogCollections
        fields = "__all__"

    def create(self, validated_data):
        # create new record
        user_blog_collection = UserBlogCollections.objects.create(**validated_data)
        # update Posts.follow_nb
        post_instance = Posts.objects.filter(id=validated_data.get('post').id).first()
        post_instance.follow_nb += 1
        post_instance.save()
        return user_blog_collection

     
class PostDetailSerializer(PostInfosSerializer):
    """
    In the detail page of a post, we need comments besides the Post information
    """
    comments = CommentSerializer(many=True, read_only=True)

    class Meta:
        model = Posts
        fields = "__all__"


class SearchSerializer(ModelSerializer):
    """
    This serializer does similar job to PostInfosSerializer,
    but it returns required data for searching feature.
    """

    # automatically get author_id
    sts = serializers.SerializerMethodField()
    author = serializers.StringRelatedField()
    is_like = serializers.SerializerMethodField()
    post_username = serializers.SerializerMethodField()

    def get_sts(self, obj):
        return obj.get_sts_display()

    def get_post_username(self, obj):
        # get the username of post's author
        if obj.author.username:
            return obj.author.username
        else:
            return None

    def get_is_like(self, obj):
        # query whether current user like the post
        user_id = self.context.get("request").user.user_id
        User_blog = UserBlogCollections.objects.filter(post_id=obj.id, user_id=user_id)
        if not User_blog:
            # if current user has not logged in
            # or do not like the post
            return False
        is_like = User_blog.first().is_like
        return is_like

    class Meta:
        model = Posts
        fields = "__all__"


class RecommendSerializer(ModelSerializer):
    """
    This serializer does similar job to PostInfosSerializer,
    but it returns required data for (random) recommendation feature.
    """
    sts = serializers.SerializerMethodField()
    author_name = serializers.CharField(source='author', read_only=True)
    author_desc = serializers.CharField(source='author.personal_info', read_only=True)
    author_avatar = serializers.CharField(source='author.avatar', read_only=True)
    author_email = serializers.EmailField(source='author.email', read_only=True)
    user_create_time = serializers.DateTimeField(source='author.created_time', read_only=True)

    def get_sts(self, obj):
        return obj.get_sts_display()

    def get_is_like(self, obj):
        return False

    class Meta:
        model = Posts
        # all required attributes
        fields = ["id", "author", "author_name", "author_desc", "author_email", "author_avatar", "user_create_time",
                  "title", "content", "create_time", "first_category", "follow_nb", "post_image", "sts"]


class CategorySerializer(ModelSerializer):
    """
    This serializer let query only returns first_category.
    """
    class Meta:
        model = Posts
        fields = ['first_category']


class ArticleListSerializer(ModelSerializer):
    """
    This serializer let query returns status of posts (include post, announcement, article), post's id, post's follow number
    """
    sts = serializers.SerializerMethodField()

    # status is stored in database as integer, but we want to return the string of status(post, announcement, article)
    # this method allows status return as string
    def get_sts(self, obj):
        return obj.get_sts_display()

    class Meta:
        model = Posts
        fields = ['id', 'sts', 'follow_nb']