from django.test import TestCase

# Create your tests here.
from rest_framework.authentication import SessionAuthentication, BasicAuthentication


# close csrf
class CsrfCloseAuthentication(SessionAuthentication):

    def enforce_csrf(self, request):
        return
