from django.urls import path
from .views import PostDetail, PostsList, PublishPost, MyFavoritePostsApiView, \
    PostHomeMustSee, SearchByCategory, Recommendation, PostHomeAnnouncement, PostHomeArticle, CategoryList, \
    ArticleList, PostAuthorList, PostAuthorTop

# registering the app_name helps to manage the project
app_name = 'posts'

urlpatterns = [
    # get list of the post using PostsList in views.py
    path('list/', PostsList.as_view(), name='list'),
    # publish a new post using PublishPost in views.py
    path('publish/', PublishPost.as_view(), name='publish'),
    # get access to particular post through pk (primary key)
    # using PostDetail in the view.py
    path('<int:pk>/', PostDetail.as_view(), name='detail'),
    # the like feature
    path(r'favor/', MyFavoritePostsApiView.as_view(), name='posts'),
    # six sections of the homepage, more explanation in views.py
    path('home/must_see/', PostHomeMustSee.as_view(), name='home_must_see'),
    path('home/announcement/', PostHomeAnnouncement.as_view(), name='home_announcement'),
    path('home/article/', PostHomeArticle.as_view(), name='home_article'),
    path('recom/', Recommendation.as_view(), name='recom'),
    path('author/', PostAuthorList.as_view(), name='author_list'),
    path('author/top/', PostAuthorTop.as_view(), name='author_top'),
    # searching feature
    path('search/', SearchByCategory.as_view(), name='search'),
    path('search/article/', ArticleList.as_view(), name='search_article'),
    # category info
    path('category/', CategoryList.as_view(), name='category'),
]
