from django.db.models import Q
from rest_framework.authentication import BasicAuthentication
from rest_framework.generics import UpdateAPIView
from rest_framework.permissions import IsAuthenticated, IsAuthenticatedOrReadOnly
from rest_framework.response import Response
from rest_framework.generics import ListAPIView, RetrieveUpdateDestroyAPIView, CreateAPIView
from .models import Posts, UserBlogCollections
from .serializers import PostListSerializer, PostDetailSerializer, PostInfosSerializer,SearchSerializer,\
    RecommendSerializer, UserBlogCollectionsSerializer, CategorySerializer, ArticleListSerializer
from .tests import CsrfCloseAuthentication
import random

"""
A very short explanation of how queryset and serializer_class work
can be found in comments\\views.py. Please refer to Django
Restful Framework official documentation for more information
"""

class PostAuthorList(UpdateAPIView):
    """
    On the homepage, we have a section where we show some information about
    experts/organizations.
    This view returns all the posts of a particular user.
    """
    permission_classes = []
    authentication_classes = []
    serializer_class = PostListSerializer

    def update(self, request, *args, **kwargs):
        # filter the database
        post_instance = Posts.objects.filter(author=request.data['author'])
        # generate the serializer
        post_ser = PostListSerializer(post_instance, context={"request": request}, many=True)

        return Response({
            "code": 200,
            "message": "Get post list successfully",
            "data": {
                "all_post": post_ser.data,
            }
        })


class PostAuthorTop(UpdateAPIView):
    """
    On the homepage, we have a section where we show some information about
    experts/organizations.
    This view returns top 3 followed posts of a particular user.
    """
    permission_classes = []
    authentication_classes = []
    serializer_class = PostListSerializer

    def update(self, request, *args, **kwargs):
        # filter the database
        post_instance = Posts.objects.filter(author=request.data['author']).order_by('-follow_nb')
        # generate the serializer
        post_ser = PostListSerializer(post_instance, context={"request": request}, many=True)

        return Response({
            "code": 200,
            "message": "Get post list successfully",
            "data": {
                "all_post": post_ser.data[:3],
            }
        })


class PostHomeMustSee(ListAPIView):
    """
    On the homepage, we have a section called "Must see" at the top.
    Posts in this section are chosen by project admin
    """
    permission_classes = []
    authentication_classes = []
    queryset = Posts.objects.filter(must_see=True)
    serializer_class = PostInfosSerializer


class PostHomeAnnouncement(ListAPIView):
    """
    On the homepage, we have a section, where we show top 3 followed announcements.
    """
    permission_classes = []
    authentication_classes = []
    queryset = Posts.objects.filter(sts=0).order_by('-follow_nb')[:3]
    serializer_class = PostInfosSerializer


class PostHomeArticle(ListAPIView):
    """
    On the homepage, we have a section, where we show top 3 followed articles.
    """
    permission_classes = []
    authentication_classes = []
    queryset = Posts.objects.filter(sts=1).order_by('-follow_nb')[:3]
    serializer_class = PostInfosSerializer


class PostDetail(RetrieveUpdateDestroyAPIView):
    """
    Show the information of a particular post
    and its comments
    """
    permission_classes = []
    authentication_classes = [CsrfCloseAuthentication, BasicAuthentication]
    queryset = Posts.objects.all()
    serializer_class = PostDetailSerializer


class PostsList(ListAPIView):
    """
    Show the information of all posts in a list form
    """
    permission_classes = []
    authentication_classes = [CsrfCloseAuthentication, BasicAuthentication]
    queryset = Posts.objects.all()
    serializer_class = PostInfosSerializer


class PublishPost(CreateAPIView):
    """
    Publish a new post
    """
    permission_classes = []
    authentication_classes = []
    queryset = Posts.objects.all()
    serializer_class = PostListSerializer

    def create(self, request, *args, **kwargs):
        # Rewriting the method from CreateAPIView

        # get data from request
        serializer = self.get_serializer(data=request.data)
        # raise an exception if not valid data received
        serializer.is_valid(raise_exception=True)
        # write data to the database
        self.perform_create(serializer)

        # return success message back to front-end
        headers = self.get_success_headers(serializer.data)
        return Response({
            "code": 201,
            "message": "published successfully"
        }, headers=headers)


class MyFavoritePostsApiView(ListAPIView, UpdateAPIView):
    """
    This view returns the list of posts, which are liked by current
    logged in user (or this user's own post).
    Since this feature needs user to log in, the following classes are
    not empty.

    The like feature is also realized by this view. Details are in the
    update() function below.
    """
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [CsrfCloseAuthentication, BasicAuthentication]
    serializer_class = PostInfosSerializer

    def list(self, request, *args, **kwargs):
        post_instance_all = None
        # generate a query to store the index of user's liked post
        Q_list = Q()

        # User's own post
        post_instance = Posts.objects.filter(author=request.user.user_id)
        # Posts liked by the user
        collection_instances = UserBlogCollections.objects.filter(user_id=request.user.user_id)

        # get id of user's liked post in UserBlogCollections and use filter to get post detail information from Posts
        if collection_instances:
            for collection in collection_instances:
                Q_list.add(Q(id=collection.post.id), Q.OR)
            collection_post_instance = Posts.objects.filter(Q_list)

            # Union all records
            if post_instance:
                post_instance_all = post_instance.union(collection_post_instance)
            else:
                post_instance_all = collection_post_instance
        # Sort all records by the follow_nb and create_time in a descending order
        if post_instance_all:
            post_instance_all_order = post_instance_all.order_by('-follow_nb', '-create_time')
        else:
            post_instance_all_order = None
        # generate the serializer
        post_ser = PostInfosSerializer(post_instance_all_order, context={"request": request}, many=True)

        return Response({
            "code": 200,
            "message": "Get post list successfully",
            "data": {
                # all posts
                "posts_all": post_ser.data,
                # latest five
                "posts_five": post_ser.data[:5]
            }
        })

    def update(self, request, *args, **kwargs):
        """
        This function realize the like(and dislike) feature. It receives post_id from
        the request parameters and user_id from session.
        """
        favor_id = request.query_params.get('id')
        if not favor_id:
            return Response({
                "code": 400,
                "message": "Enter a valid post id",
                "data": None
            })

        # First we need to know whether this user has already liked this post
        collection_instances = UserBlogCollections.objects.filter(user_id=request.user.user_id,
                                                                  post_id=favor_id).first()
        if collection_instances:
            # If the answer is yes, then the user actually wants to dislike the post
            post_instance = Posts.objects.filter(id=collection_instances.post_id).first()
            post_instance.follow_nb -= 1
            post_instance.save()
            collection_instances.delete()
            return Response({
                "code": 200,
                "message": "Cancel Like successfully",
                "data": None
            })

        else:
            # If the answer is no, then the user wants to like the post
            collection_ser = UserBlogCollectionsSerializer(data={
                "user": request.user.user_id,
                "post": favor_id,
                "is_like": True
            })
            if collection_ser.is_valid():
                collection_ser.save()
                return Response({
                    "code": 200,
                    "message": "Like successfully",
                    "data": None
                })
            else:
                return Response({
                    "code": 400,
                    "message": "Cannot find the post id",
                    "data": None
                })


class SearchByCategory(ListAPIView, CreateAPIView):
    """
    This view corresponds to the search feature. Our feature supports search by category.
    """
    permission_classes = []
    authentication_classes = []
    serializer_class = SearchSerializer

    def create(self, request, *args, **kwargs):
        # get parameters from request
        paras = request.data
        # if no search pattern (text)
        if 'text' not in paras:
            paras['text'] = None
        # if the search is a general one (without category)
        if 'first_category' not in paras:
            paras['first_category'] = None
        # if only want to search articles with particular status
        if 'sts' not in paras:
            paras['sts'] = None

        if 'first_category' in paras and paras['first_category']:
            # search in the category
            if paras['text']:
                post_instance = Posts.objects.filter(first_category=paras['first_category'],
                                                     title__contains=paras['text'])
            else:
                post_instance = Posts.objects.filter(first_category=paras['first_category'])
        # general search
        elif 'text' in paras and paras['text']:
            post_instance = Posts.objects.filter(title__contains=paras['text'])

        else:
            # both text and category are none
            post_instance = Posts.objects.all()
        # search status of article
        if 'sts' in paras and paras['sts']:
            post_instance = post_instance.filter(sts=int(paras['sts']))

        if post_instance:
            # sort the result
            post_instance = post_instance.order_by('-id')

        # check that whether current user has logged on
        if request.user.is_authenticated:
            # if the answer is yes

            # generate the serializer
            search_result = SearchSerializer(post_instance, context={"request": request}, many=True)
            return Response({
                "code": 200,
                "message": "Get posts successfully",
                "data": {
                    "posts": search_result.data
                }
            })
        else:
            # if the answer is no

            search_result = RecommendSerializer(post_instance, context={"request": request}, many=True)

            # split the pages based on received parameters
            if 'page' not in paras or not paras['page']:
                return Response({
                    "code": 200,
                    "message": "Get posts successfully",
                    "data": {
                        "posts": search_result.data
                    }
                })
            else:
                page_num = paras['page']
                post_num = 2
                # split the page
                start_page = (page_num - 1) * post_num
                end_page = page_num * post_num

                return Response({
                    "code": 200,
                    "message": "Get posts successfully",
                    "data": {
                        "posts_in_one_page": search_result.data[start_page: end_page],
                        "posts_all": search_result.data
                    }
                })


class Recommendation(ListAPIView, CreateAPIView):
    """
    Randomly recommend posts.
    Default number of posts is six.
    It can be also specified by the parameter.
    """
    permission_classes = []
    authentication_classes = []
    serializer_class = RecommendSerializer

    def create(self, request, *args, **kwargs):
        paras = request.data
        # generate query to store index
        Q_list = Q()

        # return 6 posts by default
        if 'post_num' not in paras or not paras['post_num']:
            paras['post_num'] = 6

        # query the database
        post_instance = Posts.objects.all()
        # generate list of random numbers
        random_list = [random.randint(1, len(post_instance)) for _ in range(paras['post_num'])]

        # generate an index query to let post filter the data
        if random_list:
            for num in random_list:
                Q_list.add(Q(id=num), Q.OR)
            post_instance = Posts.objects.filter(Q_list)

        # sort the records
        if post_instance:
            post_instance = post_instance.order_by('-follow_nb', '-id')
        else:
            post_instance = None

        # generate the serializer
        search_result = RecommendSerializer(post_instance, many=True)

        # return the result
        return Response({
            "code": 200,
            "message": "Get Recommendation successfully",
            "data": {
                "posts": search_result.data
            }
        })


class CategoryList(ListAPIView):
    """
    Return all categories of posts.
    """
    permission_classes = []
    authentication_classes = []

    serializer_class = CategorySerializer

    def list(self, request, *args, **kwargs):
        # query the database
        post_instance = Posts.objects.all()

        # generate the serializer
        post_instance = CategorySerializer(post_instance,  context={"request": request}, many=True)

        # get category from every posts and then drop duplicates
        category = set([x['first_category'] for x in post_instance.data])

        # return the result
        return Response({
            "code": 200,
            "message": "Get CategoryList successfully",
            "data": {
                "category": category
            }
        })


class ArticleList(ListAPIView):
    """
    Posts ID with its status (include: post, article, announcement)
    Return all status of posts and post id
    """
    permission_classes = []
    authentication_classes = []

    serializer_class = ArticleListSerializer

    def list(self, request, *args, **kwargs):
        # query the database
        post_instance = Posts.objects.all()
        # order the query by attribute follow_nb, id
        post_instance = post_instance.order_by('-follow_nb', '-id')
        # generate the serializer
        post_instance = ArticleListSerializer(post_instance,  context={"request": request}, many=True)

        # store all status of posts and post id in a dict
        article_dict = {}
        for x in post_instance.data:
            # if key is not in the dict, generate a list and store the value
            if x['sts'] not in article_dict:
                article_dict[x['sts']] = [x['id']]
            # if key is not in the dict, append value
            else:
                article_dict[x['sts']].append(x['id'])

        # return the result
        return Response({
            "code": 200,
            "message": "Get ArticleList successfully",
            "data": {
                "example:": "sts:[article_id]",
                "article_status": article_dict
            }
        })