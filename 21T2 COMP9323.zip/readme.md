# Well-being

This is the project for COMP9323.

## Project description

In this project, we aim to bulid an article website and Q&A forum to help employee solve their well-being related problems.

The requirements shown below:

​	(i) Q&A to address people concerns

​	(ii) links to professionals and experts on concern matters

​	(iii) short videos

​	(iv) curation of up-to-date health and wellbeing information from other sources (e.g., experts, health information sources). Projects on this theme can focus on specific categories of people (e.g., students, vulnerable communities).

## Project technical stack

* Vue
* Django 3
* Django REST framework

## How to implement?

### Back-end Implement

#### 1. install packets:

**Please ensure python version is 3.7 or above.**

Run the command below to install packets:

**Windows/Linux**

```
pip install -r requirements.txt
```

**MacOS**

```
pip3 install -r requirements.txt
```

#### 2. create database

Install MySQL database(version: 8.0), and create user:

```
User name: root
Password: 123qweasd
Host: localhost
Port: 3306
```

Or you can set MySQL(version: 8.0) user information(user name, password, host, port) in ./app/setting.py:

<a href="https://ibb.co/PmwDGPD"><img src="https://i.ibb.co/0Dhsy6s/database-setting.png" alt="database-setting" border="0"></a>

Then, enter mysql, sql file will atomatically create a new database named django_vue_db and insert some sample data:

```
% mysql -u root -p
% source project_absolute_path/insert.sql;
```

<a href="https://ibb.co/7yQjfnT"><img src="https://i.ibb.co/BsGcpy7/sql.png" alt="sql" border="0"></a>

**If insert successfully, just skip to step5**.

#### 3. build database

**If you fail insert sql file, please follow the step 3~5 on back-end implenment part. Otherwise, you do not need to follow this step.**

Enter mysql, run the command below to use database:

```
% DROP Database IF EXISTS django_vue_db;
% CREATE Database django_vue_db;
% use django_vue_db;
```

Run the command below to build database:

**Windows/Linux**

```
% python manage.py makemigrations
% python manage.py migrate
```

**MacOS**

```
% python3 manage.py makemigrations
% python3 manage.py migrate
```

#### 4. create superuser

**If you fail insert sql file, please follow the step 3~5 on back-end implenment part. Otherwise, you do not need to follow this step.**

Run the command below to create superuser of web administer.

**Windows/Linux**

```
python manage.py createsuperuser
```

**MacOS**

```
python3 manage.py createsuperuser
```

#### 5. run server

Run the command below to run server:

**Windows/Linux**

```
python manage.py runserver
```

**MacOS**

```
python3 manage.py runserver
```

***



### Front-end Implement

#### 1. install node.js

#### 2. enter front-end folder path 

#### 3. npm install

run commend to install modules

```
npm install
```

#### 4. npm run serve

start serve

```
npm run serve
```

#### 5. visit http://localhost:8080/

## Access url

| Feature   | Front-end url                     | Back-end url                                | Need login? | Notes                       |
| --------- | --------------------------------- | ------------------------------------------- | ----------- | --------------------------- |
| Register  | http://localhost:8080/#/register  | http://127.0.0.1:8000/user_center/register/ | No          |                             |
| Login     | http://localhost:8080/#/login     | http://127.0.0.1:8000/user_center/login/    | No          |                             |
| Homepage  | http://localhost:8080/#/          |                                             | No          |                             |
| Q&A forum | http://localhost:8080/#/forum     |                                             | No          |                             |
| Logout    | http://localhost:8080/#/login     | http://127.0.0.1:8000/user_center/logout/   | Yes         |                             |
| Add post  | http://localhost:8080/#/addPost   |                                             | Yes         | Add new post                |
| Profile   | http://localhost:8080/#/profile   | http://127.0.0.1:8000/user_center/info/     | Yes         | Visit user's profile        |
| Favourite | http://localhost:8080/#/favourite | http://127.0.0.1:8000/posts/favor/          | Yes         | Visit user's favourite post |
| Admin*    | http://127.0.0.1:8000/admin/      | http://127.0.0.1:8000/admin/                | Yes         | Website management tools    |
| etc.      | -                                 | -                                           | -           | -                           |

*We have already create the website administrator anccount, if you insert sql file successfully. If you want to create your own administrator anccount, just skip to step 4 on back-end implement.

```
# website administrator's info
username: admin
password: admin
```

## Class explanation

* **DJANGO-SWAGGER DOES NOT SUPPORT DJANG 3.8 OR ABOVE, WHICH MAY LEAD CONFLICTS WITH DJANGO AND SWAGGER. IF SWAGGER RETURNS ERROR MESSAGE OR NOT HUMAN READABLE MESSAGE, PLEASE SEARCH THE CONTENT BELOW TO FIND ANSWER.**
* We recommend use postman to test api to aviod confilcts between django and swagger.
* Some api may need login at first



Swagger url: http://localhost:8000/swagger/  (Not all api works well in swagger)



### user_center ###

#### /user_center/register/

[post] http://127.0.0.1:8000/user_center/register/

Desc: User register and login

**Parameters**

Format: Json

| fields        | required | Type      | Notes                                           |
| ------------- | -------- | --------- | ----------------------------------------------- |
| username      | required | string    |                                                 |
| email         | required | string    |                                                 |
| password      | required | string    |                                                 |
| rtpassword    | required | string    | Re-enter password for double check              |
| status        | required | integer   | User status {0:user, 1:expert/organization}     |
| checked       | optional | bool      | Check if a user is expert/organization          |
| phone_number  | optional | integer   |                                                 |
| gender_choice | optional | integer   | Gender {0:unknown, 1:male, 2:female, 3:others}  |
| birthday      | optional | timestamp |                                                 |
| address       | optional | string    |                                                 |
| hobby         | optional | string    |                                                 |
| personal_info | optional | string    |                                                 |
| avatar        | optional | imageFile |                                                 |
| created_time  | optional | timestamp | User create timestamp（create automatically）   |
| last_mod_time | optional | timestamp | User modify timestamp（create automatically）） |

**Responses**

* Success

```Json
{
  "code":201,
  "message": "register successfully",
}
```

* Fail

User already exists

```Json
{
	"code":400,
  "username":["User management with this userName already exists."],
  "email":["User management with this email already exists."]}
}
```



#### /user_center/login/

[post] http://127.0.0.1:8000/user_center/login/

Desc: user login

**Parameters**

Format: Json

| fields   | required | Type   | Notes |
| -------- | -------- | ------ | ----- |
| Email    | required | String |       |
| Password | required | String |       |

**Responses**

Format: Json

* Success

```Json
{
    "code": 200,
    "message": "login successfully",
    "data": {
        "username": "",
        "password": "",
        "email": "",
        "status": 1
    }
}
```

* Fail

Unvalid email

```json
{
    "code": 400,
    "message": "Enter a valid email address",
    "data": None
}
```

Password or email incorrect

```json
{
  "code": 400,
  "message": "Your account or password is incorrect.",
  "data": None
}
```



#### /user_center/change/

[put] http://127.0.0.1:8000/user_center/change/

Desc: Change the password for current user.

**Parameters**

Format: Json

| fields              | required | Type   | Notes                        |
| ------------------- | -------- | ------ | ---------------------------- |
| old_password        | required | string |                              |
| new_password        | required | string | password user want change to |
| Retype_new_password | required | string | type again the new password  |

**Responses**

Format: Json

* Success

```json
{
  "code": 200,
  "message": "Password updated",
  "data": None
}
```

* Fail

```json
{
  "code": 400,
  "message": Django default error message,
  "data": None
}
```



#### /user_center/change/

[patch] http://127.0.0.1:8000/user_center/change/

Desc: **Django-Swagger conflict. NO USAGE!!!**



#### /user_center/info/ ####

[get] http://127.0.0.1:8000/user_center/info/

Desc: Get current user's personal information

**Responses**

Format: Json

* Success

```json
{
    "code": 200,
    "message": "user info shows successfully",
    "data": {
        "username": "",
        "user_id": 1,
        "email": "",
        "status": 1,
        "gender": 2,
        "birthday": "",
        "address": "",
        "hobby": "",
        "avatar": "",
        "phone_number": 123456789,
        "personal_info": "",
        "checked": ""
    }
}
```

* Fail

Change password

```json
{
  "code": 400,
  "message": "The password cannot be change here.",
  "data": None
}
```

Change email

```Json
{
  "code": 400,
  "message": "The email cannot be changed. If you want to change your email, please connect to website administrator",
  "data": None
}
```



#### /user_center/info/

[put/patch] http://127.0.0.1:8000/user_center/info/

Desc: Update current user's personal information

**Parameters**

Format: Json

| fields        | required | Type      | Notes                                          |
| ------------- | -------- | --------- | ---------------------------------------------- |
| status        | required | integer   | User status {0:user, 1:expert/organization}    |
| checked       | optional | bool      | Check if a user is expert/organization         |
| phone_number  | optional | integer   |                                                |
| gender_choice | optional | integer   | Gender {0:unknown, 1:male, 2:female, 3:others} |
| birthday      | optional | timestamp |                                                |
| address       | optional | string    |                                                |
| hobby         | optional | string    |                                                |
| personal_info | optional | string    |                                                |
| avatar        | optional | imageFile |                                                |
| created_time  | optional | timestamp | User create timestamp（create automatically）  |
| last_mod_time | optional | timestamp | User modify timestamp（create automatically）  |

**Responses**

Format: Json

* Success

```json
{
    "code": 200,
    "message": "user info shows successfully",
    "data": {
        "username": "",
        "user_id": 1,
        "email": "",
        "status": 1,
        "gender": 2,
        "birthday": "",
        "address": "",
        "hobby": "",
        "avatar": "",
        "phone_number": 123456789,
        "personal_info": "",
        "checked": ""
    }
}
```

* Fail

Change password

```json
{
  "code": 400,
  "message": "The password cannot be change here.",
  "data": None
}
```

Change email

```Json
{
  "code": 400,
  "message": "The email cannot be changed. If you want to change your email, please connect to website administrator",
  "data": None
}
```



#### /user_center/search/org/

[get] http://127.0.0.1:8000/user_center/search/org

Desc: Get all the users' information whose status is 1 (Get professionals' information)

**Responses**

* Success

```json
{
  "code": 200,
  "message": "Get professionals' info successfully",
  "data": [
    {
      "email": "",
      "status": "expert/organization",
      "avatar": "",
      "personal_info": ""
    },
    {
      "email": "",
      "status": "expert/organization",
      "avatar": "",
      "personal_info": ""
    }
  ]
}
```



#### /user_center/search/user_info/

[put/post] http://127.0.0.1:8000/user_center/search/user_info/

Desc: Get user's information by user_id

**Django-Swagger conflict!!! PLEASE USE POSTMAN**

**Parameters**

Format: Params

| fields  | required | Type    | Notes |
| ------- | -------- | ------- | ----- |
| user_id | required | integer |       |

**Responses**

Format: Json

* Success

```json
{
    "code": 200,
    "message": "Get user information successfully",
    "data": {
        "username": "",
        "user_id": 1,
        "email": "",
        "status": 1,
        "gender": 2,
        "birthday": "",
        "address": "",
        "hobby": "",
        "avatar": "",
        "phone_number": 123456789,
        "personal_info": "",
        "checked": false
    }
}
```

* Fail

User_id not exists

```Json
{
    "code": 400,
    "message": "User does not exists"
}
```



#### /user_center/logout/

[post] http://127.0.0.1:8000/user_center/logout/

Desc: User logout

**Responses**

* Success

```json
{
    "code": 200,
    "message": "Logout successfully",
    "data": null
}
```

* Fail

```json
{
    "code": 400,
    "message": "Authentication credentials were not provided."
}
```



### posts ###

#### /posts/author/ ####

[put] http://127.0.0.1:8000/posts/author/

Desc: Get all posts of a particular author

**Parameters**

Format: Json

| fields              | required | Type    | Notes                        |
| ------------------- | -------- | ------- | ---------------------------- |
| author              | required | integer |                              | 

**Responses**

Format: Json

* Success

```json
{
    "code": 200,
    "message": "Get post list successfully",
    "data": {
        "all_post": [
            {
                "id": 8,
                "title": "",
                "content": null,
                "create_time": "2021-08-08T03:19:21.445481Z",
                "sts": 0,
                "first_category": null,
                "follow_nb": 0,
                "post_image": null,
                "must_see": false,
                "author": 1
            },
	    ...
        ]
    }
}
```




#### /posts/author/ ####

[patch] http://127.0.0.1:8000/posts/author/top/

Desc: **Django-Swagger conflict. This method is not supported. NO USAGE!!!**


#### /posts/author/top/ ####
[put] http://127.0.0.1:8000/posts/author/top/

Desc: Return top 3 most followed posts of a particular author

**Parameters**

Format: Json

| fields              | required | Type    | Notes                        |
| ------------------- | -------- | ------- | ---------------------------- |
| author              | required | integer |                              | 

**Responses**

Format: Json

* Success

```json
{
    "code": 200,
    "message": "Get post list successfully",
    "data": {
        "all_post": [
            {
                "id": 8,
                "title": "",
                "content": null,
                "create_time": "2021-08-08T03:19:21.445481Z",
                "sts": 0,
                "first_category": null,
                "follow_nb": 0,
                "post_image": null,
                "must_see": false,
                "author": 1
            },
	    ...
        ]
    }
}
```


#### /posts/author/top/ ####
[patch] http://127.0.0.1:8000/posts/author/top/

Desc: **Django-Swagger conflict. This method is not supported. NO USAGE!!!**


#### /posts/category/ ####
[get] http://127.0.0.1:8000/posts/category/

Desc: Get the category for all articles (include: article, announcement, post)

**Responses**

* Success

```json
{
  "code": 200,
  "message": "Get CategoryList successfully",
  "data": {
    "category": [
      "",
      ""
    ]
  }
}
```



#### /posts/favor/ ####

[get] http://127.0.0.1:8000/posts/favor/

Desc: Get all user's favorite articles (include: article, announcement, post) and recently 5 user's favorite articles.

**Responses**

* Success

```Json
{
  "code": 200,
  "message": "Get post list successfully",
  "data": {
    "posts_all": [
      {
        "id": 1,
        "post_username": "",
        "post_username_avatar": "",
        "is_like": true,
        "title": "",
        "content": "",
        "create_time": "2021-08-05T13:18:47.133057Z",
        "sts": 2,
        "first_category": "",
        "follow_nb": 1,
        "post_image": "",
        "must_see": false,
        "author": 1
       },
     ],
     "posts_five":[
       {
         "id": 1,
        "post_username": "",
        "post_username_avatar": "",
        "is_like": true,
        "title": "",
        "content": "",
        "create_time": "2021-08-05T13:18:47.133057Z",
        "sts": 2,
        "first_category": "",
        "follow_nb": 1,
        "post_image": "",
        "must_see": false,
        "author": 1
       }
     ]
}
```



#### /posts/favor/ ####

[put/patch] http://127.0.0.1:8000/posts/favor/

Desc: Like button. If user like the article, user can click this button.

**Django-Swagger conflict!!! PLEASE USE POSTMAN**

**Parameters**

Format: Params

| fields | required | Type    | Notes        |
| ------ | -------- | ------- | ------------ |
| Id     | required | integer | article's id |

**Responses**

* Success

Like

```json
{
    "code": 200,
    "message": "Like successfully",
    "data": null
}
```

Cancel Like

```json
{
    "code": 200,
    "message": "Cancel Like successfully",
    "data": null
}
```

* Fail

Do not login

```json
{
    "code": 400,
    "message": "Authentication credentials were not provided."
}
```

Cannot find article's id

```json
{
    "code": 400,
    "message": "Cannot find the post id",
    "data": null
}
```

Do not send article's id

```Json
{
    "code": 400,
    "message": "Enter a valid post id",
    "data": null
}
```



#### /posts/home/announcement/ ####

[get] http://127.0.0.1:8000/posts/home/announcement/

Desc: Return the top 3 most followed announcements

**Responses**

* Success

```Json
[
    {
        "id": 4,
        "post_username": "",
        "post_username_avatar": null,
        "is_like": false,
        "title": "",
        "content": "",
        "create_time": "2021-08-08T03:06:24.533022Z",
        "sts": 0,
        "first_category": "",
        "follow_nb": 3,
        "post_image": null,
        "must_see": false,
        "author": 1
    },
    ...
]
```



#### /posts/home/article/ ####

[get] http://127.0.0.1:8000/posts/home/article/

Desc: Return the top 3 most followed articles

**Responses**

* Success

```Json
[
    {
        "id": 4,
        "post_username": "",
        "post_username_avatar": null,
        "is_like": false,
        "title": "",
        "content": "",
        "create_time": "2021-08-08T03:06:24.533022Z",
        "sts": 1,
        "first_category": "",
        "follow_nb": 3,
        "post_image": null,
        "must_see": false,
        "author": 1
    },
    ...
]
```


#### /posts/home/must_see/ ####

[get] http://127.0.0.1:8000/posts/home/must_see/

Desc: Return the posts that website admins choose to pin at the top

**Responses**

* Success

```Json
[
    {
        "id": 4,
        "post_username": "",
        "post_username_avatar": null,
        "is_like": false,
        "title": "",
        "content": "",
        "create_time": "2021-08-08T03:06:24.533022Z",
        "sts": 0,
        "first_category": "",
        "follow_nb": 3,
        "post_image": null,
        "must_see": True,
        "author": 1
    },
    ...
]
```


#### /posts/list/ ####

[get] http://127.0.0.1:8000/posts/list/

Desc: Return the list of all posts

**Responses**

* Success

```Json
[
    {
        "id": 8,
        "post_username": "user1",
        "post_username_avatar": null,
        "is_like": false,
        "title": "",
        "content": null,
        "create_time": "2021-08-08T03:19:21.445481Z",
        "sts": 0,
        "first_category": null,
        "follow_nb": 0,
        "post_image": null,
        "must_see": false,
        "author": 1
    },
    ...
]
```



#### /posts/publish/ ####

[post] http://127.0.0.1:8000/posts/publish/

Desc: Publish a new post

**Parameters**

Format: Json

| fields           | required | Type      | Notes                                           |
| ---------------- | -------- | --------- | ----------------------------------------------- |
| author           | required | integer   | Author id                                       |
| title            | required | string    |                                                 |
| content          | required | string    |                                                 |
| sts              | required | integer   | Status of the post                              |
| first_category   | required | string    |                                                 |


**Responses**

* Success

```Json
{
  "code":201,
  "message": "published successfully",
}
```



#### /posts/recom/ ####

[get] http://127.0.0.1:8000/posts/recom/

Desc: **Django-Swagger conflict. NO USAGE!!!**



#### /posts/recom/ ####

[post] http://127.0.0.1:8000/posts/recom/

Desc: Get hot articles

**Django-Swagger conflict. Parameter description of it is incorrect.**

**Parameters**

Format: Json

| fields   | required | Type    | Notes                      |
| -------- | -------- | ------- | -------------------------- |
| post_num | optional | integer | the number of hot articles |

*In this api, the Json can be null (ie, {}). It will return 6 hot articles.

**If the number of articles in database is less than or not much bigger than post_num, the number of returned articles may be unstable.

**Responses**

* Success

```Json
{
    "code": 200,
    "message": "Get Recommendation successfully",
    "data": {
        "posts": [
            {
                "id": 1,
                "author": 1,
                "author_name": "",
                "author_desc": null,
                "author_email": "",
                "author_avatar": "",
                "user_create_time": "2021-08-05T13:18:33.833615Z",
                "title": "",
                "content": "",
                "create_time": "2021-08-05T13:18:47.133057Z",
                "first_category": "",
                "follow_nb": 1,
                "post_image": ""
            },
        ]
    }
}
```





#### /posts/search/ ####

[get] http://127.0.0.1:8000/posts/search/

Desc: **Django-Swagger conflict. NO USAGE!!!**



#### /posts/search/ ####

[post] http://127.0.0.1:8000/posts/search/

Desc: Search the articles (include: article, announcement, post).

**Django-Swagger conflict. Parameter description of it is incorrect.**

**Parameters**

Format: Json

| fields         | required | Type   | Notes |
| -------------- | -------- | ------ | ----- |
| text           | required | String |       |
| first_category | required | String |       |

*Both text and first_category can be null, it will show all the results.

```json
{
    "text" : "",
    "first_category": ""
}
```

**Responses**

* Success

```Json
{
    "code": 200,
    "message": "Get posts successfully",
    "data": {
        "posts": [
            {
                "id": 3,
                "author": "",
                "is_like": false,
                "post_username": "",
                "title": "",
                "content": "",
                "create_time": "2021-08-06T07:37:12.443883Z",
                "sts": 2,
                "first_category": "",
                "follow_nb": 0,
                "post_image": "",
                "must_see": false
            },
            {
                "id": 2,
                "author": "",
                "is_like": false,
                "post_username": "",
                "title": "",
                "content": "",
                "create_time": "2021-08-05T13:19:03.702854Z",
                "sts": 2,
                "first_category": "",
                "follow_nb": 0,
                "post_image": "",
                "must_see": false
            }
        ]
    }
}
```



#### /posts/search/article/ ####

[get] http://127.0.0.1:8000/posts/search/article/

Desc: Get all the articles' id (include: article, announcement, post) and its article status.

**Responses**

* Success

```Json
{
    "code": 200,
    "message": "Get ArticleList successfully",
    "data": {
        "example:": "sts:[article_id]",
        "article_status": {
            "question": [
                1,
                5,
                4,
                3,
                2
            ]
        }
    }
}
```



#### /posts/{id}/ ####

[get] http://127.0.0.1:8000/posts/{id}/

Desc: Return the information of a particular post, including comments.

**Responses**

* Success

```Json
{
    "id": 1,
    "post_username": "",
    "post_username_avatar": null,
    "is_like": false,
    "comments": [
        {
            "id": 1,
            "post_username": "",
            "post_checked": true,
            "post_user_avatar": null,
            "content": "",
            "create_time": "2021-08-06T14:22:23.388310Z",
            "author": 1,
            "post": 1
        },
        ...
    ],
    "title": "",
    "content": "",
    "create_time": "2021-08-06T14:22:15.172213Z",
    "sts": 1,
    "first_category": "",
    "follow_nb": 0,
    "post_image": "",
    "must_see": false,
    "author": 1
}
```



#### /posts/{id}/ ####

[put] http://127.0.0.1:8000/posts/{id}/

Desc: **Django-Swagger conflict. This method is not supported. NO USAGE!!!**



#### /posts/{id}/ ####

[patch] http://127.0.0.1:8000/posts/{id}/

Desc: **Django-Swagger conflict. This method is not supported. NO USAGE!!!**



#### /posts/{id}/ ####

[delete] http://127.0.0.1:8000/posts/{id}/

Desc: **Django-Swagger conflict. This method is not supported. NO USAGE!!!**



### comments ###

#### /comments/publish/ ####

[post] http://127.0.0.1:8000/comments/publish/

Desc: Publish a new comment

**Parameters**

Format: Json

| fields           | required | Type      | Notes                                           |
| ---------------- | -------- | --------- | ----------------------------------------------- |
| author           | required | integer   | Author id                                       |
| post             | required | integer   | Post id that making comments to                 |
| content          | required | string    |                                                 |


**Responses**

* Success

```Json
{
  "code":201,
  "message": "published successfully",
}
```



#### /comments/{id}/ ####

[get] http://127.0.0.1:8000/comments/{id}/

Desc: **This method is not suggestedd. Do not use.**


#### /comments/{id}/ ####

[put] http://127.0.0.1:8000/comments/{id}/

Desc: **Django-Swagger conflict. This method is not supported. NO USAGE!!!**



#### /comments/{id}/ ####

[patch] http://127.0.0.1:8000/comments/{id}/

Desc: **Django-Swagger conflict. This method is not supported. NO USAGE!!!**



#### /comments/{id}/ ####

[delete] http://127.0.0.1:8000/comments/{id}/

Desc: **Django-Swagger conflict. This method is not supported. NO USAGE!!!**



### upload ###

#### /upload/image/ ####

Desc: upload image for posts and users as article image or user's avatar

**Django-Swagger conflict. Please use postman!**

[POST] [http://127.0.0.1:8000/upload/image/](http://127.0.0.1:8000/upload/image/)

**Parameters**

Format: forum-data

| fields     | required | Type      | Notes |
| ---------- | -------- | --------- | ----- |
| image_file | required | ImageFile |       |

**Responses**

* Success

```json
{
    "id": 1,
    "image_file": "http://127.0.0.1:8000/media/post_image/file_tree.png",
    "created_time": "2021-08-08T13:07:24.633484Z",
    "last_mod_time": "2021-08-08T13:07:24.633511Z"
}
```

## Reference

* https://www.dusaiphoto.com/article/103/

* https://docs.djangoproject.com/en/3.2/

* Vuejs.org. 2021. Vue.js. [online] Available at: <https://vuejs.org/index.html> [Accessed 8 August 2021]. 

* Cli.vuejs.org. 2021. Vue CLI. [online] Available at: <https://cli.vuejs.org/> [Accessed 8 August 2021].

* Antdv.com. 2021. Ant Design Vue. [online] Available at: <https://antdv.com/docs/vue/introduce/> [Accessed 8 August 2021].

* https://www.mhlw.go.jp

* https://www.health.state.mn.us/ 

* https://www.news.com.au/ 

* https://forums.whirlpool.net.au/ 
