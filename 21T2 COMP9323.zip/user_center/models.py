from django.contrib.auth.models import AbstractUser
from django.db import models
from imagekit.models import ProcessedImageField
from imagekit.processors import ResizeToFill


class User(AbstractUser):
    """
        An abstract base class implementing a fully featured User model with
        admin-compliant permissions.

        Username and password are required. Other fields are optional.
        (first_name, last_name, email, is_staff, is_active,date_joined)
    """
    username = models.CharField(max_length=20, verbose_name='userName', unique=True)
    # init user_id, primary_key
    user_id = models.AutoField(primary_key=True, unique=True, verbose_name='user_id')
    # init phone number, unique
    phone_number = models.CharField(max_length=11, blank=False, null=True, verbose_name='phone_number')
    # init user's email, cannot be blank
    email = models.EmailField(unique=True, verbose_name='email')
    # init password, cannot be blank, length is between [8,22]
    # password = models.CharField(max_length=22, blank=False)
    # init status, choice, default = individual user
    user_status = [(0, 'individual user'), (1, 'expert/organization')]
    status = models.SmallIntegerField(choices=user_status, default=0, verbose_name='status')
    checked = models.BooleanField(default=False, verbose_name='approval_status')
    # init Gender, choice, default = unknown
    gender_choice = [(0, 'unknown'), (1, 'male'), (2, 'female'), (3, 'others')]
    gender = models.SmallIntegerField(choices=gender_choice, default=0, verbose_name='gender')
    # init nickname, max length is 20
    # nickname = models.CharField(max_length=20, blank=True)
    # init birthday
    birthday = models.DateField(verbose_name='birthday', blank=True, null=True)
    # init address
    address = models.TextField(blank=True, null=True)
    # init hobby
    hobby = models.CharField(max_length=50, blank=True, null=True)
    # init personal info
    personal_info = models.TextField(blank=True, null=True)
    # init personal avatar

    # avatar = ProcessedImageField(upload_to='./user_avatar/', processors=[ResizeToFill(200, 200)], null=True,
                               #  options={'quality': 60})
 
    avatar = models.CharField(verbose_name='post image', max_length=200, null=True, blank=True)
    # init user create time
    created_time = models.DateTimeField(verbose_name='create_time', auto_now_add=True, null=True)
    # init user last modify time
    last_mod_time = models.DateTimeField(verbose_name='update_time', auto_now=True, null=True)

    class Meta:
        verbose_name = 'User management'
        verbose_name_plural = verbose_name
        ordering = ['-user_id']
        db_table = 'users'

