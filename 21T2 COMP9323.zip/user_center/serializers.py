# coding:utf-8
from django.contrib.auth import login
from django.contrib.auth.hashers import make_password
from rest_framework import serializers
from rest_framework.serializers import ModelSerializer, ValidationError
from .models import User


class RegisterSerializer(ModelSerializer):
    '''
    This serializer is the RegisterSerializer used for registering
    1. verify all the required field can be received
    2. filter the received field by conditions
        1. whether the email field meet up with email's standard
        2. whether the length of password field more than 6, including upper and lower letters and digits
        3. whether the password and retype_new_password field are consistent
        4. whether the username field need to be unique
    3. if all the fields meet up with the requirements and the username is unique, it can be saved to the server
    '''
    retype_new_password = serializers.CharField(min_length=8, write_only=True)

    class Meta:
        model = User
        fields = ['username', 'password', 'email', 'status', 'retype_new_password']

    def validate(self, attrs):
        password = attrs.get('password')
        username = attrs.get('username')
        rtpassword = attrs.get('retype_new_password')
        email = attrs.get('email')
        status = str(attrs.get('status'))  # status is a digit 
        if not password or not username or not rtpassword or not email or not status:
            raise ValidationError("Loss of required information !")
        if password != rtpassword:
            raise ValidationError("Two typed password are not consisten !")
        if password.isdigit() and password.isalnum():
            raise ValidationError("Password must contain upper and lower alphabet and digit !")
        return attrs

    def create(self, validated_data):
        # get after proprecessing password
        passwd = validated_data.get('password')
        # encrypt the password
        hash_passwd = make_password(passwd)
        # get username , email, status
        username = validated_data.get('username')
        email = validated_data.get('email')
        status = validated_data.get('status')
        # create user's information
        user = User.objects.create(username=username,
                                   password=hash_passwd,
                                   email=email,
                                   status=status)

        # auto login after register
        login(request=self.context.get('request'), user=user)
        return user


class ChangePasswordSerializer(ModelSerializer):
    '''
    This serializer is the ChangePasswordSerializer used for user's password changing
    1. old_password，new_password，retype_new_password are the required field
    2. verify old_password belongs to the user
    3. verify new_password, retype_new_password are consistent containing upper and lower letters, 
    digits and the length longer than 6
    4. all the requirments meet up with requirements, encrypt the password, replace the old password and logout
    '''
    old_password = serializers.CharField(min_length=8, write_only=True)
    new_password = serializers.CharField(min_length=8, write_only=True)
    retype_new_password = serializers.CharField(min_length=8, write_only=True)

    class Meta:
        model = User
        fields = ['old_password', 'new_password', 'retype_new_password']

    def validate(self, attrs):
        username = self.instance.username
        old_password = attrs.get('old_password')
        new_password = attrs.get('new_password')
        rt_new_password = attrs.get('retype_new_password')
        if not old_password or not new_password or not rt_new_password:
            raise ValidationError("required data missing", code=400)
        if new_password != rt_new_password:
            raise ValidationError("new password and re-typed password is not same", code=400)
        if new_password.isdigit() and new_password.isalnum():
            raise ValidationError("password must contain characters and numbers", code=400)
        if username and self.instance.check_password(old_password):
            return attrs
        else:
            raise ValidationError("old password incorrect", code=400)

    def update(self, instance, validated_data):
        # get new password
        new_passwd = validated_data.get('new_password')
        # encrypt the password
        hash_passwd = make_password(new_passwd)
        instance.password = hash_passwd
        instance.save()
        return instance


# get user's infomation
class UserInfosSerializer(ModelSerializer):
    '''
    This serializer is the UserInfosSerializer used for getting and upadting user's info
    1. user_id，email，status fileds are read_only
    2. other fileds can read and write
    3. other fileds can be changed when meeting up the requirements of model's type 
    '''
    user_id = serializers.IntegerField(read_only=True)
    email = serializers.EmailField(read_only=True)
    status = serializers.IntegerField(read_only=True)

    class Meta:
        model = User
        fields = ['username', 'user_id', 'email', 'status', 'gender', 'birthday', 'address', 'hobby', 'avatar',
                  'phone_number', 'personal_info', 'checked']

    def update(self, instance, validated_data):
        instance.username = validated_data.get("username", instance.username)
        instance.gender = validated_data.get("gender", instance.gender)
        instance.birthday = validated_data.get("birthday", instance.birthday)
        instance.address = validated_data.get("address", instance.address)
        instance.hobby = validated_data.get("hobby", instance.hobby)
        instance.phone_number = validated_data.get("phone_number", instance.hobby)
        instance.personal_info = validated_data.get("personal_info", instance.hobby)
        instance.avatar = validated_data.get("avatar", instance.avatar)
        instance.save()
        return instance


class LoginSerializer(ModelSerializer):
    '''
    This serializer is the LoginSerializer used for user's login
    '''
    email = serializers.EmailField()
    password = serializers.CharField(min_length=8)

    class Meta:
        model = User
        fields = ['email', 'password']


class OrgListSerializer(ModelSerializer):
    # user_info = UserInfosSerializer(read_only=True)
    status = serializers.SerializerMethodField()
    email = serializers.EmailField(read_only=True)

    def get_status(self, obj):
        return obj.get_status_display()

    class Meta:
        model = User
        fields = ['email', 'status', 'avatar', 'personal_info']


class UserInfoSerializer(ModelSerializer):
    user_id = serializers.IntegerField(read_only=True)
    email = serializers.EmailField(read_only=True)
    status = serializers.IntegerField(read_only=True)

    class Meta:
        model = User
        fields = ['username', 'user_id', 'email', 'status', 'gender', 'birthday', 'address', 'hobby', 'avatar',
                  'phone_number', 'personal_info', 'checked']
