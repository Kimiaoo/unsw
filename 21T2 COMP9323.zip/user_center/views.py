from django.contrib.auth import login, authenticate, logout
from rest_framework.authentication import BasicAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.generics import CreateAPIView, UpdateAPIView, ListAPIView
from rest_framework.views import APIView
from .models import User
from .serializers import RegisterSerializer, ChangePasswordSerializer, UserInfosSerializer, LoginSerializer, \
    OrgListSerializer, UserInfoSerializer
from .tests import CsrfCloseAuthentication



"""
interface of register 
"""


class RegisterApiView(CreateAPIView):
    permission_classes = []
    authentication_classes = []
    queryset = User.objects.all()

    serializer_class = RegisterSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response({
            "code": 201,
            "message": "register successfully"
        }, headers=headers)


"""
interface of login
"""


class LoginApiView(CreateAPIView, APIView):
    permission_classes = []
    authentication_classes = []

    serializer_class = LoginSerializer

    def create(self, request, *args, **kwargs):
        email = request.data.get("email", None)
        if not email:
            return Response({
                "code": 400,
                "message": "Enter a valid email address",
                "data": None
            })
        try:
            user = User.objects.get(email=email)
            login_data = {
                "username": user.username,
                "password": request.data.get('password')
            }
            # authenticate the password
            user_instance = authenticate(request, **login_data)
            if user_instance:
                login(request, user_instance)
                return Response({
                    "code": 200,
                    "message": "login successfully",
                    "data": {"username": user_instance.username,
                             "password": user_instance.password,
                             "email": user_instance.email,
                             "status": user_instance.status}
                })
            else:
                return Response({
                    "code": 400,
                    "message": "Your account or password is incorrect.",
                    "data": None
                })
        except Exception as e:
            print(e)
            return Response({
                "code": 400,
                "message": "Enter a valid email address",
                "data": None
            })


"""
interface of changing password
1. authenticate the user 
2. authenticate the password
3. authenticate the password and retype password
4. change the password successfully
"""


class ChangePasswordApiView(UpdateAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = (CsrfCloseAuthentication, BasicAuthentication)

    serializer_class = ChangePasswordSerializer

    def update(self, request, *args, **kwargs):
        user_instance = User.objects.get(user_id=request.user.user_id)
        user_ser = ChangePasswordSerializer(user_instance, data=request.data, partial=True)
        if user_ser.is_valid(raise_exception=True):
            user_ser.save()
            # logout
            logout(request)
            return Response({
                "code": 200,
                "message": "Password updated",
                "data": None
            })
        else:
            return Response({
                "code": 400,
                "message": user_ser.error_messages,
                "data": None
            })


"""
interface of getting user's information
1.info of user
2.info of article
"""


class UserInfosAPIViewApiView(UpdateAPIView, ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [CsrfCloseAuthentication, BasicAuthentication]

    serializer_class = UserInfosSerializer

    # query user's info
    def list(self, request, *args, **kwargs):
        user_instance = User.objects.get(user_id=request.user.user_id)
        user_ser = UserInfosSerializer(user_instance)
        return Response({
            "code": 200,
            "message": "user info shows successfully",
            "data": user_ser.data
        })

    # change user's info
    def update(self, request, *args, **kwargs):
        user_instance = User.objects.get(user_id=request.user.user_id)
        user_ser = UserInfosSerializer(user_instance, data=request.data, partial=True)
        if user_ser.is_valid(raise_exception=True):
            if 'password' in request.data.keys():
                return Response({
                    "code": 400,
                    "message": "The password cannot be change here.",
                    "data": None
                })
            if 'email' in request.data.keys():
                return Response({
                    "code": 400,
                    "message": "The email cannot be changed. If you want to change your email, please connect to"
                               + "website administrator",
                    "data": None
                })
            else:
                user_ser.save()
                return Response({
                    "code": 200,
                    "message": "User information updated successfully",
                    "data": user_ser.data
                })


class OrgList(ListAPIView):
    permission_classes = []
    authentication_classes = []

    serializer_class = OrgListSerializer

    def list(self, request, *args, **kwargs):
        user_instance = User.objects.filter(status=1)
        user_instance = user_instance.order_by("-user_id")
        user_instance = OrgListSerializer(user_instance, many=True)

        return Response({
            "code": 200,
            "message": "Get professionals' info successfully",
            "data": user_instance.data
        })


'''
interface of logging out
'''
class LogOutView(CreateAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [CsrfCloseAuthentication, BasicAuthentication]
    # logout and delete the seesion in db
    def create(self, request, *args, **kwargs):
        logout(request)
        return Response({
            "code": 200,
            "message": "Logout successfully",
            "data": None
        })


class UserInfo(UpdateAPIView):
    permission_classes = []
    authentication_classes = []

    serializer_class = UserInfoSerializer

    def update(self, request, *args, **kwargs):
        user_instance = User.objects.all()
        user_ser = UserInfoSerializer(user_instance, many=True)

        data = None
        for user in user_ser.data:
            if user['user_id'] == int(request.query_params.get('user_id')):
                data = user

        if data:
            return Response({
                "code": 200,
                "message": "Get user information successfully",
                "data": data
            })
        else:
            return Response({
                "code": 400,
                "message": "User does not exists"
            })
