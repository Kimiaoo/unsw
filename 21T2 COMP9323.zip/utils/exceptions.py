# coding:utf-8
from rest_framework.exceptions import ValidationError, NotAuthenticated
from rest_framework.response import Response


def custom_exception_handler(exc, context):
    try:
        if isinstance(exc, ValidationError):
            for key, value in dict(exc.__dict__.get('detail')).items():
                return Response({
                    "code": 400,
                    "message": value[0]
                })
        if isinstance(exc, NotAuthenticated):
            return Response({
                "code": 400,
                "message": str(exc)
            })
    except Exception as e:
        print(e)
        return Response(
            {"code": 500,
             "message": "error, wait a minute"
             })
